{
    'name': "hawk_accounting",
    'summary': "Hawk Accounting Module",
    'description': """
        Custom for Accounting module.
    """,
    'author': "Arman Castro",
    'website': "",
    'category': 'base',
    'version': '0.1',
    'depends': [],
    'qweb': [],
    'data': [
        # 'security/security.xml',
        'security/ir.model.access.csv',
        # 'security/rules.xml',
        #
        # 'data/analysis_type_data.xml',
        # 'data/config_data.xml',
        #
        # 'wizards/assign_teamleader_views.xml',
        # 'wizards/reject_analysis_views.xml',
        #
        # 'views/tender_views.xml',
        # 'views/tenderer_views.xml',
        # 'views/analysis_views.xml',

    ],
    'demo': [
        # 'demo/demo.xml',
        # 'demo/thinksavvy_demo.xml',
    ],
    'installable': True,
    'application': False,
}

