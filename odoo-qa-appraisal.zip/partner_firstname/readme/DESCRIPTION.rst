This module was written to extend the functionality of contacts to support
having separate last name and first name.
