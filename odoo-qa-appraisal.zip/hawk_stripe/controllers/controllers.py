# -*- coding: utf-8 -*-

from odoo import fields, http, _
import base64
import json
import os
import stripe
import logging
import binascii
from odoo.exceptions import AccessError, MissingError
from odoo.addons.portal.controllers.mail import _message_post_helper
from odoo.addons.sale.controllers.portal import CustomerPortal
from odoo.addons.payment.controllers.portal import PaymentProcessing
from odoo.addons.base.models.ir_ui_view import keep_query
from werkzeug import urls
from odoo import models, fields, api
from odoo.http import request

_logger = logging.getLogger(__name__)


class HawkCustomerPortal(CustomerPortal):

    @http.route(['/my/orders/<int:order_id>'], type='http', auth="public", website=True)
    def portal_order_page(self, order_id, report_type=None, access_token=None, message=False, download=False, **kw):
        try:
            if not access_token and 'access_token' in kw:
                access_token = kw.get('access_token')
            order_sudo = self._document_check_access('sale.order', order_id, access_token=access_token)
        except (AccessError, MissingError):
            _logger.error('Access Error @ portal_order_page')
            return request.redirect('/my')

        if report_type in ('html', 'pdf', 'text'):
            return self._show_report(model=order_sudo, report_type=report_type, report_ref='hawk_stripe.action_report_saleorder', download=download)

        # use sudo to allow accessing/viewing orders for public user
        # only if he knows the private token
        # Log only once a day
        if order_sudo:
            # store the date as a string in the session to allow serialization
            now = fields.Date.today().isoformat()
            session_obj_date = request.session.get('view_quote_%s' % order_sudo.id)
            if session_obj_date != now and request.env.user.share and access_token:
                request.session['view_quote_%s' % order_sudo.id] = now
                body = _('Quotation viewed by customer %s', order_sudo.partner_id.name)
                _message_post_helper(
                    "sale.order",
                    order_sudo.id,
                    body,
                    token=order_sudo.access_token,
                    message_type="notification",
                    subtype_xmlid="mail.mt_note",
                    partner_ids=order_sudo.user_id.sudo().partner_id.ids,
                )
        acquirer = request.env['payment.acquirer'].sudo().search([('provider','=','stripe')])
        values = self._order_get_page_view_values(order_sudo, access_token, **kw)
        values['message'] = message
        values['acq'] = acquirer
        values['context'] = {
            'return_url': '%s/update-payment-transaction/%s' % (str(request.env['ir.config_parameter'].sudo().get_param('web.base.url')),str(order_sudo.id))
        }
        _logger.info(values)
        return request.render('hawk_stripe.sale_order_portal_template', values)

    # create payment.transaction when redirected here
    @http.route(['/my/orders/<int:order_id>/accept'], type='json', auth="public", website=True)
    def portal_quote_accept(self, order_id, access_token=None, name=None, signature=None):
        # get from query string if not on json param
        access_token = access_token or request.httprequest.args.get('access_token')
        try:
            order_sudo = self._document_check_access('sale.order', order_id, access_token=access_token)
        except (AccessError, MissingError):
            return {'error': _('Invalid order.')}

        if not order_sudo.has_to_be_signed():
            return {'error': _('The order is not in a state requiring customer signature.')}
        if not signature:
            return {'error': _('Signature is missing.')}

        try:
            order_sudo.write({
                'signed_by': name,
                'signed_on': fields.Datetime.now(),
                'signature': signature,
            })
            request.env.cr.commit()

            # create transaction with default acquirer 'stripe'
            transaction = order_sudo._create_payment_transaction({
                'acquirer_id': request.env['payment.acquirer'].sudo().search([('provider','=','stripe')]).id,
                'type': order_sudo._get_payment_type(False),
                'return_url': order_sudo.get_portal_url(),
            })

            PaymentProcessing.add_payment_transaction(transaction)

        except (TypeError, binascii.Error) as e:
            return {'error': _('Invalid signature data.')}

        if not order_sudo.has_to_be_paid():
            order_sudo.action_confirm()
            order_sudo._send_order_confirmation_mail()

        pdf = request.env.ref('hawk_stripe.action_report_saleorder').sudo()._render_qweb_pdf([order_sudo.id])[0]

        _message_post_helper(
            'sale.order', order_sudo.id, _('Order signed by %s') % (name,),
            attachments=[('%s.pdf' % order_sudo.name, pdf)],
            **({'token': access_token} if access_token else {}))

        query_string = '&message=sign_ok'
        if order_sudo.has_to_be_paid(True):
            query_string += '#allow_payment=yes'
        return {
            'force_refresh': True,
            'redirect_url': order_sudo.get_portal_url(query_string=query_string),
        }


class HawkStripe(http.Controller):

    @http.route('/site-safety-observations', type='http', auth='public', website=True, sitemap=True)
    def safety_page(self, **kw):
        return request.render("hawk_stripe.site-safety-observations")

    @http.route('/hawk_stripe/<module>/quotation-form', type='http', auth='public', website=True, sitemap=False)
    def quotation_form(self, module, **kw):

        product = request.env['product.template'].sudo().search([('module_id.name' , '=', module.title())])
        try:
            context = {
                'module': module,
                'price': product.list_price,
                'countries': request.env['res.country'].sudo().search([]),
                'regions': request.env['res.country.state'].sudo().search([])
            }
            return request.render("hawk_stripe.quotation_form", context)
        except Exception as e:
            # return json.dumps({'error':str(e), 'code':403})
            _logger.error('Error in internal_attachment_form ', str(e))
            return http.Response(response='Error in quotation_form: ' + str(e), status=403)

    @http.route('/hawk_stripe/<module>/quotation-form/submit', type='http', auth='public', website=True, sitemap=False)
    def submit_quotation_form(self, module, **kw):

        try:
            print(kw.get('quot_tender_budget'))
            print(kw.get('quot_tenderer_count'))
            print(kw.get('quot_price'))

            product_template = request.env['product.template'].sudo().search([('module_id.name', '=', module.title())])
            product = request.env['product.product'].sudo().search([('product_tmpl_id.id', '=', product_template.id)])
            country = request.env['res.country'].sudo().search([('name', '=', kw.get('quot_country'))], limit=1)
            region = request.env['res.country.state'].sudo().search([('name', '=', kw.get('quot_region'))], limit=1)

            company = False
            company_has_no_abn = request.env['res.company'].sudo().search([('name', '=', kw.get('quot_company_name'))])
            company_has_correct_abn = request.env['res.company'].sudo().search(['&',('name', '=', kw.get('quot_company_name')), ('ab_number', '=', kw.get('quot_ab_number'))])
            # company_has_incorrect_abn = request.env['res.company'].sudo().search(['&',('name', '=', kw.get('quot_company_name')), ('ab_number', '!=', kw.get('quot_ab_number'))])
            # company_has_incorrect_name = request.env['res.company'].sudo().search(['&',('name', '!=', kw.get('quot_company_name')), ('ab_number', '=', kw.get('quot_ab_number'))])

            if company_has_correct_abn:

                company = company_has_correct_abn
                sudo_company = company.sudo()

                if not sudo_company.street:
                    sudo_company.street = kw.get('quot_street')

                if not sudo_company.street2:
                    sudo_company.street2 = kw.get('quot_street2')

                if not sudo_company.city:
                    sudo_company.city = kw.get('quot_city')

                if not sudo_company.state_id:
                    sudo_company.state_id = region.id

                if not sudo_company.state:
                    sudo_company.state = region.name if region else kw.get('quot_region')

                if not sudo_company.country_id:
                    sudo_company.country_id = country.id

                if not sudo_company.country:
                    sudo_company.country = country.name if country else kw.get('quot_country')

            # elif company_has_incorrect_abn:
            #     message = 'You may have provided us an incorrect business number. Please '
            #     return_url = urls.url_join(request.env['ir.config_parameter'].sudo().get_param('web.base.url'),
            #                                '/hawk_stripe/'+module+'/quotation-form')
            #     return request.render("hawk_stripe.tx_fail_form",
            #                           {'message': message, 'allow_try_again': True, 'return_url': return_url})
            #
            # elif company_has_incorrect_name:
            #     message = 'You may have provided us an incorrect company name. Please '
            #     return_url = urls.url_join(request.env['ir.config_parameter'].sudo().get_param('web.base.url'),
            #                                '/hawk_stripe/'+module+'/quotation-form')
            #     return request.render("hawk_stripe.tx_fail_form",
            #                           {'message': message, 'allow_try_again': True, 'return_url': return_url})
            elif company_has_no_abn:
                company = company_has_no_abn
                sudo_company = company.sudo()

                if not sudo_company.street:
                    sudo_company.street = kw.get('quot_street')

                if not sudo_company.street2:
                    sudo_company.street2 = kw.get('quot_street2')

                if not sudo_company.city:
                    sudo_company.city = kw.get('quot_city')

                if not sudo_company.state_id:
                    sudo_company.state_id = region.id

                if not sudo_company.state:
                    sudo_company.state = region.name if region else kw.get('quot_region')

                if not sudo_company.country_id:
                    sudo_company.country_id = country.id

                if not sudo_company.country:
                    sudo_company.country = country.name if country else kw.get('quot_country')

            elif not company:
                company = request.env['res.company'].sudo().create({
                    'name': kw.get('quot_company_name'),
                    'ab_number': kw.get('quot_ab_number'),
                    'street': kw.get('quot_street'),
                    'street2': kw.get('quot_street2'),
                    'city': kw.get('quot_city'),
                    'state_id': region.id,
                    'state': region.name if region else kw.get('quot_region'),
                    'country_id': country.id,
                    'country': country.name if country else kw.get('quot_country')
                })
                _logger.info('...new company created.')

            contact = request.env['res.partner'].sudo().search([
                ('email', '=', kw.get('quot_email')),
                ('parent_id.id', '=', company.partner_id.id)
            ])

            if not contact:
                contact = request.env['res.partner'].sudo().create({
                    'name': '%s %s' % (kw.get('quot_firstname'), kw.get('quot_lastname')),
                    'phone': kw.get('quot_phone'),
                    'email': kw.get('quot_email'),
                    'parent_id': company.partner_id.id,
                })
                _logger.info('...new contact created.')

            category = request.env['ir.module.category'].sudo().search([('name', '=', 'HAWK')])
            concierge_group = request.env['res.groups'].sudo().search(
                [('category_id.id', '=', category.id), ('name', '=', 'Client Relations Manager')])
            salesperson = request.env['res.users'].sudo().search([('groups_id', 'in', concierge_group.id),('name','=','Mark Bryce')], limit=1)

            sale_order = request.env['sale.order'].sudo().create({
                'partner_id': contact.id,
                'user_id': salesperson.id,
                'require_signature': True,
                'require_payment': True,
                'order_line': [(0, 0, {'product_id': product.id,
                                       'name': kw.get('quot_title'),
                                       'product_uom_qty': kw.get('quot_tenderer_count'),
                                       'price_unit': kw.get('quot_price'),
                                       })]
            })

            # Send Email Notification to client after Quotation Form is Submitted
            template_id = request.env.ref('hawk_stripe.{}'.format('success_quotation_template')).sudo().id
            request.env['mail.template'].sudo().browse(template_id).send_mail(sale_order.id, force_send=True)

            message = "Setup Successful"
            return request.render("hawk_stripe.tx_success_form", {'message': message})

        except Exception as e:
            return http.Response(response='Error in quotation: ' + str(e), status=403)

    @http.route('/create-payment-intent', type='json', auth='public', website=True, sitemap=False, csrf=True)
    def create_payment_intent(self, **kw):
        try:
            headers = dict(request.httprequest.headers)
            data = json.loads(request.httprequest.data)
            order = request.env['sale.order'].sudo().search([('id', '=', data['order_id'])])
            order = order.sudo()
            acquirer = request.env['payment.acquirer'].sudo().search([('id','=',data['acquirer_id'])])
            api_key = acquirer.stripe_secret_key if acquirer.state == 'enabled' else acquirer.stripe_test_secret_key
            _logger.info(api_key)
            stripe.api_key = api_key

            transaction = order.transaction_ids.sudo().search([], limit=1, order='id desc')

            if not transaction:
                return False

            if transaction and not transaction.stripe_payment_intent_secret:

                _logger.info('Creating intent...')
                order = order.sudo()
                amount = int(order.amount_total * 100)

                # customer = stripe.Customer.create(
                #     name=order.partner_id.name,
                #     email=order.partner_id.email,
                #     phone=order.partner_id.phone,
                #     balance=amount
                # )
                #
                # invoice = stripe.Invoice.create(
                #     customer=str(customer.id)
                # )

                intent = stripe.PaymentIntent.create(
                    amount=amount,
                    currency='aud',
                    automatic_payment_methods={
                        'enabled': True,
                    },
                    # customer = str(customer.id),
                    # invoice=str(invoice.id)
                )

                transaction.stripe_payment_intent = intent.id
                transaction.reference = intent.id
                transaction.stripe_payment_intent_secret = intent.client_secret

            transaction.acquirer_id = acquirer.id
            return json.dumps({'clientSecret': transaction.stripe_payment_intent_secret})

        except Exception as e:
            _logger.error(str(e))
            return False

    def create_webhook_endpoint(self, url):
        try:
            acquirer = request.env['payment.acquirer'].sudo().search([('provider', '=', 'stripe')])
            api_key = acquirer.stripe_secret_key if acquirer.state == 'enabled' else acquirer.stripe_test_secret_key
            _logger.info(api_key)
            stripe.api_key = api_key

            webhook = stripe.WebhookEndpoint.create(
                url=url,
                enabled_events=[
                    "payment_intent.canceled",
                    "payment_intent.created",
                    "payment_intent.payment_failed",
                    "payment_intent.processing",
                    "payment_intent.requires_action",
                    "payment_intent.succeeded"
                ]
            )

            stripe.WebhookEndpoint.modify(
                str(webhook.id),
                url="%s?%s" % (webhook.url, keep_query(endpoint_secret=webhook.secret))
            )

            return webhook

        except Exception as e:
            _logger.error(str(e))
            return False

    @http.route('/update-payment-transaction/<order_id>', type='http', auth='public', website=True, sitemap=False, csrf=False)
    def update_payment_transaction(self, order_id, **kw):
        response = None

        try:
            _logger.info('Initialising Web transaction...')
            _logger.info('Queries: '+str(kw))

            order = request.env['sale.order'].sudo().search([('id', '=', order_id)])
            order = order.sudo()
            tx = request.env['payment.transaction'].sudo().search([('reference', '=', kw.get('payment_intent'))])
            web_tx = request.env['hawk.api.transaction'].sudo().search([('reference','=',kw.get('payment_intent'))])

            if not web_tx:
                company = request.env['res.company'].sudo().search([('partner_id.id', '=', order.partner_id.parent_id.id)])
                data = {
                    "company": {
                        "name": company.name,
                        "abn": company.ab_number,
                        "street": order.partner_id.parent_id.street,
                        "street2": order.partner_id.parent_id.street2,
                        "city": order.partner_id.parent_id.city,
                        "region": company.state,
                        "country": company.country,
                    },
                    "contact": {
                        "firstname": order.partner_id.firstname,
                        "lastname": order.partner_id.lastname,
                        "phone": order.partner_id.phone,
                        "email": order.partner_id.email
                    },
                    "tender": {
                        "name": order.order_line.sudo().search([('order_id.id', '=', order_id)]).name,
                        "tenderer_count": int(
                            order.order_line.sudo().search([('order_id.id', '=', order_id)]).product_uom_qty)
                    },
                    "order_id": order.id
                }
                web_tx = request.env['hawk.api.transaction'].initialize_tx(data, {'payment_intent': kw.get('payment_intent')}, 'form_save')

            _logger.info('Web transaction initialised.')

            status = kw.get('redirect_status')

            # update so/invoice/tx states
            if status == 'succeeded':
                _logger.info('Stripe TX is successful. Processing Odoo payment TX...')

                base_url = str(request.env['ir.config_parameter'].sudo().get_param('web.base.url'))
                url = '/attachment-form/%s?%s' % (web_tx.token, keep_query(reference=kw.get('payment_intent')))
                template_id = request.env.ref('hawk_stripe.{}'.format('email_template_edi_invoice'))

                _logger.info('Variables initialised for payment TX.')

                tx.state = 'done'

                _logger.info("Payment TX is set to 'Done'.")

                if order.state != 'sale':
                    order.action_confirm()
                    _logger.info('Quotation is set to Sales Order.')

                if not order.invoice_ids:
                    invoices = order._create_invoices()
                    _logger.info('Invoice created.')

                    # this will automatically create payment.account and reconsile if theres an invoice
                    tx._create_payment()
                    _logger.info('Payment TX is reconsiled with the Stripe payment.')

                else:
                    invoices = order.invoice_ids
                    _logger.info('Invoice retrieved.')

                tx.return_url = url
                _logger.info('Return URL is redirected to Tender form.')

                for inv in invoices:
                    inv = inv.sudo()
                    _logger.info('Processing INV: '+str(inv.id)+' ...')
                    _logger.info('Sending INV: ' + str(inv.id) + ' thru email ...')

                    # Send Email Notification to client after a successful payment
                    template = request.env.ref('hawk_stripe.success_payment_template')
                    inv_pdf = request.env.ref('hawk_stripe.account_invoices').sudo()._render_qweb_pdf(inv.id)[0]
                    url = base_url + url
                    attachment = request.env['ir.attachment'].sudo().create({
                        'name': inv.name + '.pdf',
                        'type': 'binary',
                        'datas': base64.b64encode(inv_pdf),
                        'res_model': inv._name,
                        'res_id': inv.id
                    })
                    template.sudo().write({'attachment_ids': [(6, 0, [attachment.id])]})

                    request.env['mail.template'].sudo().browse(template.id).with_context(url=url).send_mail(order.id, force_send=True)

                    inv.write({'is_move_sent': True})
                    _logger.info('INV: ' + str(inv.id) + ' is processed.')
                order.invoice_status = 'invoiced'
                _logger.info('Invoices are sent thru email.')

                return request.redirect(url)

            elif status == 'processing':

                tx.state = 'pending'
                # TODO: send email to customer
                url = str(request.env['ir.config_parameter'].sudo().get_param('web.base.url'))+'/hawk_stripe/my/webhook/track-webhook/%s' % (kw.get('payment_intent'))
                webhook = self.create_webhook_endpoint(url)

                if not webhook:
                    response = 'No webhook created.'

            elif status == 'requires_payment_method':
                tx.state = 'pending'
                # TODO: send email to customer
                response = 'No selected payment method.'

            else:
                tx.state = 'error'
                # TODO: send email to customer
                response = 'Error in processing your payment.'

        except Exception as e:
            response = e

        return http.Response(response=response, status=403)

    # send notification with email
    # def action_send_notification(self, obj, subject, body):
    #     odoobot = request.env.ref('base.partner_root')
    #     obj.message_post(
    #         subject=subject,
    #         body=body,
    #         message_type='comment',
    #         notify_by_email=True,
    #         author_id=odoobot.id,
    #         partner_ids=[obj.partner_id.id]
    #     )
    #
    # def action_send_email(self):
    #     template_id = False
    #     context = []
    #     request.env['mail.template'].sudo().browse(template_id).with_context(context).send_mail(self.id, force_send=True)
    #
    #     return True

    @http.route('/hawk_stripe/my/webhook/track-webhook/<intent_id>', type='json', auth='public', methods=['POST'], website=True, sitemap=False, csrf=False)
    def track_webhook(self, intent_id, **kw):
        payment_intent = None
        event = None
        data = json.loads(request.httprequest.data)
        sig_header = json.loads(request.httprequest.headers)['STRIPE_SIGNATURE']

        try:
            endpoint_secret = kw.get('endpoint_secret')
            event = stripe.Webhook.construct_event(
                data, sig_header, endpoint_secret
            )
        except ValueError as e:
            # Invalid payload
            raise e
        except stripe.error.SignatureVerificationError as e:
            # Invalid signature
            raise e

        tx = request.env['payment.transaction'].sudo().search([('reference', '=', intent_id)])

        # Handle the event
        if event['type'] == 'payment_intent.canceled':
            tx.state = 'cancel'
            # TODO: send email to customer
            payment_intent = event['data']['object']
        elif event['type'] == 'payment_intent.created':
            payment_intent = event['data']['object']
        elif event['type'] == 'payment_intent.payment_failed':
            tx.state = 'error'
            # TODO: send email to customer
            payment_intent = event['data']['object']
        elif event['type'] == 'payment_intent.processing':
            tx.state = 'pending'
            # TODO: send email to customer
            payment_intent = event['data']['object']
        elif event['type'] == 'payment_intent.requires_action':
            tx.state = 'pending'
            # TODO: send email to customer
            payment_intent = event['data']['object']
        elif event['type'] == 'payment_intent.succeeded':
            tx.state = 'done'
            # TODO: send email to customer
            payment_intent = event['data']['object']
            # ... handle other event types
        else:
            _logger.info('Unhandled event type {}'.format(event['type']))

        return http.Response(success=True)

