# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ProductTemplate(models.Model):
    _inherit = 'product.template'
    _description = 'hawk_product and product inherit'

    module_id = fields.Many2one('hawk.analysis.type', 'Module')

