# -*- coding: utf-8 -*-

import json
import os
import stripe
import logging
import requests
from requests.exceptions import HTTPError
from odoo import api, fields, models, _
from odoo.http import request
from werkzeug import urls
from odoo.exceptions import ValidationError


_logger = logging.getLogger(__name__)


class PaymentAcquirerStripe(models.Model):
    _inherit = 'payment.acquirer'

    stripe_test_secret_key = fields.Char(string='Stripe Test Secret Key', required_if_provider='stripe', groups='base.group_user')
    stripe_test_publishable_key = fields.Char(string='Stripe Test Publishable Key', required_if_provider='stripe', groups='base.group_user')

    def _stripe_request(self, url, data=False, method='POST'):
        self.ensure_one()
        url = urls.url_join(self._get_stripe_api_url(), url)
        headers = {
            'AUTHORIZATION': 'Bearer %s' % self.sudo().stripe_secret_key if self.sudo().state == 'enabled' else self.sudo().stripe_test_secret_key,
            'Stripe-Version': '2019-05-16', # SetupIntent need a specific version
            }
        resp = requests.request(method, url, data=data, headers=headers)
        # Stripe can send 4XX errors for payment failure (not badly-formed requests)
        # check if error `code` is present in 4XX response and raise only if not
        # cfr https://stripe.com/docs/error-codes
        # these can be made customer-facing, as they usually indicate a problem with the payment
        # (e.g. insufficient funds, expired card, etc.)
        # if the context key `stripe_manual_payment` is set then these errors will be raised as ValidationError,
        # otherwise, they will be silenced, and the will be returned no matter the status.
        # This key should typically be set for payments in the present and unset for automated payments
        # (e.g. through crons)
        if not resp.ok and self._context.get('stripe_manual_payment') and (400 <= resp.status_code < 500 and resp.json().get('error', {}).get('code')):
            try:
                resp.raise_for_status()
            except HTTPError:
                _logger.error(resp.text)
                stripe_error = resp.json().get('error', {}).get('message', '')
                error_msg = " " + (_("Stripe gave us the following info about the problem: '%s'", stripe_error))
                raise ValidationError(error_msg)
        return resp.json()


class PaymentTransactionStripe(models.Model):
    _inherit = 'payment.transaction'

    def _get_processing_info(self):
        res = super()._get_processing_info()
        if self.acquirer_id.provider == 'stripe':
            stripe_info = {
                'stripe_payment_intent': self.stripe_payment_intent,
                'stripe_payment_intent_secret': self.stripe_payment_intent_secret,
                'stripe_publishable_key': self.acquirer_id.stripe_publishable_key if self.acquirer_id.state == 'enabled' else self.acquirer_id.stripe_test_publishable_key,
            }
            res.update(stripe_info)
        return res