$(document).ready(function(){
    console.log('page is ready');
    $('#quotation-form>.action-button-disabled').each(function() {
        $(this).prop('disabled', false);
        $(this).removeClass("action-button-disabled");
    });
    $('.quot-details-input').each(function() {
        $(this).prop('disabled', false);
    });
    $('#quot_street2').prop('disabled', false);
});
// function for budget with or without floating point
$('#quot_tender_budget').keyup(function() {
    var input = $(this).val().replaceAll(',', '');
    if (!input == ''){
        var val = parseFloat(input);
        var formatted = currencyFormat(input);
        if (formatted.indexOf('.') > 0) {
            var split = formatted.split('.');
            formatted = split[0] + '.' + split[1].substring(0, 2);
        }
        $(this).val(formatted);
    }
});

function currencyFormat(val) {
    var x = val;
    x = x.toString();
    var afterPoint = '';
    if (x.indexOf('.') > 0)
        afterPoint = x.substring(x.indexOf('.'), x.length);
    x = Math.floor(x);
    x = x.toString();
    var lastThree = x.substring(x.length - 3);
    var otherNumbers = x.substring(0, x.length - 3);
    if (otherNumbers != '')
        lastThree = ',' + lastThree;
    var res = otherNumbers.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + lastThree + afterPoint;
    return res;
}

//$('#quot_tender_budget').keyup(function(event){
//  // skip for arrow keys
//  if(event.which >= 37 && event.which <= 40){
//      event.preventDefault();
//  }
//  var $this = $(this);
//  var num = $this.val().replace(/,/gi, "").split("").reverse().join("");
//
//  var num2 = RemoveRougeChar(num.replace(/(.{3})/g,"$1,").split("").reverse().join(""));
//
//  // the following line has been simplified. Revision history contains original.
//  $this.val(num2);
//})
//
//function RemoveRougeChar(convertString){
//    if(convertString.substring(0,1) == ","){
//        return convertString.substring(1, convertString.length)
//    }
//return convertString;
//}

$("#request_quote").on("click", function(e){
    e.preventDefault();
    var submitLoading = $('#submitLoading');
    var form = $('#quotation-form');
    var input = $('.quot-details-input');
    let is_missing_field = new Boolean(false);
    var validations = [];

    input.each(function() {
        $(this).removeClass("is-invalid is-valid");
        userText = $(this).val().replace(/^\s+/, '').replace(/\s+$/, '');
        inputType = $(this).attr('type');
        name = $(this).attr('name');
        console.log(name);

        if (userText == '') {
            if (inputType == 'tel') {
                $('div#invalid-quot-phone-feedback').text( "Phone number required.");
                $('div#invalid-quot-phone-feedback').css("display","block");
            }
            if (inputType == 'email') {
                $('div#invalid-quot-email-feedback').text("Please enter your email address.");
            }
            if (name === 'quot_tender_budget') {
                $('div#invalid-quot-budget-feedback').text("Please enter the tender's budget.")
                $('div#invalid-quot-budget-feedback').css("display","block");
            }
            $(this).addClass('is-invalid');
            is_missing_field = true;
        }
        else {

            $(this).addClass('is-valid');
            is_missing_field = false;

            if (name === 'quot_tender_budget') {
                var strValue = $(this).val();
                console.log(strValue);
                var floatValue = parseFloat(strValue.replace(/,/g, ''), 10);
                console.log(floatValue);
                if (floatValue <= 0) {
                    $('div#invalid-quot-budget-feedback').text("Budget value should be 1-100000000.");
                    $(this).addClass('is-invalid');
                    $('div#valid-quot-budget-feedback').css("display","none");
                    $('div#invalid-quot-budget-feedback').css("display","block");
                    is_missing_field = true;
                } else {
                    $('div#invalid-quot-budget-feedback').css("display","none");
                    $('div#valid-quot-budget-feedback').css("display","block");
                }
            }

            else if (inputType == 'tel') {
                var telText = $(this).val();
                if (telText.indexOf('-') != -1) {
                    telText.replace('-','');
                }
                if (telText.length != 10) {
                    $('div#invalid-quot-phone-feedback').text("10 digits required.");
                    $(this).addClass('is-invalid');
                    $('div#valid-quot-phone-feedback').css("display","none");
                    $('div#invalid-quot-phone-feedback').css("display","block");
                    is_missing_field = true;
                } else {
                    $('div#invalid-quot-phone-feedback').css("display","none");
                    $('div#valid-quot-phone-feedback').css("display","block");
                }
            }

            else if (inputType == 'email') {
                var emailText = $(this).val();
                if (emailText.indexOf('@') == -1) {
                    $('div#invalid-quot-email-feedback').text("Email address should have '@'.");
                    $(this).addClass('is-invalid');
                    is_missing_field = true;
                }
            }
        }
        validations.push(is_missing_field);
    });

    if (jQuery.inArray(true, validations) === -1) {
        $(this).prop('disabled', true);
        $(this).addClass("action-button-disabled");
        submitLoading.css('display', 'inline-block');
        form.submit();
        $('#quotaion-form>.action-button-disabled').each(function() {
            $(this).prop('disabled', true);
        });
        $('.quot-details-input').each(function() {
            $(this).prop('disabled', true);
        });
        $('#quot_street2').prop('disabled', true);
    }
});

function calculate_price(product_price, tender_value, tenderer_count){
    /*Corrected price= original price + ((project budget x fixed coefficient) / number of tenderer)*/
    const beta = 0.00018750;
    return product_price + ((tender_value*beta)/tenderer_count);
}

function tenderValueOnchange(price){
    var tenderer_count = document.getElementById('quot_tenderer_count');
    var tender_value = document.getElementById('quot_tender_budget');
    document.getElementById('quot_price').value = calculate_price(price, parseFloat(tender_value.value.replace(/,/g, ''), 10), tenderer_count.value).toFixed(2);

}

function tendererCountOnchange(price){
    var tenderer_count = document.getElementById('quot_tenderer_count');
    var tender_value = document.getElementById('quot_tender_budget');
    document.getElementById('quot_price').value = calculate_price(price, parseFloat(tender_value.value.replace(/,/g, ''), 10), tenderer_count.value).toFixed(2);

}