# -*- coding: utf-8 -*-
{
    'name': "hawk_stripe",
    'summary': """Hawk Stripe Module""",
    'description': """
        Custom module implemented for Hawk Stripe Payment Acquirer
    """,
    'author': "Arman Castro | Cuburt Balanon",
    'website': "",
    'category': 'base',
    'version': '0.1',
    'depends': ['payment_stripe', 'sale_management', 'hawk_web', 'partner_firstname'],
    'data': [
        # 'security/ir.model.access.csv',
        'report/sale_report_templates.xml',
        'report/sale_report.xml',
        'report/account_report.xml',
        'report/report_invoice.xml',

        'views/assets.xml',
        'views/safety_page.xml',
        'views/payment_views.xml',
        'views/templates.xml',
        'views/quotation.xml',
        'views/payment_stripe_templates.xml',
        'views/sale_portal_templates.xml',
        'views/sale_views.xml',

        'data/product_data.xml',
        'data/mail_data.xml',
        'data/data.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
    'installable': True,
    'application': False,
}
