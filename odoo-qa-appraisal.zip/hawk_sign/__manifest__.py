{
    'name': "hawk_sign",
    'summary': "Hawk Sign Module",
    'description': """
        Responsible in the NDA signature preview template.
    """,
    'author': "Arman Castro | Cuburt Balanon",
    'website': "",
    'category': 'base',
    'version': '0.1',
    'depends': ['hawk_base',
                'sign',
                'web'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/data.xml',
        'data/team_leader_nda.xml',
        'data/analyst_nda.xml',
        'views/views.xml',
        'views/templates.xml',

    ],
    'demo': [
        # 'demo/demo.xml',
        'demo/users.xml',
    ],
    'installable': True,
    'application': False,
}
