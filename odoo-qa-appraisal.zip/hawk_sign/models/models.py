# -*- coding: utf-8 -*-
import base64
import io

from PyPDF2 import PdfFileReader, PdfFileWriter
from odoo import models, fields, api
from odoo import tools, _
from odoo.exceptions import ValidationError, UserError
# from odoo.addons.sign.wizard.sign_send_request import SignSendRequest
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph


class SignTemplateTypesNDA(models.Model):
    _name = 'sign.template.type'
    _description = 'sign.template.type model'

    name = fields.Char()
    # subname = fields.Char(default=lambda self:self.name.lower())
    is_active = fields.Boolean(default=True)


class SignTemplate(models.Model):
    _inherit = 'sign.template'

    type = fields.Many2one('sign.template.type')


class SignSendRequestSigner(models.TransientModel):
    _inherit = "sign.send.request.signer"
    is_hawk = fields.Boolean(string='Hawk App', default=False, compute='compute_is_hawk')

    def compute_is_hawk(self):
        for rec in self:
            if rec.sign_send_request_id.template_id.name == 'Non-Disclosure Agreement for Analysts.pdf' or rec.sign_send_request_id.template_id.name == 'Non-Disclosure Agreement for Team Leader.pdf':
                self.is_hawk = True
                rec.sign_send_request_id.is_hawk = True


class SignSendRequest(models.TransientModel):
    _inherit = 'sign.send.request'

    # SignSendRequest.default_get = False

    @api.model
    def default_get(self, fields):
        print('default_get')
        res = super(SignSendRequest, self).default_get(fields)
        signer = self.env.user.partner_id

        if self.env.context.get('nda_for_teamleader'):
            if self.env.user.id != self.env.context.get('team_lead_id'):
                raise ValidationError('Sorry only the assigned team leader is allowed to sign the NDA.')
        if self.env.context.get('nda_for_analyst'):
            if self.env.user.id != self.env.context.get('safety_analyst_id'):
                raise ValidationError('Sorry only the assigned analyst is allowed to sign the NDA.')

        try:
            template = self.env['sign.template'].sudo().search([('active', '=', True), ('type.name', '=', signer.function)], limit=1, order='id desc')
            res['signer_id'] = signer.id
            res['template_id'] = template.id
        except Exception as e:
            raise ValidationError(_('Please upload a template for %s.' %(signer.function), str(e)))

        if 'filename' in fields:
            res['filename'] = template.display_name
        if 'subject' in fields:
            res['subject'] = _("Signature Request - %(file_name)s", file_name=template.attachment_id.name)
        if 'signers_count' in fields or 'signer_ids' in fields or 'signer_id' in fields:
            roles = template.sign_item_ids.responsible_id
            if 'signers_count' in fields:
                res['signers_count'] = len(roles)
            if 'signer_ids' in fields:
                res['signer_ids'] = [(0, 0, {
                    'role_id': role.id,
                    'partner_id': False,
                }) for role in roles]
            if self.env.context.get('sign_directly_without_mail'):
                if len(roles) == 1 and 'signer_ids' in fields and res.get('signer_ids'):
                    res['signer_ids'][0][2]['partner_id'] = self.env.user.partner_id.id
                elif not roles and 'signer_id' in fields:
                    res['signer_id'] = self.env.user.partner_id.id
        # print(res['template_id'])
        return res

    def get_companies(self):
        print('get_companies')
        try:
            tenderer_id = self.env.context.get('tenderer_id')
            obj = self.env['hawk.tenderer'].sudo().search([('id', '=', tenderer_id)]).tender_id.tender_manager_id.company_id
        except Exception as e:
            print(str(e))

        try:
            tender_manager_id = self.env.context.get('tender_manager_id')
            obj = self.env['res.users'].sudo().search([('id', '=', tender_manager_id)]).company_id
        except Exception as e:
            print(str(e))
            return False

        return self.env['res.partner'].sudo().search([('is_company', '=', True), ('id', '=', obj.id)]).ids

    def get_template(self):
        print('get_template')
        signer = self.env.user.partner_id
        if self.env.context.get('nda_for_analyst'):
            signer.function = 'Safety Analyst'
        elif self.env.context.get('nda_for_teamleader'):
            signer.function = 'Team Leader'
        return self.env['sign.template'].sudo().search([('active', '=', True),
                                                        ('type.name', '=', signer.function)], limit=1, order='id desc')

    # signer_id = fields.Many2one('res.partner', string="Send To")
    follower_ids = fields.Many2many('res.partner', string="Copy to", default=get_companies)
    template_id = fields.Many2one('sign.template', required=True, ondelete='cascade', default=get_template)
    filename = fields.Char("Filename", required=True)
    is_hawk = fields.Boolean(string='Hawk App 1')

    def sign_directly_without_mail(self):
        print('sign_directly_without_mail')
        res = self.create_request(False, True)
        request = self.env['sign.request'].browse(res['id'])
        user_item = request.request_item_ids[0]

        if self.env.context.get('nda_for_teamleader'):
            print('nda_for_teamleader')
            if self.env.user.id != self.env.context.get('team_lead_id'):
                raise ValidationError('Sorry only the assigned team leader can sign this document.')

        if self.env.context.get('nda_for_analyst'):
            print('nda_for_analyst')
            if self.env.user.id != self.env.context.get('safety_analyst_id'):
                raise ValidationError('Sorry only the assigned analyst can sign this document.')

        return {
            'type': 'ir.actions.client',
            'tag': 'sign.SignableDocument',
            'name': _('Sign'),
            'context': {
                'id': request.id,
                'token': user_item.access_token,
                'sign_token': user_item.access_token,
                'create_uid': request.create_uid.id,
                'state': request.state,
                # Don't use mapped to avoid ignoring duplicated signatories
                'token_list': [item.access_token for item in request.request_item_ids[1:]],
                'current_signor_name': user_item.partner_id.name,
                'name_list': [item.partner_id.name for item in request.request_item_ids[1:]],
            },
        }

def _fix_image_transparency(image):
    """ Modify image transparency to minimize issue of grey bar artefact.

    When an image has a transparent pixel zone next to white pixel zone on a
    white background, this may cause on some renderer grey line artefacts at
    the edge between white and transparent.

    This method sets transparent pixel to white transparent pixel which solves
    the issue for the most probable case. With this the issue happen for a
    black zone on black background but this is less likely to happen.
    """
    pixels = image.load()
    for x in range(image.size[0]):
        for y in range(image.size[1]):
            if pixels[x, y] == (0, 0, 0, 0):
                pixels[x, y] = (255, 255, 255, 0)


class SignRequest(models.Model):
    _inherit = 'sign.request'

    analysis_id = fields.Many2one('hawk.analysis')
    tender_id = fields.Many2one('hawk.tender')

    @api.model
    def initialize_new(self, id, signers, followers, reference, subject, message, send=True, without_mail=False, analysis=None, reportLog=None):
        print('initialize_new')
        try:
            template = self.env['sign.template'].sudo().search([('id', '=', id)])
            values = {'template_id': template.id, 'reference': reference}

            if analysis:
                values.update({'analysis_id': analysis.id})

            elif self.env.context.get('nda_for_analyst'):
                analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
                values.update({'analysis_id': analysis.id})

            elif self.env.context.get('nda_for_teamleader'):
                tender = self.env['hawk.tender'].browse(self.env.context.get('active_ids'))
                values.update({'tender_id': tender.id})

            sign_users = self.env['res.users'].search(
                [('partner_id', 'in', [signer['partner_id'] for signer in signers])]).filtered(
                lambda u: u.has_group('sign.group_sign_employee'))

            sign_request = self.create(values)
            sign_request.message_subscribe(partner_ids=followers)
            sign_request.activity_update(sign_users)
            sign_request.set_signers(signers)

            if reportLog:
                reportLog.sign_request_id = sign_request
            if send:
                sign_request.action_sent(subject, message)
            if without_mail:
                sign_request.action_sent_without_mail()

            return {
                'id': sign_request.id,
                'token': sign_request.access_token,
                'sign_token': sign_request.request_item_ids.filtered(lambda r: r.partner_id == self.env.user.partner_id)[:1].access_token,
            }
        except Exception as e:
            raise ValidationError(_(str(e)))

    @api.model
    def action_signed(self):
        print('action_signed')
        self.write({'state': 'signed'})

        if self.template_id.name == 'Non-Disclosure Agreement for Team Leader.pdf':
            tender = self.env['hawk.tender'].browse(self.tender_id.id)

            # Alerts
            odoobot = self.env.ref('base.partner_root')
            tender.message_post(
                subject='Sign NDA',
                body=tender.team_lead_id.name + ' signed the NDA.',
                message_type='comment',
                notify_by_email=False,
                author_id=odoobot.id,
                partner_ids=[4, tender.tender_manager_id.partner_id.id])

            tender.write({
                'state': 'analysis',
                'is_sign_nda': True,
            })
            self.action_send_email_notification('sign_nda_tl_template')
            return {}

        if self.template_id.name == 'Non-Disclosure Agreement for Analysts.pdf':
            analysis = self.env['hawk.analysis'].browse(self.analysis_id.id)
            vals = [{
                'analysis_id': analysis.id,
                'details': 'Accept & Sign',
                'date': fields.Datetime.now(),
                'res_person_id': analysis.safety_analyst_id.id,
                'remarks': analysis.safety_analyst_id.name + ' accepted the task and signed the NDA.',
            }]
            analysis.analysis_timeline_ids.create(vals)

            # Alerts
            odoobot = self.env.ref('base.partner_root')
            analysis.message_post(
                subject='Sign NDA',
                body=analysis.safety_analyst_id.name + ' signed the NDA.',
                message_type='comment',
                notify_by_email=False,
                author_id=odoobot.id,
                partner_ids=[4, analysis.team_leader_id.partner_id.id])

            analysis.write({
                'state': 'analysis',
                'hide_new_btn': False,
                'hide_resume_btn': True,
                'hide_submit_btn': True,
            })
            self.action_send_email_notification('accept_by_analyst_template', 'analysis', analysis)
            return {}

        self.env.cr.commit()
        if not self.check_is_encrypted():
            # if the file is encrypted, we must wait that the document is decrypted
            self.send_completed_document()

    def action_send_email_notification(self, template, criteria=None, new_id=None):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        if criteria == 'analysis':
            url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(new_id.id)
            self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(new_id.id, force_send=True)
        else:
            url = base_url + '/web#id={}&model=hawk.tender&view_type=form'.format(self.tender_id.id)
            self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(self.tender_id.id, force_send=True)


class Analysis(models.Model):
    _inherit = 'hawk.analysis'

    def write(self, vals):
        if vals and 'state' in vals and vals.get('state'):
            # if self.analysis_type_id.name.lower() ==  'safety':
            try:
                field = self.analysis_type_id.name.lower()+'_state'
                self.tenderer_id[field] = vals.get('state')
            except Exception as e:
                print(str(e))
            # if self.analysis_type ==  'quality':
            #     self.tenderer_id.quality_state = vals.get('state')
            # if self.analysis_type ==  'health':
            #     self.tenderer_id.health_state = vals.get('state')
            # if self.analysis_type ==  'environment':
            #     self.tenderer_id.environment_state = vals.get('state')
        return super(Analysis, self).write(vals)


class User(models.Model):
    _inherit = 'res.users'

    sign_signature = fields.Binary(string="Digital Signature", groups="hawk_base.group_hawk_analyst")
    sign_initials = fields.Binary(string="Digitial Initials", groups="hawk_base.group_hawk_analyst")


class Company(models.Model):
    _inherit = 'res.company'

    complete_name = fields.Char(compute='_get_complete_name')
    sign_complete_address = fields.Char(compute='_get_complete_address')
    sign_custom_address = fields.Char(compute='_get_custom_address')
    sign_street_address = fields.Char(compute='_get_street_address')
    sign_region_address = fields.Char(compute='_get_region_address')

    @api.depends('name', 'ab_number')
    def _get_complete_name(self):
        self.complete_name = False
        for rec in self:
            rec.complete_name = '%s (%s)' % (
                rec.name if rec.name else '',
                rec.ab_number if rec.ab_number else '')

    @api.depends('street', 'street2', 'city', 'state_id', 'zip', 'country_id')
    def _get_complete_address(self):
        self.sign_complete_address = False
        for rec in self:
            rec.sign_complete_address = '%s %s %s %s %s %s' % (
                rec.street if rec.street else '',
                rec.street2 if rec.street2 else '',
                rec.city if rec.city else '',
                rec.state_id.name if rec.state_id else '',
                rec.zip if rec.zip else '',
                rec.country_id.name if rec.country_id else '')

    @api.depends('street', 'street2', 'city', 'state_id', 'zip', 'country_id')
    def _get_street_address(self):
        self.sign_street_address = False
        for rec in self:
            rec.sign_street_address = '%s %s' % (
                rec.street if rec.street else '',
                rec.street2 if rec.street2 else '')

    @api.depends('state_id','country_id', 'zip')
    def _get_region_address(self):
        self.sign_region_address = False
        for rec in self:
            rec.sign_region_address = '%s %s %s' % (
                rec.state_id.name if rec.state_id.name else '',
                rec.country_id.name if rec.country_id else '',
                rec.zip if rec.zip else '')

    @api.depends('state_id', 'country_id')
    def _get_custom_address(self):
        self.sign_custom_address = False
        for rec in self:
            rec.sign_custom_address = 'the state of %s in %s' % (
                rec.state_id.name if rec.state_id.name else '',
                rec.country_id.name if rec.country_id else '')


class Partner(models.Model):
    _inherit = 'res.partner'

    office_address = fields.Char(compute='_get_address', store=True)

    @api.depends('street', 'street2', 'city', 'state_id', 'zip', 'country_id')
    def _get_address(self):
        self.sudo().office_address = False
        for rec in self.sudo():
            rec.sudo().office_address = '%s %s %s %s %s %s' % (
                rec.sudo().street if rec.sudo().street else '',
                rec.sudo().street2 if rec.sudo().street2 else '',
                rec.sudo().city if rec.sudo().city else '',
                rec.sudo().state_id.name if rec.sudo().state_id else '',
                rec.sudo().zip if rec.sudo().zip else '',
                rec.sudo().country_id.name if rec.sudo().country_id else '')

