# -*- coding: utf-8 -*-
# from odoo import http


# class HawkSign(http.Controller):
#     @http.route('/hawk_sign/hawk_sign/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hawk_sign/hawk_sign/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('hawk_sign.listing', {
#             'root': '/hawk_sign/hawk_sign',
#             'objects': http.request.env['hawk_sign.hawk_sign'].search([]),
#         })

#     @http.route('/hawk_sign/hawk_sign/objects/<model("hawk_sign.hawk_sign"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hawk_sign.object', {
#             'object': obj
#         })
