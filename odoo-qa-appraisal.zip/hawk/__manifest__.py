{
    'name': "Hawk",
    'summary': "Project Hawk",
    'description': """ 
        The main application.
    """,
    'author': "Arman Castro | Cuburt Balanon",
    'website': "",
    'category': 'base',
    'version': '0.1',
    'depends': ['hawk_base',
                'hawk_web',
                'hawk_sign',
                'hawk_survey',
                'hawk_report'],
    'images': ['static/description/icon.png'],
    'qweb': [],
    'data': [
        # 'security/security.xml',
        # 'security/ir.model.access.csv',
        'views/menu_views.xml',
    ],
    'demo': [],
    'installable': True,
    'application': True,
}
