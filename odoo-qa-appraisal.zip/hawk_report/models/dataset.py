from odoo import tools, _
from odoo import api, fields, models
from odoo.tools.image import image_data_uri
from odoo.exceptions import ValidationError, UserError
import logging
import re

_logger = logging.getLogger(__name__)


CLEANR = re.compile('<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});')

def cleanhtml(raw_html):
    cleantext = re.sub(CLEANR, '', raw_html)
    return cleantext

def generate_dictvalue(cat_sequence, category, weight, sequence, question, answer, score, is_page, heading=None):
    return {'category_sequence': cat_sequence,
            'category': category,
            'weight': weight,
            'sequence': sequence,
            'question': question,
            'answer': answer,
            'score': score,
            'is_page': is_page,
            'heading': heading}


class Analysis(models.Model):
    _inherit = 'hawk.analysis'

    # IMPROVEMENT: use tree traversal method such as depth-first search, instead of the current linear search method
    def get_values(self, analysis_id, reportChangeLog_id):
        try:

            values = []
            graph_values = []

            # get analysis record
            analysis = self.sudo().search([('id', '=', analysis_id)])
            partner = analysis[str(analysis.analysis_type_id.name.lower() + '_analyst_id')].partner_id
            if partner.survey_user_input_ids:
                for survey_input in partner.survey_user_input_ids:
                    if survey_input.survey_id.id == analysis.survey_id.id:

                        head_value = False # current index in the survey
                        head_values = [] # list of indeces
                        main_header = False
                        header = False
                        header_copy = False
                        category = False

                        # for each record in the target survey
                        for page_or_question in survey_input.survey_id.question_and_page_ids:
                            value = False

                            if page_or_question.is_page:

                                chapter_list = [int(s) for s in re.findall(r'\b\d+\b', cleanhtml(page_or_question.title))]
                                _logger.info(str(chapter_list))
                                if page_or_question.category_id or len(
                                        chapter_list) == 1:  # only main headers have category_id
                                    _logger.info('PATH 1')
                                    if page_or_question.category_id:
                                        _logger.info('PATH 1.1')
                                        category = page_or_question.category_id
                                    else:
                                        _logger.info('PATH 1.2')
                                        for cat in self.env['survey.question.category'].sudo().search([]):
                                            _logger.info(cat.name.lower())
                                            _logger.info(str([s.lower().replace('.', '') for s in
                                                              cleanhtml(page_or_question.title).split()]))
                                            if cat and cat.name.lower() in [s.lower().replace('.', '') for s in
                                                              cleanhtml(page_or_question.title).split()]:

                                                category = cat
                                                page_or_question.category_id = cat
                                                break

                                    main_header = page_or_question

                                elif category:
                                    _logger.info('PATH 2')
                                    category = category

                                    if not header:
                                        page_or_question.parent_id = main_header

                                    else:
                                        page_or_question.parent_id = header


                                    page_or_question.category_id = False
                                    header = page_or_question
                                    header_copy = header

                                else:
                                    _logger.info('PATH 3')
                                    raise ValidationError(
                                        _('No category: Please contact Site Administrator.'))

                                _logger.info('CATEGORY: ' + category.name)
                                value = generate_dictvalue(category.sequence, category.name, False,
                                                           page_or_question.sequence,
                                                           cleanhtml(page_or_question.title), False, False, True,
                                                           len(chapter_list))

                                # store value in head_value, then append value to values list to preserve index pox.
                                head_value = value

                            elif not page_or_question.is_page:

                                if header:
                                    page_or_question.parent_id = header
                                elif header_copy:
                                    page_or_question.parent_id = header_copy
                                elif main_header:  # ignores this condition if a subheader exists
                                    page_or_question.parent_id = main_header
                                for line in survey_input.user_input_line_ids:
                                    for weight in analysis.weight_ids:

                                        if category.id == weight.category_id.id \
                                                and line.question_id.id == page_or_question.id:
                                            answer = " ".join(self.env['survey.question.answer'].sudo().search(
                                                [('id', '=', line.suggested_answer_id.id),
                                                 ('question_id.id', '=', line.question_id.id)]).value.split())
                                            value = generate_dictvalue(weight.category_id.sequence,
                                                                       weight.category_id.name,
                                                                       weight.weight, line.question_id.sequence,
                                                                       cleanhtml(line.question_id.title), answer,
                                                                       line.answer_score, False)
                                            graph_values.append(value)
                                            page_or_question.answer_score = line.answer_score

                                header = False

                            if page_or_question.parent_id:  # must for subheaders and questions
                                page_or_question.parent_id.answer_score = sum(
                                    [page.answer_score for page in page_or_question.parent_id.child_ids])

                            # if value is not empty.
                            if value:
                                values.append(value)
                                if head_value:
                                    head_values.append(head_value)

                        for header in reversed(survey_input.survey_id.page_ids):
                            if header.child_ids:
                                header.answer_score = sum([page.answer_score for page in header.child_ids])

                        # finds the head_value equivalent in the values list then updates the score attribute.
                        for head_value in head_values:
                            for page_or_question in survey_input.survey_id.question_and_page_ids:
                                if page_or_question.is_page and page_or_question.sequence == head_value['sequence']:
                                    value = next(
                                        (value for value in values if value["sequence"] == head_value['sequence']),
                                        None)
                                    value['score'] = page_or_question.answer_score

            if graph_values and values:
                new_values = []
                mainHeaders = [value for value in values if value['heading']==1]
                for headerIndex in range(len(mainHeaders)):
                    nextHeaderValue = False
                    currentHeaderValue = mainHeaders[headerIndex]
                    try:
                        nextHeaderValue = mainHeaders[headerIndex+1]
                    except:
                        _logger.info('No more main headers')
                    temp_values = [value for value in values if (not nextHeaderValue and value['sequence'] >= currentHeaderValue['sequence']) or  (nextHeaderValue and (value['sequence'] >= currentHeaderValue['sequence'] and value['sequence'] < nextHeaderValue['sequence']))]
                    for index, value in enumerate(temp_values):
                        value['index'] = index
                    new_values.append(temp_values)
                return {'dataframes': self.generate_graph(graph_values, reportChangeLog_id), 'values': new_values}

            else:
                raise ValidationError(
                    _('Sorry, there has been an error while processing your questionnaire. '
                      'Please contact Site Administrator.'))

        except Exception as e:
            raise ValidationError(_('Error in get_values() ' + str(e)))
