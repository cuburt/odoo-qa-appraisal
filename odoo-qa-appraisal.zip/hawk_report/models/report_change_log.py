# -*- coding: utf-8 -*-
from odoo import tools, _
from odoo import api, fields, models
from odoo.exceptions import ValidationError, UserError
import base64
from slugify import slugify
import logging

_logger = logging.getLogger(__name__)


class ReportChangeLog(models.Model):
    _name = 'hawk.analysis.report.log'
    _description = "Report Change Log"

    analysis_id = fields.Many2one('hawk.analysis', 'Analysis')
    sign_request_id = fields.Many2one('sign.request', 'Report Attachment')
    editor_id = fields.Many2one('res.users', 'Editor', default=lambda self:self.env.user)
    remarks = fields.Text('Remarks')
    datetime = fields.Datetime('Date & Time', default=fields.Datetime.now())
    executive_summary = fields.Html(string='Executive Summary')
    assessment_context = fields.Html(string='Assessment Context')
    results_analysis_context_1 = fields.Html(string='Results Analysis')
    img_weight_count_bar_large = fields.Binary(attachment=True)
    results_analysis_context_2_intro = fields.Html(string='Considered Weighting Coefficient')
    results_analysis_context_2_content = fields.Html(string='Second Context')
    img_mean_score_bar_large = fields.Binary(attachment=True)
    results_analysis_context_3_intro = fields.Html(string='Average Raw Mark per Category')
    results_analysis_context_3_content = fields.Html(string='Third Context')
    img_weighted_mean_score_bar_large = fields.Binary(attachment=True)
    results_analysis_context_4_intro = fields.Html(string='Average Corrected Mark per Category')
    results_analysis_context_4_content = fields.Html(string='Fourth Context')
    img_mean_raw_mark_pie = fields.Binary(attachment=True)
    img_weighted_mean_raw_mark_pie = fields.Binary(attachment=True)
    results_analysis_context_5_intro = fields.Html(string='Total Score Share for Tenderer')
    results_analysis_context_5_content = fields.Html(string='Fifth Context')
