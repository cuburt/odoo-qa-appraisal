# -*- coding: utf-8 -*-
from odoo import tools, _
from odoo import api, fields, models
from odoo.exceptions import ValidationError, UserError
import base64
from slugify import slugify
import logging

_logger = logging.getLogger(__name__)


class ReportContent(models.Model):
    _name = 'report.content'
    _description = "Report Content"

    config_id = fields.Many2one('hawk.analysis.config')
    section = fields.Selection([('disclaimer','Disclaimer'),
                                ('copyright','Copyright'),
                                ('opening','Executive Summary [Opening]'),
                                ('closing', 'Executive Summary [Closing]'),
                                ('assessment_context', 'Assessment Context'),
                                ('results_glance', 'Results At A Glance'),
                                ('results_analysis', 'Results Analysis'),
                                ('results_analysis_bar1_top', 'Results Analysis [Considered Weighting Coefficient (Top)]'),
                                ('results_analysis_bar1_bottom', 'Results Analysis [Considered Weighting Coefficient (Bottom)]'),
                                ('results_analysis_bar2_top', 'Results Analysis [Average Raw Mark Per Category (Top)]'),
                                ('results_analysis_bar2_bottom', 'Results Analysis [Average Raw Mark Per Category (Bottom)]'),
                                ('results_analysis_bar3_top', 'Results Analysis [Average Corrected Mark Per Category (Top)]'),
                                ('results_analysis_bar3_bottom', 'Results Analysis [Average Corrected Mark Per Category (Bottom)]'),
                                ('total_score_share_top', 'Results Analysis [Total Score Share For Tenderer (Top)]'),
                                ('total_score_share_bottom', 'Results Analysis [Total Score Share For Tenderer (Bottom)]'),
                                ('score_methodology', 'Score Methodology'),
                                ('assessment_criteria', 'Assessment Criteria'),
                                ('tnc', 'Terms and Conditions')
                                ])
    summary = fields.Html()
    min_score = fields.Float()
    max_score = fields.Float()
    min_keyword = fields.Char()
    max_keyword = fields.Char()
    repeat_headers = fields.Boolean(default=False)


class ExecutiveSummaryContent(models.Model):
    _name = 'executive.summary'
    _description = 'Executive summaries'

    config_id = fields.Many2one('hawk.analysis.config')
    category_id = fields.Many2one('survey.question.category')
    summary = fields.Html()
    min_score = fields.Float()
    max_score = fields.Float()


class ReportTemplateComponent(models.Model):
    _name = 'hawk.analysis.report.template.component'

    name = fields.Char()
    qweb_keyword = fields.Char(description='This component will be referred with this word in the qweb template')
    image = fields.Image(max_width=1920, max_height=1920, attachment=True) #TODO: Odoo 14 now has fields.Image. Replace binary with image
    template_id = fields.Many2one('hawk.analysis.report.template')
    is_static = fields.Boolean(default=False, description='If static, files will be retrieved from the file system. Else, from database')


class ReportTemplate(models.Model):
    _name = 'hawk.analysis.report.template'

    name = fields.Char('Description')
    datetime = fields.Datetime(default=fields.Datetime.now())
    component_ids = fields.One2many('hawk.analysis.report.template.component', 'template_id')
    report_type_id = fields.Many2one('hawk.analysis.type')
    report_type = fields.Char(related='report_type_id.name')


class ContentConfig(models.Model):
    _name = 'hawk.analysis.config'
    _description = 'Configuration for analysis contents'

    def get_template_id(self):
        return self.env['hawk.analysis.report.template'].search([('report_type','=','Safety')]).id

    name = fields.Char('Description')
    datetime = fields.Datetime(default=fields.Datetime.now())
    template_id = fields.Many2one('hawk.analysis.report.template', default=lambda self:self.get_template_id(), required=True)
    template_type = fields.Char(related='template_id.report_type')
    report_type_id = fields.Many2one('hawk.analysis.type', related='template_id.report_type_id')
    analysis_ids = fields.One2many('hawk.analysis', 'config_id')
    summary_ids = fields.One2many('executive.summary', 'config_id')
    section_ids = fields.One2many('report.content', 'config_id')
    is_active = fields.Boolean(default=True)
    is_default = fields.Boolean(default=False)

    def activate_config(self):
        config_id = self.env.context.get('config_id')
        config = self.sudo().search([('id','=', config_id)])
        config.is_active = True

    def deactivate_config(self):
        config_id = self.env.context.get('config_id')
        config = self.sudo().search([('id', '=', config_id)])
        config.is_active = False

    @api.model
    def inactivate_report_config(self):
        for config in self.sudo().search([]):
            config.is_active = False
        self.delete_report_config()

    @api.model
    def delete_report_config(self):
        for summary in self.env['executive.summary'].sudo().search([('config_id','=',None)]):
            summary.sudo().unlink()
        for section in self.env['report.content'].sudo().search([('config_id','=',None)]):
            section.sudo().unlink()

    def get_report_template_component(self, analysis):
        _logger.info('retrieving template components...')
        config = self.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(
                _('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id', '=', analysis.id)]).config_id.sudo().search(
                [('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        components = {}
        for component in config.template_id.component_ids:
            # _logger.info('appending key: ' + component.qweb_keyword + ' value: ' + str(component.image))
            components[str(component.qweb_keyword)] = component.image
            components[str(component.qweb_keyword) + '_is_static'] = component.is_static

        return components

    def parse_html_string(self, min_value, max_value, summary, section):
        try:
            max_keyword = section.max_keyword
            max_keyword = max_keyword.replace('&', '&amp;')
            max_keyword = max_keyword.replace('"', '&quot;')
            max_keyword = max_keyword.replace('\'', '&apos;')
            max_keyword = max_keyword.replace('>', '&gt;')
            max_keyword = max_keyword.replace('<', '&lt;')

            min_keyword = section.min_keyword
            min_keyword = min_keyword.replace('&', '&amp;')
            min_keyword = min_keyword.replace('"', '&quot;')
            min_keyword = min_keyword.replace('\'', '&apos;')
            min_keyword = min_keyword.replace('>', '&gt;')
            min_keyword = min_keyword.replace('<', '&lt;')

            temp_summary = section.summary

            temp_summary = str(temp_summary).replace(min_keyword, min_value)
            temp_summary = str(temp_summary).replace(max_keyword, max_value)
            summary += temp_summary
        except:
            summary = section.summary

        return summary

    def get_disclaimer(self, analysis):
        _logger.info('generating disclaimer...')
        config = self.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(
                _('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id', '=', analysis.id)]).config_id.sudo().search(
                [('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        assessment = config.section_ids.search([('section', '=', 'disclaimer'), ('config_id', '=', config.id)])
        summary = ''
        summary += assessment.summary
        return summary

    def get_copyright(self, analysis):
        _logger.info('generating copyright statement...')
        config = self.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(
                _('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id', '=', analysis.id)]).config_id.sudo().search(
                [('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        assessment = config.section_ids.search([('section', '=', 'copyright'), ('config_id', '=', config.id)])
        summary = ''
        summary += assessment.summary
        return summary

    #use this function to get executive summary
    def get_executive_summary(self, analysis, df_mean_raw_mark):
        _logger.info('generating executive summary...')
        config = self.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        summary = ''
        print('creating content...')
        ave_mean_value = round(df_mean_raw_mark.sum().values[0] / 7, 3)
        print('AVE MEAN VAL:', ave_mean_value)
        summary += config.section_ids.search([('section', '=', 'opening'), ('config_id','=', config.id),
                                                    ('min_score', '<=', ave_mean_value),
                                                    ('max_score', '>=', ave_mean_value)]).summary
        for category in df_mean_raw_mark.index:

            mean_value = round(df_mean_raw_mark.loc[df_mean_raw_mark.index==category]['mean'].values[0], 3)
            summary += config.summary_ids.search([('category_id.name','=',category), ('config_id','=', config.id),
                                                       ('min_score','<=',mean_value),
                                                       ('max_score','>=',mean_value)]).summary

        summary += config.section_ids.search([('section', '=', 'closing'), ('config_id','=', config.id),
                                                    ('min_score', '<=', ave_mean_value),
                                                    ('max_score', '>=', ave_mean_value)]).summary
        print('SUMMARY: ', summary)
        return summary

    def get_assessment_context(self, analysis):
        _logger.info('generating assessment context...')
        config = self.sudo().search([('is_active','=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        summary = ''
        summary += config.section_ids.search([('section', '=', 'assessment_context'),('config_id','=', config.id)]).summary
        return summary

    def get_results_glance(self, analysis):
        _logger.info('generating results in a glance...')
        config = self.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        summary = ''
        summary += config.section_ids.search([('section', '=', 'results_glance'), ('config_id','=', config.id)]).summary
        return summary

    def get_score_methodology(self, analysis):
        _logger.info('generating score methodology...')
        config = self.sudo().search([('is_active','=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        summary = ''
        summary += config.section_ids.search([('section', '=', 'score_methodology'), ('config_id','=', config.id)]).summary
        return summary

    def get_results_analysis_context_1(self, analysis):
        _logger.info('generating ctx 1 ctn...')
        config = self.sudo().search([('is_active','=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        summary = ''
        summary += config.section_ids.search([('section', '=', 'results_analysis'), ('config_id','=', config.id)]).summary
        return summary

    def get_results_analysis_context_2_intro(self, analysis, df_coeff_count):
        _logger.info('generating ctx 2 intro...')
        config = self.sudo().search([('is_active','=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        summary = ''
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        print(df_coeff_count.loc[df_coeff_count['max'] == df_coeff_count['max'].max()].index.values[0])
        try:
            max_value = df_coeff_count.loc[df_coeff_count['max']==df_coeff_count['max'].max()].index.values[0]
            min_value = df_coeff_count.loc[df_coeff_count['max']==df_coeff_count['max'].min()].index.values[0]
            section = config.section_ids.search([('section', '=', 'results_analysis_bar1_top'), ('config_id','=', config.id)])
            summary = self.parse_html_string(min_value, max_value, summary, section)
        except Exception as e:
            _logger.error('get_results_analysis_context_2_intro '+str(e))
            summary = ''
        return summary

    def get_results_analysis_context_2_content(self, analysis, df_coeff_count):
        _logger.info('generating ctx 2 ctn...')
        config = self.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        summary = ''
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id', '=', analysis.id)]).config_id.sudo().search(
                [('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        print(df_coeff_count.loc[df_coeff_count['max'] == df_coeff_count['max'].max()].index.values[0])
        try:

            max_value = df_coeff_count.loc[df_coeff_count['max'] == df_coeff_count['max'].max()].index.values[0]
            min_value = df_coeff_count.loc[df_coeff_count['max'] == df_coeff_count['max'].min()].index.values[0]
            section = config.section_ids.search([('section', '=', 'results_analysis_bar1_bottom'), ('config_id','=', config.id)])
            summary = self.parse_html_string(min_value, max_value, summary, section)
        except Exception as e:
            _logger.error('get_results_analysis_context_2_content ' + str(e))
            summary = ''
        return summary

    def get_results_analysis_context_3_intro(self, analysis, df_mean_raw_mark):
        _logger.info('generating ctx 3 intro...')
        config = self.sudo().search([('is_active','=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        summary = ''
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        print(df_mean_raw_mark.loc[df_mean_raw_mark['mean'] == df_mean_raw_mark['mean'].max()].index.values[0])
        try:
            max_value = df_mean_raw_mark.loc[df_mean_raw_mark['mean']==df_mean_raw_mark['mean'].max()].index.values[0]
            min_value = df_mean_raw_mark.loc[df_mean_raw_mark['mean']==df_mean_raw_mark['mean'].min()].index.values[0]
            section = config.section_ids.search([('section', '=', 'results_analysis_bar2_top'), ('config_id','=', config.id)])
            summary = self.parse_html_string(min_value, max_value, summary, section)
        except Exception as e:
            _logger.error('get_results_analysis_context_3_intro '+str(e))
            summary = ''
        return summary

    def get_results_analysis_context_3_content(self, analysis, df_mean_raw_mark):
        _logger.info('generating ctx 3 ctn...')
        config = self.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        summary = ''
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id', '=', analysis.id)]).config_id.sudo().search(
                [('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        print(df_mean_raw_mark.loc[df_mean_raw_mark['mean'] == df_mean_raw_mark['mean'].max()].index.values[0])
        try:

            max_value = df_mean_raw_mark.loc[df_mean_raw_mark['mean'] == df_mean_raw_mark['mean'].max()].index.values[0]
            min_value = df_mean_raw_mark.loc[df_mean_raw_mark['mean'] == df_mean_raw_mark['mean'].min()].index.values[0]
            section = config.section_ids.search([('section', '=', 'results_analysis_bar2_bottom'), ('config_id','=', config.id)])
            summary = self.parse_html_string(min_value, max_value, summary, section)
        except Exception as e:
            _logger.error('get_results_analysis_context_3_content ' + str(e))
            summary = ''
        return summary

    def get_results_analysis_context_4_intro(self, analysis, df_correlated_mark):
        _logger.info('generating ctx 4 intro...')
        config = self.sudo().search([('is_active','=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        summary = ''
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        print(df_correlated_mark.loc[df_correlated_mark['mean'] == df_correlated_mark['mean'].max()].index.values[0])
        try:
            max_value = df_correlated_mark.loc[df_correlated_mark['mean']==df_correlated_mark['mean'].max()].index.values[0]
            min_value = df_correlated_mark.loc[df_correlated_mark['mean']==df_correlated_mark['mean'].min()].index.values[0]
            section = config.section_ids.search([('section', '=', 'results_analysis_bar3_top'), ('config_id','=', config.id)])
            summary = self.parse_html_string(min_value, max_value, summary, section)
        except Exception as e:
            _logger.error('get_results_analysis_context_4_intro '+str(e))
            summary = ''
        return summary

    def get_results_analysis_context_4_content(self, analysis, df_correlated_mark):
        _logger.info('generating ctx 4 ctn...')
        config = self.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        summary = ''
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id', '=', analysis.id)]).config_id.sudo().search(
                [('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        print(df_correlated_mark.loc[df_correlated_mark['mean'] == df_correlated_mark['mean'].max()].index.values[0])
        try:

            max_value = df_correlated_mark.loc[df_correlated_mark['mean'] == df_correlated_mark['mean'].max()].index.values[0]
            min_value = df_correlated_mark.loc[df_correlated_mark['mean'] == df_correlated_mark['mean'].min()].index.values[0]
            section = config.section_ids.search([('section', '=', 'results_analysis_bar3_bottom'), ('config_id','=', config.id)])
            summary = self.parse_html_string(min_value, max_value, summary, section)
        except Exception as e:
            _logger.error('get_results_analysis_context_4_content ' + str(e))
            summary = ''
        return summary

    def get_results_analysis_context_5_intro(self, analysis, df_cumulative_raw_mark):
        _logger.info('generating ctx 4 intro...')
        config = self.sudo().search([('is_active','=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        summary = ''
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        print(df_cumulative_raw_mark.loc[df_cumulative_raw_mark['mean'] == df_cumulative_raw_mark['mean'].max()].index.values[0])
        try:
            max_value = df_cumulative_raw_mark.loc[df_cumulative_raw_mark['mean']==df_cumulative_raw_mark['mean'].max()].index.values[0]
            min_value = df_cumulative_raw_mark.loc[df_cumulative_raw_mark['mean']==df_cumulative_raw_mark['mean'].min()].index.values[0]
            section = config.section_ids.search([('section', '=', 'total_score_share_top'), ('config_id','=', config.id)])
            summary = self.parse_html_string(min_value, max_value, summary, section)
        except Exception as e:
            _logger.error('get_results_analysis_context_5_intro '+str(e))
            summary = ''
        return summary

    def get_results_analysis_context_5_content(self, analysis, df_cumulative_weighted_mark):
        _logger.info('generating ctx 4 ctn...')
        config = self.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        summary = ''
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id', '=', analysis.id)]).config_id.sudo().search(
                [('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        print(df_cumulative_weighted_mark.loc[df_cumulative_weighted_mark['mean'] == df_cumulative_weighted_mark['mean'].max()].index.values[0])
        try:

            max_value = df_cumulative_weighted_mark.loc[df_cumulative_weighted_mark['mean'] == df_cumulative_weighted_mark['mean'].max()].index.values[0]
            min_value = df_cumulative_weighted_mark.loc[df_cumulative_weighted_mark['mean'] == df_cumulative_weighted_mark['mean'].min()].index.values[0]
            section = config.section_ids.search([('section', '=', 'total_score_share_bottom'), ('config_id','=', config.id)])
            summary = self.parse_html_string(min_value, max_value, summary, section)
        except Exception as e:
            _logger.error('get_results_analysis_context_5_content ' + str(e))
            summary = ''
        return summary

    def get_assessment_criteria(self, analysis):
        _logger.info('generating assessment criteria...')
        config = self.sudo().search([('is_active','=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        analysis = analysis.sudo()
        summary = ''
        if len(config) > 1:
            raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
        if self.analysis_ids and analysis:
            config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
        section = config.section_ids.search([('section', '=', 'assessment_criteria'), ('config_id','=', config.id)])
        try:
            max_keyword = section.max_keyword
            max_keyword = max_keyword.replace('&', '&amp;')
            max_keyword = max_keyword.replace('"', '&quot;')
            max_keyword = max_keyword.replace('\'', '&apos;')
            max_keyword = max_keyword.replace('>', '&gt;')
            max_keyword = max_keyword.replace('<', '&lt;')

            min_keyword = section.min_keyword
            min_keyword = min_keyword.replace('&', '&amp;')
            min_keyword = min_keyword.replace('"', '&quot;')
            min_keyword = min_keyword.replace('\'', '&apos;')
            min_keyword = min_keyword.replace('>', '&gt;')
            min_keyword = min_keyword.replace('<', '&lt;')

            temp_summary = section.summary

            temp_summary = str(temp_summary).replace(min_keyword, analysis.tenderer_id.tender_id.reference)
            temp_summary = str(temp_summary).replace(max_keyword, analysis.tenderer_id.tender_id.reference)
            summary += temp_summary
        except:
            summary = section.summary
        return summary, section.repeat_headers

    # def get_terms_and_conditions(self, analysis):
    #     _logger.info('generating terms and conditions...')
    #     config = self.sudo().search([('is_active','=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
    #     if len(config) > 1:
    #         raise ValidationError(_('You have multiple active report configuration. Head over to the report settings and deactivate the others.'))
    #     if self.analysis_ids and analysis:
    #         config = self.analysis_ids.sudo().search([('id','=',analysis.id)]).config_id.sudo().search([('is_active', '=', True), ('report_type_id.id', '=', analysis.analysis_type_id.id)])
    #     assessment = config.section_ids.search([('section', '=', 'tnc'), ('config_id','=', config.id)])
    #     summary = ''
    #     summary += assessment.summary
    #     return summary
