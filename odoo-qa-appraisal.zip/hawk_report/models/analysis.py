# -*- coding: utf-8 -*-
from odoo import tools, _
from odoo import api, fields, models
from odoo.exceptions import ValidationError, UserError
import base64
from slugify import slugify
import logging

_logger = logging.getLogger(__name__)

# IMPROVEMENT: add version restore method using 'hawk.analysis.report.log'
class Analysis(models.Model):
    _inherit = 'hawk.analysis'


    config_id = fields.Many2one('hawk.analysis.config', default=lambda self:self.get_config())
    report_logs = fields.One2many('hawk.analysis.report.log', 'analysis_id', description='History record of report contents.')

    #returns latest report settings.
    def get_config(self):
        if not self.config_id:
            config = self.env['hawk.analysis.config'].sudo().search([('is_active','=',True)], order='datetime desc')
            if config: #multiple activated report config.
                config = config[0]
                return config.id

    #returns domain for filtering [sign.request] records connnected to this analysis.
    def sign_request_domain(self):
        tag = self.env['sign.template.tag'].search([('name', '=', self.analysis_type)])
        domain = [('template_id.tag_ids', 'in', [tag.id])]
        # '|','|',('state', '=', 'sent'),('state', '=', 'signed'),
        # '|',('create_uid', '=', self.env.user.id),('request_item_ids.partner_id.user_ids', 'like', self.env.user.id)]
        return domain

    sign_request_ids = fields.One2many('sign.request', string='Reports', inverse_name='analysis_id', tracking=True,
                                       domain=lambda self: self.sign_request_domain())
    subject = fields.Char()
    message = fields.Text()
    version = fields.Integer(default=1)

    def action_edit_answer_by_tl(self):
        if self.env.user.id == self.team_leader_id.id:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Survey',
                'view_mode': 'form',
                'res_model': 'survey.user_input',
                'res_id': self.env['survey.user_input'].search([('survey_token', '=', self.access_token)]).id,
            }
        else:
            raise ValidationError('Sorry only the assigned team leader can edit the answers.')

    def check_if_signed(self, analysis, request, role, partner):
        request_item = request.request_item_ids.search([('sign_request_id.id', '=', request.id),
                                                        ('role_id', '=', self.env['sign.item.role'].sudo().search(
                                                            [('name', '=', role)]).id),
                                                        ('partner_id.id', '=', partner.id)])
        print('request_item', request_item)
        return request_item.state == 'completed'

    def submit_to_tl(self):
        request = self.sign_request_ids[len(self.sign_request_ids) - 1]
        role = 'Analyst'
        partner = self[self.analysis_type.lower() + '_analyst_id'].partner_id
        if not self.check_if_signed(self.id, request, role, partner):
            raise UserError(_('Please affix your signature on the latest report before submitting. Thank you.'))

        self.state = 'tl'

    def assign_qa_wizard(self):
        request = self.sign_request_ids[len(self.sign_request_ids) - 1]
        role = 'Team Leader'
        partner = self.team_leader_id.partner_id
        name = "Assign QA"
        if not self.check_if_signed(self.id, request, role, partner):
            raise UserError(_('Please affix your signature on the latest report before submitting. Thank you.'))
        if self.is_qa_reject:
            name = "Assign QA and Submit Rejected Document"

        return {
            'name': _(name),  # Name You want to display on wizard
            'view_mode': 'form',
            'view_id': self.env['ir.ui.view'].get_view_id('hawk_report.assign_qa_form'),
            'view_type': 'form',
            'res_model': 'assign.qa',  # With . Example sale.order
            'type': 'ir.actions.act_window',
            'target': 'new'
        }

    def qa_pass_wizard(self):
        request = self.sign_request_ids[len(self.sign_request_ids) - 1]
        role = 'Quality Control'
        partner = self.qa_specialist_id.partner_id
        if not self.check_if_signed(self.id, request, role, partner):
            raise UserError(_('Please affix your signature on the latest report before submitting. Thank you.'))

        return {
            'name': _("QA Pass"),  # Name You want to display on wizard
            'view_mode': 'form',
            'view_id': self.env['ir.ui.view'].get_view_id('hawk_report.qa_pass_form'),
            'view_type': 'form',
            'res_model': 'qa.pass',  # With . Example sale.order
            'type': 'ir.actions.act_window',
            'target': 'new'
        }

    def open_report_dialog(self):

        #return latest log
        reportChangeLog = self.report_logs.search([('analysis_id','=',self.id)], order='id desc')
        new_report = False
        if not reportChangeLog:
            #create log
            reportChangeLog = self.report_logs.create({
                'analysis_id': self.id
            })
            new_report = True
        else:
            reportChangeLog = reportChangeLog[0]

        # calculate scores, generate dataset, transform to dataframe, generate graphs from dataframe (dataset.py, dataframe.py)
        # assigns all data to ['hawk.analysis.report.log']
        ctx = self.get_values(self.id, reportChangeLog.id)

        # opens  'Generate report' dialog box
        return {
            'name': _("Edit Report"),  # Name You want to display on wizard
            'view_mode': 'form',
            'view_id': self.env['ir.ui.view'].get_view_id('hawk_report.view_wizard_report_form'),
            'view_type': 'form',
            'res_model': 'wizard.report',  # With . Example sale.order
            'type': 'ir.actions.act_window',
            'target': 'new',
            # 'domain': '[if you need]',
            'context': {'analysis_id': self.id,
                        'reportChangeLog_id': reportChangeLog.id,
                        'new_report': new_report,
                        'ctx': ctx}
        }

    # appends QC sign.items
    def update_sign_request(self, request, qa_specialist):
        quality_control = self.env['sign.item.role'].sudo().search([('name', '=', 'Quality Control')])
        print('add QC signatory')
        _logger.info('add QC signatory')

        if qa_specialist:
            try:
                if quality_control.id not in [rec.role_id.id for rec in request.request_item_ids]:
                    # create sign items for QC
                    template = self.create_sign_item(request.sudo().template_id, True)
                    request.sudo().write({'template_id': template.id})
            except Exception as e:
                _logger.error('Cannot create sign items for QA ' + str(e))
            signers = [{'partner_id': qa_specialist.partner_id.id, 'role': quality_control.id}]

            sign_users = self.env['res.users'].search(
                [('partner_id', 'in', [signer['partner_id'] for signer in signers])]).filtered(
                lambda u: u.has_group('sign.group_sign_employee'))

            request.activity_update(sign_users)
            request.append_signers(signers)

    def create_sign_item(self, template, update=False):

        pos_y = 0.0
        role_list = []

        analyst = self.env['sign.item.role'].sudo().search([('name', '=', 'Analyst')])
        team_leader = self.env['sign.item.role'].sudo().search([('name', '=', 'Team Leader')])
        quality_control = self.env['sign.item.role'].sudo().search([('name', '=', 'Quality Control')])

        _logger.info("Invoked from 'update_sign_request' ?" + str(update))

        # If this function is invoked from 'update_sign_request'
        if quality_control and self.qa_specialist_id and update:
            _logger.info('Create QA fields only.')
            role_list.append(quality_control)
            pos_y = 0.114

        # If analysis has the same user for analyst and team leader
        elif team_leader and (self[self.analysis_type.lower() + '_analyst_id'].id == self.team_leader_id.id):
            role_list.insert(0, team_leader)
            role_list.append(team_leader)

        # If the analysis has separate users for analyst and team leader
        else:
            if analyst and self[self.analysis_type.lower() + '_analyst_id']:
                role_list.insert(0, analyst)
            if team_leader and self.team_leader_id:
                role_list.append(team_leader)

        _logger.info('CREATING SIGN ITEMS FOR ROLES: ' + str(role_list))
        for role in role_list:
            _logger.info('Creating fields for ' + str(role.name) + ' ...')
            sign_item = self.env['sign.item']
            name = self.env['sign.item.type'].sudo().search([('name', '=', 'Name')])
            sign_item.create({
                'template_id': template.id,
                'type_id': name.id,
                'responsible_id': role.id,
                'page': 2,
                'posX': 0.195,
                'posY': 0.395 + pos_y,
                'width': 0.210,
                'height': 0.012
            })
            signature = self.env['sign.item.type'].sudo().search([('name', '=', 'Signature')])
            sign_item.create({
                'template_id': template.id,
                'type_id': signature.id,
                'responsible_id': role.id,
                'page': 2,
                'posX': 0.417,
                'posY': 0.374 + pos_y,
                'width': 0.170,
                'height': 0.052
            })
            function = self.env['sign.item.type'].sudo().search([('name', '=', 'Function')])
            sign_item.create({
                'template_id': template.id,
                'type_id': function.id,
                'responsible_id': role.id,
                'page': 2,
                'posX': 0.599,
                'posY': 0.395 + pos_y,
                'width': 0.166,
                'height': 0.012
            })
            date = self.env['sign.item.type'].sudo().search([('name', '=', 'Date')])
            sign_item.create({
                'template_id': template.id,
                'type_id': date.id,
                'responsible_id': role.id,
                'page': 2,
                'posX': 0.779,
                'posY': 0.395 + pos_y,
                'width': 0.163,
                'height': 0.012
            })
            pos_y += 0.057

        return template

    # create ['sign.template'] from the report pdf
    def create_sign_template(self, pdf_content):
        try:

            attachment = self.env['ir.attachment'].sudo().create({
                'name': 'Safety Module Report.pdf',
                'type': 'binary',
                'datas': base64.b64encode(pdf_content),
                'res_model': self._name,
                'res_id': self.id
            })

            template = self.env['sign.template'].sudo().create({
                'attachment_id': attachment.id,
                'share_link': slugify(attachment.name),
                'privacy': 'employee',
                'create_uid': self.env.user.id,
                'type': self.env['sign.template.type'].sudo().search(
                    [('name', '=', '%s Module Report' % (self.analysis_type))]).id,
                'favorited_ids': [(4, self[self.analysis_type.lower() + '_analyst_id'].id),
                                  (4, self.team_leader_id.id)],
                'tag_ids': [(4, self.env['sign.template.tag'].sudo().search(
                    [('name', '=', self.analysis_type.capitalize())]).id)]
            })

            _logger.info("SIGN TEMPLATE CREATED.")
            return self.create_sign_item(template)

        except Exception as e:
            raise ValidationError(_(str(e)))

    # duplicates sign.item of analyst when team leader generates a new version. to keep analyst's signature in the new version
    def duplicate_sign_request(self, module_report_requests):
        # module_report_requests: all sign.request connected to this analysis
        analyst = self.env['sign.item.role'].sudo().search([('name', '=', 'Analyst')])
        analysis = self.env['hawk.analysis'].sudo().search([('id', '=', self.id)])
        _logger.info(str([rec.reference for rec in module_report_requests]))
        if module_report_requests:
            try:
                current_request = module_report_requests[len(module_report_requests) - 1]
                previous_request = module_report_requests[len(module_report_requests) - 2]
                previous_analyst = previous_request.request_item_ids.sudo().search(
                    [('sign_request_id.id', '=', previous_request.id), ('role_id.id', '=', analyst.id)])
                current_analyst = analysis[analysis.analysis_type.lower() + '_analyst_id']
                current_request.sudo().template_id.name = '%s (v%s)' % (
                    current_request.sudo().template_id.name, len(module_report_requests))
                analysis.sudo().version = len(module_report_requests)
                current_request.sudo().reference = '%s (v%s)' % (
                    current_request.sudo().reference, len(module_report_requests))

                signItemValues = self.env['sign.request.item.value']
                if previous_analyst.partner_id.id == current_analyst.partner_id.id:
                    previousSignRequestItems = self.env['sign.request.item'].sudo().search(
                        [('sign_request_id.id', '=', previous_request.id), ('role_id.id', '=', analyst.id)])
                    currentSignRequestItems = self.env['sign.request.item'].sudo().search(
                        [('sign_request_id.id', '=', current_request.id), ('role_id.id', '=', analyst.id)])
                    signItems = self.env['sign.item'].sudo().search(
                        [('template_id.id', '=', current_request.sudo().template_id.id),
                         ('responsible_id.id', '=', analyst.id)])

                    for previous_request_item in previousSignRequestItems:
                        for current_request_item in currentSignRequestItems:
                            current_request_item.sudo().state = previous_request_item.sudo().state
                            current_request_item.sudo().signing_date = previous_request_item.sudo().signing_date
                            current_request_item.sudo().signature = previous_request_item.sudo().signature
                            for item in signItems:
                                for previous_value in signItemValues.sudo().search(
                                        [('sign_request_item_id.role_id.id', '=', analyst.id),
                                         ('sign_request_item_id.id', '=', previous_request_item.id),
                                         ('sign_item_id.type_id.id', '=', item.type_id.id)]):
                                    self.env['sign.request.item.value'].sudo().create({
                                        'sign_request_item_id': current_request_item.id,
                                        'sign_item_id': item.id,
                                        'value': previous_value.value
                                    })
                else:
                    _logger.info(str([rec.name for rec in previous_analyst.partner_id]))
                    _logger.info(str([rec.name for rec in current_analyst.partner_id]))

                _logger.info("SIGN REQUEST UPDATED")

            except Exception as e:
                _logger.error(str(e))

    # creates new ['sign.request'] record. sends out notifs to signees
    def create_sign_request(self, template, reportLog, send=True, without_mail=False):
        try:
            analyst = self.env['sign.item.role'].sudo().search([('name', '=', 'Analyst')])
            team_leader = self.env['sign.item.role'].sudo().search([('name', '=', 'Team Leader')])

            # else:
            responsible_person = False
            if self.state == 'report':
                responsible_person = 'team_leader'
            elif self.state == 'tl':
                responsible_person = 'qa_specialist'
            template_id = template.id
            signers = []
            if self[self.analysis_type.lower() + '_analyst_id'].id == self.team_leader_id.id:
                self.team_leader_id.partner_id.function = 'Team Leader'
                signers = [{'partner_id': self.team_leader_id.partner_id.id, 'role': team_leader.id}]
            else:
                signers = [
                    {'partner_id': self[self.analysis_type.lower() + '_analyst_id'].partner_id.id, 'role': analyst.id},
                    {'partner_id': self.team_leader_id.partner_id.id, 'role': team_leader.id}]
            followers = [self.tender_manager_id.partner_id.id]
            reference = template.attachment_id.name
            subject = self.subject
            message = self.message

            _logger.info("SIGN REQUEST CREATED")
            return self.env['sign.request'].initialize_new(template_id,
                                                           signers,
                                                           followers,
                                                           reference,
                                                           subject,
                                                           message,
                                                           send,
                                                           without_mail,
                                                           self,
                                                           reportLog)
        except Exception as e:
            raise ValidationError(_(str(e)))

    def button_edit_report(self):
        print('button_edit_report', self)
        self.is_generate_done = False
        self.is_qa_reject = False
        if self.env.user.id == self.team_leader_id.id:
            vals = [{
                'analysis_id': self.id,
                'details': 'Edit Report',
                'date': fields.Datetime.now(),
                'res_person_id': self.team_leader_id.id,
                'remarks': self.team_leader_id.name + ' is editing the report.',
            }]
            self.analysis_timeline_ids.create(vals)

            # Alerts
            odoobot = self.env.ref('base.partner_root')
            self.message_post(
                subject='Edit Report',
                body=self.team_leader_id.name + ' is editing the report.',
                message_type='comment',
                subtype_xmlid='mail.mt_comment',
                notify_by_email=False,
                author_id=odoobot.id,
                partner_ids=[4, self[self.analysis_type.lower() + '_analyst_id'].partner_id.id])

            self.write({'state': 'report'})
            self.action_send_email('edit_report_by_tl_template')
        else:
            raise ValidationError('Sorry only the assigned team leader is allowed to edit the report.')

    def action_send_email(self, template):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(self.id)
        self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(self.id, force_send=True)
