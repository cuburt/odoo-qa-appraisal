# -*- coding: utf-8 -*-
import matplotlib as mpl

mpl.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

from matplotlib.patches import Circle, RegularPolygon
from matplotlib.path import Path
from matplotlib.projections.polar import PolarAxes
from matplotlib.projections import register_projection
from matplotlib.spines import Spine
from matplotlib.transforms import Affine2D
from contextlib import closing
from collections import OrderedDict

import more_itertools as mit
# import squarify
import logging
import tempfile
import base64
import os

from statistics import mode

from odoo import tools, _
from odoo import api, fields, models
from odoo.tools.image import image_data_uri
from odoo.exceptions import ValidationError, UserError

_logger = logging.getLogger(__name__)


class ReportChangeLog(models.Model):
    _inherit = 'hawk.analysis.report.log'
    _description = "Report Change Log"

    img_category_count_bar = fields.Binary(attachment=True)
    img_weight_count_bar = fields.Binary(attachment=True)
    img_mean_score_bar = fields.Binary(attachment=True)
    img_weighted_mean_score_bar = fields.Binary(attachment=True)
    img_category_count_pie = fields.Binary(attachment=True)
    img_weight_count_radar = fields.Binary(attachment=True)
    img_mean_score_radar = fields.Binary(attachment=True)
    # img_mean_score_treemap = fields.Binary(attachment=True)
    img_linegraph_context = fields.Binary(attachment=True)
    img_linegraph_leadership = fields.Binary(attachment=True)
    img_linegraph_planning = fields.Binary(attachment=True)
    img_linegraph_support = fields.Binary(attachment=True)
    img_linegraph_operation = fields.Binary(attachment=True)
    img_linegraph_performance = fields.Binary(attachment=True)
    img_linegraph_improvement = fields.Binary(attachment=True)

class Analysis(models.Model):
    _inherit = 'hawk.analysis'

    # method for radar graphs. currently not being used
    def radar_factory(self, num_vars, frame='circle'):

        theta = np.linspace(0, 2 * np.pi, num_vars, endpoint=False)

        class RadarAxes(PolarAxes):

            name = 'radar'

            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.set_theta_zero_location('N')

            def fill(self, *args, closed=True, **kwargs):
                return super().fill(closed=closed, *args, **kwargs)

            def plot(self, *args, **kwargs):
                lines = super().plot(*args, **kwargs)
                for line in lines:
                    self._close_line(line)

            def _close_line(self, line):
                x, y = line.get_data()
                if x[0] != x[-1]:
                    x = np.concatenate((x, [x[0]]))
                    y = np.concatenate((y, [y[0]]))
                    line.set_data(x, y)

            def set_varlabels(self, labels):
                self.set_thetagrids(np.degrees(theta), labels)

            def _gen_axes_patch(self):
                if frame == 'circle':
                    return Circle((0.5, 0.5), 0.5)
                elif frame == 'polygon':
                    return RegularPolygon((0.5, 0.5), num_vars,
                                          radius=.5, edgecolor="k")
                else:
                    raise ValueError("unknown value for 'frame': %s" % frame)

            def draw(self, renderer):
                if frame == 'polygon':
                    gridlines = self.yaxis.get_gridlines()
                    for gl in gridlines:
                        gl.get_path()._interpolation_steps = num_vars

                super().draw(renderer)

            def _gen_axes_spines(self):
                if frame == 'circle':
                    return super()._gen_axes_spines()
                elif frame == 'polygon':
                    spine = Spine(axes=self,
                                  spine_type='circle',
                                  path=Path.unit_regular_polygon(num_vars))
                    spine.set_transform(Affine2D().scale(.5).translate(.5, .5)
                                        + self.transAxes)

                    return {'polar': spine}
                else:
                    raise ValueError("unknown value for 'frame': %s" % frame)

        register_projection(RadarAxes)
        return theta

    # transforms dictionary from dataset.py into pandas.DataFrame for permutability.
    def dataframe(self, values):
        df = pd.DataFrame(values)
        df_list = []
        # arrange column 'category_sequence' unique values into iso format for categories.
        # 1. Context
        # 2. Leadership
        # 3. Planning
        # 4. Support
        # 5. Operation
        # 6. Performance
        # 7. Improvement
        a_list = [x for _, x in sorted(zip(sorted([seq for seq in df.category_sequence.unique()]), [cat for cat in df.category.unique()]))]
        # creates temporary dataframe for each category
        for i in a_list:
            temp_df = df.loc[df['category'] == i]
            temp_df.reset_index(inplace=True)
            temp_df.index += 1
            temp_df['local_sequence'] = temp_df.index
            temp_df.reset_index(drop=True, inplace=True)
            # append temporary dataframe to df_list
            df_list.append(temp_df)
        # merge separate temporary dataframes
        merged_df = pd.concat(df_list)
        merged_df.reset_index(drop=True, inplace=True)
        merged_df.drop(columns=['index'], inplace=True)
        # sort category values based on the column 'category_sequence'
        merged_df.sort_values(['category_sequence'])
        print(merged_df)
        return a_list, merged_df

    # returns a dataframe where rows are aggregated by category
    def df_by_cat(self, dataframe):
        df_by_cat = dataframe.groupby('category')
        return df_by_cat

    # returns a dataframe where rows are aggregated and counted by category
    def df_count(self, df_by_cat):
        df_count = df_by_cat['category'].agg(['count'])
        df_count = df_count.rename_axis(None, axis=0)
        return df_count

    # returns a dataframe where rows are aggregated and averaged by category
    def df_mean_raw_mark(self, df_by_cat):
        df_mean_raw_mark = df_by_cat['score'].agg(['mean'])
        return df_mean_raw_mark

    # returns a dataframe where rows are aggregated and summed up by category
    def df_sum_raw_mark(self, df_by_cat):
        df_sum_raw_mark = df_by_cat['score'].agg(['sum'])
        return df_sum_raw_mark

    # returns a dataframe of weight values (coefficients) by category
    def df_coeff_count(self, df_by_cat):
        df_coeff_count = df_by_cat['weight'].agg(['max'])
        return df_coeff_count

    # returns a dataframe of average * coefficient by category
    def df_correlated_mark(self, df_mean_raw_mark, df_coeff_count):
        df_correlated_mark = pd.DataFrame(df_mean_raw_mark.values * df_coeff_count.applymap(lambda x: x / 1).values,
                                          columns=df_mean_raw_mark.columns,
                                          index=df_mean_raw_mark.index)
        return df_correlated_mark

    # returns a dataframe of average/sum(df_mean_raw_mark) * 100 by category
    def df_cumulative_raw_mark(self, df_mean_raw_mark):

        data = [round((row[0] / df_mean_raw_mark.sum().values[0]) * 100) for row in df_mean_raw_mark.values]
        if sum(data) != 100:
            for i in range(1, 10):
                if sum(data) != 100:
                    data = [round((row[0] / df_mean_raw_mark.sum().values[0]) * 100, i) for row in df_mean_raw_mark.values]
                else: break

        df_cumulative_raw_mark = pd.DataFrame({'mean': data}, index=df_mean_raw_mark.index)

        return df_cumulative_raw_mark

    # returns a dataframe of weighted average/sum(df_correlated_mark) * 100 by category
    def df_cumulative_weighted_mark(self, df_correlated_mark):

        data = [round(row[0] / df_correlated_mark.sum().values[0] * 100) for row in df_correlated_mark.values]
        if sum(data) != 100:
            for i in range(1, 10):
                if sum(data) != 100:
                    data = [round(row[0] / df_correlated_mark.sum().values[0] * 100, i) for row in df_correlated_mark.values]
                else:
                    break

        df_cumulative_weighted_mark = pd.DataFrame({'mean': data}, index=df_correlated_mark.index)

        return df_cumulative_weighted_mark

    # currently not being used
    def category_count_bar(self, df_count):
        fig = plt.figure(figsize=(6.4, 4.8))
        plt.bar(df_count.index, df_count['count'], color='#5a3d98')
        plt.yticks(np.arange(0, df_count['count'].max() + 1, step=df_count.any().min()), fontsize=12)
        plt.xticks(df_count.index, rotation=20, fontsize=12)
        plt.grid(axis='y')
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='category_count_bar.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    # currently not being used
    def weight_count_bar(self, df_coeff_count):
        fig = plt.figure(figsize=(6.4, 4.8))
        plt.bar(df_coeff_count.index, df_coeff_count['max'], color='#555858')
        plt.yticks(np.arange(0, df_coeff_count['max'].max() + 1, step=df_coeff_count.any().min()), fontsize=12)
        plt.xticks(df_coeff_count.index, rotation=20, fontsize=12)
        plt.grid(axis='y')
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='weight_count_bar.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    def weight_count_bar_large(self, df_coeff_count):
        fig = plt.figure(figsize=(20, 6))
        plt.bar(df_coeff_count.index, df_coeff_count['max'], color='#5a3d98')
        plt.yticks(np.arange(0, df_coeff_count['max'].max() + 1, step=df_coeff_count.any().min()), fontsize=15)
        plt.xticks(df_coeff_count.index, fontsize=15)
        plt.grid(axis='y')
        plt.title('Considered Weighting Coefficient', fontsize=15)
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='weight_count_bar_large.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    # currently not being used
    def mean_score_bar(self, df_mean_raw_mark):
        fig = plt.figure(figsize=(6.4, 4.8))
        plt.bar(df_mean_raw_mark.index, df_mean_raw_mark['mean'])
        plt.yticks(np.arange(0, df_mean_raw_mark['mean'].max() + 1, step=df_mean_raw_mark.any().min()), fontsize=12)
        plt.xticks(df_mean_raw_mark.index, rotation=20, fontsize=12)
        plt.grid(axis='y')
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='mean_score_bar.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    def mean_score_bar_large(self, df_mean_raw_mark):
        fig = plt.figure(figsize=(20, 6))
        plt.bar(df_mean_raw_mark.index, df_mean_raw_mark['mean'], color='#555858')
        plt.yticks(np.arange(0, df_mean_raw_mark['mean'].max() + 1, step=df_mean_raw_mark.any().min()), fontsize=15)
        plt.xticks(df_mean_raw_mark.index, fontsize=15)
        plt.grid(axis='y')
        plt.title('Average Raw Mark per Category', fontsize=15)
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='mean_score_bar_large.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    # currently not being used
    def weighted_mean_score_bar(self, df_correlated_mark):
        fig = plt.figure(figsize=(6.4, 4.8))
        plt.bar(df_correlated_mark.index, df_correlated_mark['mean'])
        plt.yticks(np.arange(0, df_correlated_mark['mean'].max() + 1, step=df_correlated_mark.any().min()), fontsize=12)
        plt.xticks(df_correlated_mark.index, rotation=20, fontsize=12)
        plt.grid(axis='y')
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='weighted_mean_score_bar.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    def weighted_mean_score_bar_large(self, df_correlated_mark):
        #TODO: dynamic font size
        fig = plt.figure(figsize=(20, 6))
        plt.bar(df_correlated_mark.index, df_correlated_mark['mean'], color='#b1b3b5')
        plt.yticks(np.arange(0, df_correlated_mark['mean'].max() + 1, step=df_correlated_mark.any().min()), fontsize=12)
        plt.xticks(df_correlated_mark.index, fontsize=15)
        plt.grid(axis='y')
        plt.title('Average Corrected Mark per Category', fontsize=15)
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='weighted_mean_score_bar_large.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    def category_count_pie(self, df_count):
        explode = ([0.05 for category in df_count.index])
        fig = plt.figure(figsize=(6.4, 4.8))
        _, _, autotexts = plt.pie(df_count['count'],
                explode=explode,
                #         labels=df_count.index,
                autopct='%1.0f%%',
                pctdistance=0.83,
                #         shadow=True,
                #         startangle=90
                colors=['#5a3d98', '#ADA0CE', '#b1b3b5', '#555858', '#000000', '#29abe3', '#0070bd'])
        plt.setp(autotexts, **{'color': 'white', 'weight': 'bold', 'fontsize': 11})
        centre_circle = plt.Circle((0, 0), 0.70, fc='white')
        fig = plt.gcf()
        fig.gca().add_artist(centre_circle)
        plt.axis('equal')
        plt.legend(loc=8, ncol=4, labels=df_count.index,
                   columnspacing=0.1,
                   labelspacing=0.05,
                   handlelength=1,
                   borderaxespad=0.01,
                   mode='expand')
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='category_count_pie.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    def mean_raw_mark_pie(self, df_cumulative_raw_mark):
        explode = ([0.05 for category in df_cumulative_raw_mark.index])
        pad = str(df_cumulative_raw_mark['mean'].values[0])[::-1].find('.')
        if pad <= 0: pad = 0
        fig = plt.figure(figsize=(6.4, 4.8))
        _, _, autotexts = plt.pie(df_cumulative_raw_mark['mean'],
                                  explode=explode,
                                  # autopct='%1.'+str(pad)+'f%%',
                                  autopct='%.2f%%',
                                  pctdistance=0.83,
                                  colors=['#5a3d98', '#ADA0CE', '#b1b3b5', '#555858', '#000000', '#29abe3', '#0070bd'])
        plt.setp(autotexts, **{'color': 'white', 'weight': 'bold', 'fontsize': 9.5})
        centre_circle = plt.Circle((0, 0), 0.70, fc='white')
        fig = plt.gcf()
        fig.gca().add_artist(centre_circle)
        plt.axis('equal')
        plt.legend(loc=8, ncol=4, labels=df_cumulative_raw_mark.index,
                   columnspacing=0.1,
                   labelspacing=0.05,
                   handlelength=1,
                   borderaxespad=0.01,
                   mode='expand')
        plt.title('Average Raw Mark Composition')
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='mean_raw_mark_pie.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    def weighted_mean_raw_mark_pie(self, df_cumulative_weighted_mark):
        explode = ([0.05 for category in df_cumulative_weighted_mark.index])
        pad = str(df_cumulative_weighted_mark['mean'].values[0])[::-1].find('.')
        if pad <= 0: pad = 0
        fig = plt.figure(figsize=(6.4, 4.8))
        _, _, autotexts = plt.pie(df_cumulative_weighted_mark['mean'],
                                  explode=explode,
                                  # autopct='%1.'+str(pad)+'f%%',
                                  autopct='%.2f%%',
                                  pctdistance=0.83,
                                  colors=['#5a3d98', '#ADA0CE', '#b1b3b5', '#555858', '#000000', '#29abe3', '#0070bd'])
        plt.setp(autotexts, **{'color': 'white', 'weight': 'bold', 'fontsize': 9.5})
        centre_circle = plt.Circle((0, 0), 0.70, fc='white')
        fig = plt.gcf()
        fig.gca().add_artist(centre_circle)
        plt.axis('equal')
        plt.legend(loc=8, ncol=4, labels=df_cumulative_weighted_mark.index,
                   columnspacing=0.1,
                   labelspacing=0.05,
                   handlelength=1,
                   borderaxespad=0.01,
                   mode='expand')
        plt.title('Average Corrected Mark Composition')
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='weighted_mean_raw_mark_pie.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    # currently not being used
    def weight_count_radar(self, df_coeff_count):
        N = len(df_coeff_count.index)
        theta = self.radar_factory(N, frame='polygon')
        spoke_labels = df_coeff_count.index
        fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(projection='radar'))
        ax.set_rgrids([item for sublist in df_coeff_count.to_numpy() for item in sublist])
        vals = [item for sublist in df_coeff_count.to_numpy() for item in sublist]
        line = ax.plot(theta, vals)
        ax.fill(theta, vals, alpha=0.25)
        ax.set_varlabels(spoke_labels)
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='weight_count_radar.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    # currently not being used
    def mean_score_radar(self, df_mean_raw_mark):
        N = len(df_mean_raw_mark.index)
        theta = self.radar_factory(N, frame='polygon')
        spoke_labels = df_mean_raw_mark.index
        fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(projection='radar'))
        ax.set_rgrids([item for sublist in df_mean_raw_mark.to_numpy() for item in sublist])
        vals = [item for sublist in df_mean_raw_mark.to_numpy() for item in sublist]
        line = ax.plot(theta, vals)
        ax.fill(theta, vals, alpha=0.25)
        ax.set_varlabels(spoke_labels)
        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='mean_score_radar.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    # currently not being used
    # def mean_score_treemap(self, df_mean_raw_mark):
    #     squarify.plot(sizes=df_mean_raw_mark['mean'], label=df_mean_raw_mark.index, alpha=.8)
    #     plt.axis('off')
    #     graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='mean_score_treemap.tmp.')
    #     with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
    #         plt.savefig(tmpfile, format="png")
    #         tmpfile.seek(0)
    #     plt.clf()
    #     return base64.b64encode(open(graph_path, 'rb').read())

    # removes saved .png s in a temporary file dir
    def process_tempfile(self, function):
        try:
            os.unlink(function[1])
        except (OSError, IOError):
            _logger.error('Error when trying to remove file %s' % function[1])
        return function[0]

    # generates graphs and stores them to ['hawk.analysis.report.log']. returns dataframe, and total values for 'methodology' section of safety report
    def generate_graph(self, values, reportChangeLog_id):
        try:
            reportChangeLog = self.report_logs.search([('id', '=', reportChangeLog_id)])

            # create dataframes and sort categories according to iso
            sorted_list, dataframe = self.dataframe(values)
            df_by_cat = self.df_by_cat(dataframe)
            df_count = self.df_count(df_by_cat)
            df_count = df_count.loc[sorted_list]
            df_mean_raw_mark = self.df_mean_raw_mark(df_by_cat)
            df_mean_raw_mark = df_mean_raw_mark.loc[sorted_list]
            df_coeff_count = self.df_coeff_count(df_by_cat)
            df_coeff_count = df_coeff_count.loc[sorted_list]
            df_sum_raw_mark = self.df_sum_raw_mark(df_by_cat)
            df_sum_raw_mark = df_sum_raw_mark.loc[sorted_list]
            df_correlated_mark = self.df_correlated_mark(df_mean_raw_mark, df_coeff_count)
            df_correlated_mark = df_correlated_mark.loc[sorted_list]
            df_cumulative_raw_mark = self.df_cumulative_raw_mark(df_mean_raw_mark)
            df_cumulative_raw_mark = df_cumulative_raw_mark.loc[sorted_list]
            df_cumulative_weighted_mark = self.df_cumulative_weighted_mark(df_correlated_mark)
            df_cumulative_weighted_mark = df_cumulative_weighted_mark.loc[sorted_list]

            # generate line graph for each category
            try:
                for i in list(sorted_list):
                    temp_df = dataframe.loc[dataframe['category'] == i]
                    fig = plt.figure(figsize=(6.4, 4.8))
                    plt.plot(temp_df['local_sequence'], temp_df['score'])
                    plt.axis([0, len(temp_df['local_sequence']) + 1, 0, 11]) #[xmin, xmax, ymin, ymax]
                    # plt.xticks(np.arange(0, len(temp_df['local_sequence']) + 1, 1), fontsize=8)
                    plt.xticks(fontsize=12)
                    plt.yticks(np.arange(0, 11, 1), fontsize=12)
                    plt.grid(axis='y')
                    graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='%s_linegraph.tmp.' % (str(i)))
                    with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
                        plt.savefig(tmpfile, format="png")
                        tmpfile.seek(0)
                    plt.clf()
                    reportChangeLog['img_linegraph_%s' % (str(i).lower())] = base64.b64encode(open(graph_path, 'rb').read())
            except Exception as e:
                raise ValidationError(_('loop categorical_line_graph: ' + str(e)))

            # create and store graphs to report change log

            # reportChangeLog.img_category_count_bar = self.category_count_bar(df_count)
            # reportChangeLog.img_weight_count_bar = self.weight_count_bar(df_coeff_count)
            reportChangeLog.img_weight_count_bar_large = self.process_tempfile(self.weight_count_bar_large(df_coeff_count))
            # reportChangeLog.img_mean_score_bar = self.mean_score_bar(df_mean_raw_mark)
            reportChangeLog.img_mean_score_bar_large = self.process_tempfile(self.mean_score_bar_large(df_mean_raw_mark))
            # reportChangeLog.img_weighted_mean_score_bar = self.weighted_mean_score_bar(df_correlated_mark)
            reportChangeLog.img_weighted_mean_score_bar_large = self.process_tempfile(self.weighted_mean_score_bar_large(df_correlated_mark))
            reportChangeLog.img_category_count_pie = self.process_tempfile(self.category_count_pie(df_count))
            reportChangeLog.img_mean_raw_mark_pie = self.process_tempfile(self.mean_raw_mark_pie(df_cumulative_raw_mark))
            reportChangeLog.img_weighted_mean_raw_mark_pie = self.process_tempfile(self.weighted_mean_raw_mark_pie(df_cumulative_weighted_mark))
            # reportChangeLog.img_weight_count_radar = self.weight_count_radar(df_coeff_count)
            # reportChangeLog.img_mean_score_radar = self.mean_score_radar(df_mean_raw_mark)
            # reportChangeLog.img_mean_score_treemap = self.mean_score_treemap(df_mean_raw_mark)

            #set contents to report change log

            reportChangeLog.executive_summary = self.config_id.get_executive_summary(self, df_mean_raw_mark)
            reportChangeLog.assessment_context = self.config_id.get_assessment_context(self)
            reportChangeLog.results_analysis_context_1 = self.config_id.get_results_analysis_context_1(self)
            reportChangeLog.results_analysis_context_2_intro = self.config_id.get_results_analysis_context_2_intro(self, df_coeff_count)
            reportChangeLog.results_analysis_context_2_content = self.config_id.get_results_analysis_context_2_content(self, df_coeff_count)
            reportChangeLog.results_analysis_context_3_intro = self.config_id.get_results_analysis_context_3_intro(self, df_mean_raw_mark)
            reportChangeLog.results_analysis_context_3_content = self.config_id.get_results_analysis_context_3_content(self, df_mean_raw_mark)
            reportChangeLog.results_analysis_context_4_intro = self.config_id.get_results_analysis_context_4_intro(self, df_correlated_mark)
            reportChangeLog.results_analysis_context_4_content = self.config_id.get_results_analysis_context_4_content(self, df_correlated_mark)
            reportChangeLog.results_analysis_context_5_intro = self.config_id.get_results_analysis_context_5_intro(self, df_cumulative_raw_mark)
            reportChangeLog.results_analysis_context_5_content = self.config_id.get_results_analysis_context_5_content(self, df_cumulative_weighted_mark)

            # merge dataframes

            merged_df = pd.concat([df_coeff_count,
                                   df_sum_raw_mark,
                                   df_count,
                                   df_mean_raw_mark], axis=1, join='inner')
            merged_df = merged_df.rename(columns={merged_df.columns[3]: 'raw_mean'})
            merged_df = pd.concat([merged_df, df_cumulative_raw_mark], axis=1, join='inner')
            merged_df = merged_df.rename(columns={merged_df.columns[4]: 'cumulative_raw_mean'})
            merged_df = pd.concat([merged_df, df_correlated_mark], axis=1, join='inner')
            merged_df = merged_df.rename(columns={merged_df.columns[5]: 'weighted_mean'})
            merged_df = pd.concat([merged_df, df_cumulative_weighted_mark], axis=1, join='inner')
            merged_df = merged_df.rename(columns={merged_df.columns[6]: 'cumulative_weighted_mean'})

            merged_df = merged_df.round(decimals=2)
            merged_df = merged_df.loc[sorted_list]
            merged_df = merged_df.reset_index()
            merged_df.index = merged_df.index.map(str)
            # merged_df.sort_values()
            pd.set_option('display.max_columns', None)
            _logger.info(merged_df)
            _logger.info(merged_df.to_dict('index'))
            return merged_df.to_dict('index'), df_coeff_count.sum().values[0], df_sum_raw_mark.sum().values[0], \
                   df_count.sum().values[0], df_mean_raw_mark.sum().values[0], round(df_cumulative_raw_mark.sum().values[0]), \
                   df_correlated_mark.sum().values[0], round(df_cumulative_weighted_mark.sum().values[0])

        except Exception as e:
            raise ValidationError(_('Error in generate_graph() ' + str(e)))