# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.exceptions import ValidationError

import matplotlib as mpl

mpl.use('Agg')
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

from contextlib import closing

import tempfile
import base64
import os

# TODO : adjust the dpi for better quality


class Tender(models.Model):
    _inherit = 'hawk.tender'

    done_tenderers = []
    reference_safety_analysis_id = fields.Many2one('hawk.analysis', string='Reference Safety Analysis')
    done_safety_tenderer_ids = fields.One2many('hawk.tenderer', string='Done Safety Tenderer', inverse_name='tender_id')

    @staticmethod
    def get_img_corrected_ave_score_h_bar(data):
        x_data = []
        y_data = []

        for datum in data:
            x_data.append(float(datum['corrected_ave_score']))
            y_data.append(datum['name'])
        #
        # no_of_rec = 5
        # y_data = ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9'][:no_of_rec]
        # x_data = [4.3, 2.5, 3.5, 4.5, 6.3, 5.5, 6.2, 4, 10][:no_of_rec]

        fig, ax = plt.subplots(figsize=(14, 6))
        ax.barh(y_data, x_data, label="Corrected Average Score", color='#5a3d98')
        plt.legend(loc=8, ncol=4)
        plt.grid(axis='x')
        plt.margins(0.25)
        plt.title('Corrected Average Scores of Tenderers', fontsize=15)

        for index, data in enumerate(x_data):
            plt.text(x=data-0.15,
                     y=index,
                     s=f"{data}",
                     color='w',
                     ha='center',
                     fontsize=10,
                     fontweight='bold')

        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='corrected_ave_score_h_bar.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    @staticmethod
    def get_img_per_category_line_graph(title, x_data, y_data):
        # no_of_rec = 9
        # x_data = ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9'][:no_of_rec]
        # y_data = [4.3, 2.5, 3.5, 4.5, 6.3, 5.5, 6.2, 4, 10][:no_of_rec]

        fig, ax = plt.subplots(figsize=(6, 4))
        ax.plot(x_data, y_data, marker='o', linewidth=5, ms='25')
        ax.set_facecolor("#d9d9d9")
        ax.grid(axis='y')
        plt.margins(0.25)
        plt.title(title, fontsize=15)

        for x, y in zip(x_data, y_data):
            label = y  # label = "{:.2f}".format(y) # make the labels 2 decimals
            plt.annotate(label,
                         (x, y),
                         textcoords="offset points",
                         xytext=(0, -2.5),
                         color='w',
                         ha='center',
                         fontsize=8,
                         fontweight='bold')

        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='per_category_line_graph.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    @staticmethod
    def get_img_raw_scores_3d_bar(
            tenderers,
            categories,
            raw_score_context,
            raw_score_leadership,
            raw_score_planning,
            raw_score_support,
            raw_score_operation,
            raw_score_performance,
            raw_score_improvement):

        # n = 4
        # tenderers = ['Tenderer Ryo - A', 'Tenderer Ryo - B', 'Tenderer Ryo - C', 'Tenderer Ryo - D'][:n]
        # raw_score_context = [67, 50, 32, 41][:n]
        # raw_score_leadership = [184, 214, 150, 222][:n]
        # raw_score_planning = [191, 221, 212, 185][:n]
        # raw_score_support = [182, 188, 175, 190][:n]
        # raw_score_operation = [195, 217, 222, 150][:n]
        # raw_score_performance = [121, 128, 111, 81][:n]
        # raw_score_improvement = [36, 21, 34, 26][:n]

        t_len = len(tenderers)
        context_clr = ['#9400D3']*t_len
        leadership_clr = ['#FF7F00']*t_len
        planning_clr = ['#0000FF']*t_len
        support_clr = ['#FFFF00']*t_len
        operation_clr = ['#00FF00']*t_len
        performance_clr = ['#FF0000']*t_len
        improvement_clr = ['#4B0082']*t_len
        colors = [context_clr + leadership_clr + planning_clr + support_clr + operation_clr + performance_clr + improvement_clr]

        result = [raw_score_context,
                  raw_score_leadership,
                  raw_score_planning,
                  raw_score_support,
                  raw_score_operation,
                  raw_score_performance,
                  raw_score_improvement]

        result = np.array(result, dtype=np.int)
        fig = plt.figure(figsize=(14, 8))  # facecolor='#f2e6ff' figsize=(14, 4)
        ax = fig.add_subplot(111, projection='3d')  # facecolor='#cccccc'

        plt.title('Raw Scores Composition According to Categories', fontsize=15)
        # plt.margins(0.10)
        xlabels = np.array(tenderers)
        xpos = np.arange(xlabels.shape[0])
        ylabels = np.array(categories)
        ypos = np.arange(ylabels.shape[0])

        xposM, yposM = np.meshgrid(xpos, ypos, copy=False)
        zpos = result
        zpos = zpos.ravel()

        dx = .50
        dy = .25
        dz = zpos

        ax.w_xaxis.set_ticks(xpos + .5 / 2.)
        ax.w_xaxis.set_ticklabels(xlabels)
        ax.w_yaxis.set_ticks(ypos + 1 / 2.)
        ax.w_yaxis.set_ticklabels(ylabels)

        ax.set_box_aspect((1, 4, 2)) # ax.set_box_aspect((1, 4, 1))
        ax.bar3d(xposM.ravel(), yposM.ravel(), dz*0, dx, dy, dz, color=colors[0])  # color=colors
        ax.view_init(35, -35) # ax.view_init(35, -35)
        # import pdb
        # pdb.set_trace()
        # Segment1_proxy = plt.Rectangle((0, 0), 1, 1, fc="#FFC04C")
        # Segment2_proxy = plt.Rectangle((0, 0), 1, 1, fc="blue")
        # Segment3_proxy = plt.Rectangle((0, 0), 1, 1, fc="#3e9a19")
        #
        # ax.legend([Segment1_proxy,
        #            Segment2_proxy,
        #            Segment3_proxy], ['Segment1',
        #                              'Segment2',
        #                              'Segment3'
        #                              ])

        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='raw_scores_3d_bar_.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    def action_summarize_safety_reports(self):
        template = "hawk_report.action_safety_summary_report"
        dataframes = ()
        tenderers = []

        # 3d bar graph data
        tenderers_name = []
        categories = []
        raw_score_context = []
        raw_score_leadership = []
        raw_score_planning = []
        raw_score_support = []
        raw_score_operation = []
        raw_score_performance = []
        raw_score_improvement = []

        # line graph data
        t_names = []  # abbreviated names
        context = []
        leadership = []
        planning = []
        support = []
        operation = []
        performance = []
        improvement = []

        total_weight = 0
        total_count = 1

        if self.env.user.id == self.tender_manager_id.id:
            for analysis in self.tenderer_ids.analysis_ids:
                if analysis.analysis_type == 'Safety' and analysis.state == 'done':
                    self.done_safety_tenderer_ids = [(4, analysis.tenderer_id.id)]

                    if not self.reference_safety_analysis_id.id:
                        self.reference_safety_analysis_id = analysis.id

                    t_names.append('T%s' % total_count)
                    total_count += 1

                    reportChangeLog = analysis.report_logs.search([('analysis_id', '=', analysis.id)], order='id desc')[0]
                    ctx = analysis.get_values(analysis.id, reportChangeLog.id)
                    merged_df, coeff_count, sum_raw_mark, count, mean_raw_mark, cumulative_raw_mark, correlated_mark, cumulative_weighted_mark = ctx['dataframes']
                    mean_mean_raw_mark = round(mean_raw_mark / 7, 3)
                    mean_correlated_mark = round(correlated_mark / coeff_count, 3)

                    tenderers_name.append(analysis.tenderer_id.name)

                    for k, v in merged_df.items():
                        if v['index'] not in categories:
                            categories.append(v['index'])

                        if v['index'] == 'Context':
                            context.append(v['weighted_mean'])
                            raw_score_context.append(v['sum'])
                        elif v['index'] == 'Leadership':
                            leadership.append(v['weighted_mean'])
                            raw_score_leadership.append(v['sum'])
                        elif v['index'] == 'Planning':
                            planning.append(v['weighted_mean'])
                            raw_score_planning.append(v['sum'])
                        elif v['index'] == 'Support':
                            support.append(v['weighted_mean'])
                            raw_score_support.append(v['sum'])
                        elif v['index'] == 'Operation':
                            operation.append(v['weighted_mean'])
                            raw_score_operation.append(v['sum'])
                        elif v['index'] == 'Performance':
                            performance.append(v['weighted_mean'])
                            raw_score_performance.append(v['sum'])
                        elif v['index'] == 'Improvement':
                            improvement.append(v['weighted_mean'])
                            raw_score_improvement.append(v['sum'])

                    tenderers.append({
                        'name': analysis.tenderer_id.name,
                        'raw_overall_score': format(round(mean_mean_raw_mark, 2), '.2f'),
                        'corrected_ave_score': format(round(mean_correlated_mark, 2), '.2f'),
                    })

                    if not dataframes:
                        dataframes = merged_df
                        for k, v in dataframes.items():
                            v['max'] = int(v['max'])

                    if total_weight <= 0:
                        total_weight = int(coeff_count)

                    if total_count <= 0:
                        total_count = int(count)

            data = {
                'dataframes': dataframes,
                'tenderers': tenderers,
                'total_weight': total_weight,
                'total_count': total_count,
                'img_corrected_ave_score_h_bar': self.get_img_corrected_ave_score_h_bar(tenderers),
                'img_raw_scores_3d_bar': self.get_img_raw_scores_3d_bar(
                    tenderers_name,
                    categories,
                    raw_score_context,
                    raw_score_leadership,
                    raw_score_planning,
                    raw_score_support,
                    raw_score_operation,
                    raw_score_performance,
                    raw_score_improvement),
                'img_line_graph_context': self.get_img_per_category_line_graph('Context', t_names, context),
                'img_line_graph_leadership': self.get_img_per_category_line_graph('Leadership', t_names, leadership),
                'img_line_graph_planning': self.get_img_per_category_line_graph('Planning', t_names, planning),
                'img_line_graph_support': self.get_img_per_category_line_graph('Support', t_names, support),
                'img_line_graph_operation': self.get_img_per_category_line_graph('Operation', t_names, operation),
                'img_line_graph_performance': self.get_img_per_category_line_graph('Performance', t_names, performance),
                'img_line_graph_improvement': self.get_img_per_category_line_graph('Improvement', t_names, improvement),
                'disclaimer': self.reference_safety_analysis_id.config_id.get_disclaimer(self.reference_safety_analysis_id),
                'copyright': self.reference_safety_analysis_id.config_id.get_copyright(self.reference_safety_analysis_id),
            }

            pdf_content, __ = self.env.ref(template)._render_qweb_pdf(self.id, data=data, type='snapshot_report')

            attachment = self.env['ir.attachment'].sudo().create({
                'name': '%s - Safety Module Overall Results Snapshot.pdf' % self.name,
                'type': 'binary',
                'datas': base64.b64encode(pdf_content),
                'res_model': self._name,
                'res_id': self.id
            })

            print(attachment)

        else:
            raise ValidationError('Sorry only the assigned Tender Manager is allowed to create the report.')
