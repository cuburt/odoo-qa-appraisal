# -*- coding: utf-8 -*-
from odoo import tools, _
from odoo import api, fields, models
from odoo.exceptions import ValidationError, UserError
import base64
import logging

_logger = logging.getLogger(__name__)


class SignRequest(models.Model):
    _inherit = 'sign.request'
    # _order = 'create_date desc'

    remarks = fields.Text('Remarks', placeholder='Say something about this template...')
    type = fields.Many2one('sign.template.type', related='template_id.type')

    def append_signers(self, signers):
        sign_request_item = self.env['sign.request.item']

        for rec in self:
            for request_item in rec.request_item_ids:
                for i in range(0, len(signers)):
                    if signers[i]['partner_id'] == request_item.partner_id.id \
                            and signers[i]['role'] == request_item.role_id.id:
                        signers.pop(i)
                    elif signers[i]['partner_id'] != request_item.partner_id.id \
                            and signers[i]['role'] == request_item.role_id.id:
                        request_item.sudo().unlink()

            for signer in signers:
                request_item = sign_request_item.create({
                    'partner_id': signer['partner_id'],
                    'sign_request_id': rec.id,
                    'role_id': signer['role'],
                })
                request_item.sudo().state = 'sent'
                self.completed_document = False
