# -*- coding: utf-8 -*-
import base64
import re

from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.exceptions import UserError, AccessError
from odoo.tools.misc import find_in_path
from odoo.tools import config
from odoo.sql_db import TestCursor
from odoo.http import request

import os
import logging
import tempfile
import lxml.html
import json

from contextlib import closing
from lxml import etree
import subprocess
from PIL import Image, ImageFile
from collections import OrderedDict
from PyPDF2 import PdfFileMerger
from odoo import modules

# Allow truncated images
ImageFile.LOAD_TRUNCATED_IMAGES = True

_logger = logging.getLogger(__name__)

wkhtmltopdf_dpi_zoom_ratio = False


def _get_wkhtmltopdf_bin():
    try:
        return find_in_path('wkhtmltopdf.bin')
    except:
        return find_in_path('wkhtmltopdf')


class PaperFormat(models.Model):
    _inherit = "report.paperformat"

    toc = fields.Boolean(default=False, required=False)
    cover = fields.Boolean(default=False, required=False)
    backcover = fields.Boolean(default=False, required=False)


class IrActionsReport(models.Model):
    _inherit = 'ir.actions.report'
    _description = 'Report Action'
    _table = 'ir_act_report_xml'
    _sequence = 'ir_actions_id_seq'
    _order = 'name'

    @api.model
    def _build_wkhtmltopdf_args(
            self,
            paperformat_id,
            landscape,
            specific_paperformat_args=None,
            set_viewport_size=False):
        '''Build arguments understandable by wkhtmltopdf bin.

        :param paperformat_id: A report.paperformat record.
        :param landscape: Force the report orientation to be landscape.
        :param specific_paperformat_args: A dictionary containing prioritized wkhtmltopdf arguments.
        :param set_viewport_size: Enable a viewport sized '1024x1280' or '1280x1024' depending of landscape arg.
        :return: A list of string representing the wkhtmltopdf process command args.
        '''
        if landscape is None and specific_paperformat_args and specific_paperformat_args.get('data-report-landscape'):
            landscape = specific_paperformat_args.get('data-report-landscape')

        command_args = ['--disable-local-file-access']
        cover_command_args = ['--disable-local-file-access']
        backcover_command_args = ['--disable-local-file-access']

        if set_viewport_size:
            command_args.extend(['--viewport-size', landscape and '1024x1280' or '1280x1024'])
            cover_command_args.extend(['--viewport-size', landscape and '1024x1280' or '1280x1024'])
            backcover_command_args.extend(['--viewport-size', landscape and '1024x1280' or '1280x1024'])

        # Passing the cookie to wkhtmltopdf in order to resolve internal links.
        try:
            if request:
                command_args.extend(['--cookie', 'session_id', request.session.sid])
                cover_command_args.extend(['--cookie', 'session_id', request.session.sid])
                backcover_command_args.extend(['--cookie', 'session_id', request.session.sid])
        except AttributeError:
            pass

        # Less verbose error messages
        command_args.extend(['--quiet'])
        cover_command_args.extend(['--quiet'])
        backcover_command_args.extend(['--quiet'])

        # Build paperformat args
        if paperformat_id:
            if paperformat_id.format and paperformat_id.format != 'custom':
                command_args.extend(['--page-size', paperformat_id.format])
                cover_command_args.extend(['--page-size', paperformat_id.format])
                backcover_command_args.extend(['--page-size', paperformat_id.format])

            if paperformat_id.page_height and paperformat_id.page_width and paperformat_id.format == 'custom':
                command_args.extend(['--page-width', str(paperformat_id.page_width) + 'mm'])
                cover_command_args.extend(['--page-width', str(paperformat_id.page_width) + 'mm'])
                backcover_command_args.extend(['--page-width', str(paperformat_id.page_width) + 'mm'])
                command_args.extend(['--page-height', str(paperformat_id.page_height) + 'mm'])
                cover_command_args.extend(['--page-height', str(paperformat_id.page_height) + 'mm'])
                backcover_command_args.extend(['--page-height', str(paperformat_id.page_height) + 'mm'])

            if specific_paperformat_args and specific_paperformat_args.get('data-report-margin-top'):
                command_args.extend(['--margin-top', str(specific_paperformat_args['data-report-margin-top'])])
                cover_command_args.extend(['--margin-top', str(0)])
                backcover_command_args.extend(['--margin-top', str(0)])
            else:
                command_args.extend(['--margin-top', str(paperformat_id.margin_top)])
                cover_command_args.extend(['--margin-top', str(0)])
                backcover_command_args.extend(['--margin-top', str(0)])

            dpi = None
            if specific_paperformat_args and specific_paperformat_args.get('data-report-dpi'):
                dpi = int(specific_paperformat_args['data-report-dpi'])
            elif paperformat_id.dpi:
                if os.name == 'nt' and int(paperformat_id.dpi) <= 95:
                    _logger.info("Generating PDF on Windows platform require DPI >= 96. Using 96 instead.")
                    dpi = 96
                else:
                    dpi = paperformat_id.dpi
            if dpi:
                command_args.extend(['--dpi', str(dpi)])
                cover_command_args.extend(['--dpi', str(dpi)])
                backcover_command_args.extend(['--dpi', str(dpi)])
                if wkhtmltopdf_dpi_zoom_ratio:
                    command_args.extend(['--zoom', str(96.0 / dpi)])
                    cover_command_args.extend(['--zoom', str(96.0 / dpi)])
                    backcover_command_args.extend(['--zoom', str(96.0 / dpi)])

            if specific_paperformat_args and specific_paperformat_args.get('data-report-header-spacing'):
                command_args.extend(['--header-spacing', str(specific_paperformat_args['data-report-header-spacing'])])
                cover_command_args.extend(['--header-spacing', str(0)])
                backcover_command_args.extend(['--header-spacing', str(0)])
            elif paperformat_id.header_spacing:
                command_args.extend(['--header-spacing', str(paperformat_id.header_spacing)])
                cover_command_args.extend(['--header-spacing', str(0)])
                backcover_command_args.extend(['--header-spacing', str(0)])

            command_args.extend(['--margin-left', str(paperformat_id.margin_left)])
            cover_command_args.extend(['--margin-left', str(paperformat_id.margin_left)])
            backcover_command_args.extend(['--margin-left', str(paperformat_id.margin_left)])
            command_args.extend(['--margin-bottom', str(paperformat_id.margin_bottom)])
            cover_command_args.extend(['--margin-bottom', str(0)])
            backcover_command_args.extend(['--margin-bottom', str(0)])
            command_args.extend(['--margin-right', str(paperformat_id.margin_right)])
            cover_command_args.extend(['--margin-right', str(paperformat_id.margin_right)])
            backcover_command_args.extend(['--margin-right', str(paperformat_id.margin_right)])
            if not landscape and paperformat_id.orientation:
                command_args.extend(['--orientation', str(paperformat_id.orientation)])
                cover_command_args.extend(['--orientation', str(paperformat_id.orientation)])
                backcover_command_args.extend(['--orientation', str(paperformat_id.orientation)])
            if paperformat_id.header_line:
                command_args.extend(['--header-line'])
                cover_command_args.extend(['--header-line'])
                backcover_command_args.extend(['--header-line'])

        if landscape:
            command_args.extend(['--orientation', 'landscape'])
            cover_command_args.extend(['--orientation', 'landscape'])
            backcover_command_args.extend(['--orientation', 'landscape'])

        return command_args, cover_command_args, backcover_command_args

    def _prepare_html(self, html, type=None):

        IrConfig = self.env['ir.config_parameter'].sudo()
        base_url = IrConfig.get_param('report.url') or IrConfig.get_param('web.base.url')

        layout = self.env.ref('web.minimal_layout', False)
        if not layout:
            return {}
        layout = self.env['ir.ui.view'].browse(self.env['ir.ui.view'].get_view_id('web.minimal_layout'))
        root = lxml.html.fromstring(html)
        match_klass = "//div[contains(concat(' ', normalize-space(@class), ' '), ' {} ')]"

        covers = []
        intros = []
        bodies = []
        backcovers = []
        res_ids = []

        body_parent = root.xpath('//main')[0]

        if type == 'safety_report': # or type == 'snapshot_report'

            try:
                header_file = modules.module.get_resource_path("hawk_report", "static/src/html/safety", "header.html")
                header_node = etree.parse(header_file)

                for node in root.xpath(match_klass.format('header')):
                    body_parent = node.getparent()
                    node.getparent().remove(node)
                    header_node.find(".//img[@class='header-img']").attrib['src'] = "data:image/*;base64," + node.get('data-oe-header')
                    header_node.find(".//div[@id='minimal_layout_report_headers']").append(node)

                footer_file = modules.module.get_resource_path("hawk_report", "static/src/html/safety", "footer.html")
                footer_node = etree.parse(footer_file)

                for node in root.xpath(match_klass.format('footer')):
                    body_parent = node.getparent()
                    node.getparent().remove(node)
                    footer_node.find(".//img[@class='footer-img']").attrib['src'] = "data:image/*;base64," + node.get('data-oe-footer')
                    footer_node.find(".//div[@id='minimal_layout_report_footers']").append(node)

            except Exception as e:
                _logger.error(str(e))

        else:
            header_node = etree.Element('div', id='minimal_layout_report_headers')

            for node in root.xpath(match_klass.format('header')):
                body_parent = node.getparent()
                node.getparent().remove(node)
                header_node.append(node)

            footer_node = etree.Element('div', id='minimal_layout_report_footers')

            for node in root.xpath(match_klass.format('footer')):
                body_parent = node.getparent()
                node.getparent().remove(node)
                footer_node.append(node)

        for node in root.xpath(match_klass.format('cover')):
            layout_with_lang = layout

            if node.get('data-oe-lang'):
                layout_with_lang = layout_with_lang.with_context(lang=node.get('data-oe-lang'))
            cover = layout_with_lang._render(dict(subst=False, body=lxml.html.tostring(node), base_url=base_url))
            covers.append(cover)
            if node.get('data-oe-model') == self.model:
                res_ids.append(int(node.get('data-oe-id', 0)))
            else:
                res_ids.append(None)

        for node in root.xpath(match_klass.format('intro')):
            layout_with_lang = layout

            if node.get('data-oe-lang'):
                layout_with_lang = layout_with_lang.with_context(lang=node.get('data-oe-lang'))
            intro = layout_with_lang._render(dict(subst=False, body=lxml.html.tostring(node), base_url=base_url))
            intros.append(intro)
            if node.get('data-oe-model') == self.model:
                res_ids.append(int(node.get('data-oe-id', 0)))
            else:
                res_ids.append(None)

        for node in root.xpath(match_klass.format('article')):
            layout_with_lang = layout

            if node.get('data-oe-lang'):
                layout_with_lang = layout_with_lang.with_context(lang=node.get('data-oe-lang'))
            body = layout_with_lang._render(dict(subst=False, body=lxml.html.tostring(node), base_url=base_url))
            bodies.append(body)
            if node.get('data-oe-model') == self.model:
                res_ids.append(int(node.get('data-oe-id', 0)))
            else:
                res_ids.append(None)

        if not bodies:
            body = bytearray().join([lxml.html.tostring(c) for c in body_parent.getchildren()])
            bodies.append(body)

        for node in root.xpath(match_klass.format('backcover')):
            layout_with_lang = layout

            if node.get('data-oe-lang'):
                layout_with_lang = layout_with_lang.with_context(lang=node.get('data-oe-lang'))
            backcover = layout_with_lang._render(dict(subst=False, body=lxml.html.tostring(node), base_url=base_url))
            backcovers.append(backcover)
            if node.get('data-oe-model') == self.model:
                res_ids.append(int(node.get('data-oe-id', 0)))
            else:
                res_ids.append(None)

        specific_paperformat_args = {}
        for attribute in root.items():
            if attribute[0].startswith('data-report-'):
                specific_paperformat_args[attribute[0]] = attribute[1]

        if type == 'snapshot_report':
            footer = layout._render(dict(subst=False, body=lxml.html.tostring(footer_node), base_url=base_url))
            header = layout._render(dict(subst=False, body=lxml.html.tostring(header_node), base_url=base_url))
        else:
            footer = layout._render(dict(subst=True, body=lxml.html.tostring(footer_node), base_url=base_url))
            header = layout._render(dict(subst=True, body=lxml.html.tostring(header_node), base_url=base_url))

        if type == 'safety_report':
            return covers, intros, bodies, backcovers, res_ids, header, footer, specific_paperformat_args

        elif type == 'snapshot_report':
            return covers, intros, bodies, header, footer, specific_paperformat_args

        else:
            return bodies, res_ids, header, footer, specific_paperformat_args

    @api.model
    def _run_wkhtmltopdf(
            self,
            covers,
            intros,
            bodies,
            backcovers,
            header=None,
            footer=None,
            landscape=False,
            specific_paperformat_args=None,
            set_viewport_size=False,
            type=None):
        '''Execute wkhtmltopdf as a subprocess in order to convert html given in input into a pdf
        document.

        :param bodies: The html bodies of the report, one per page.
        :param header: The html header of the report containing all headers.
        :param footer: The html footer of the report containing all footers.
        :param landscape: Force the pdf to be rendered under a landscape format.
        :param specific_paperformat_args: dict of prioritized paperformat arguments.
        :param set_viewport_size: Enable a viewport sized '1024x1280' or '1280x1024' depending of landscape arg.
        :return: Content of the pdf as a string
        '''
        paperformat_id = self.get_paperformat()

        # Build the base command args for wkhtmltopdf bin
        command_args, cover_command_args, backcover_command_args = self._build_wkhtmltopdf_args(
            paperformat_id,
            landscape,
            specific_paperformat_args=specific_paperformat_args,
            set_viewport_size=set_viewport_size)

        files_command_args = []
        cover_args = []
        backcover_args = []
        temporary_files = []
        intro_args = []
        additional_args = []
        toc_args = []
        toc_paths = []
        version, error = subprocess.Popen([_get_wkhtmltopdf_bin(), '--version'], stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE).communicate()
        if error:
            raise error.decode("utf-8")
        version = version.decode("utf-8")
        version = [float(s) for s in re.findall(r'-?\d+\.?\d*', version)]

        if header:
            head_file_fd, head_file_path = tempfile.mkstemp(suffix='.html', prefix='report.header.tmp.')
            with closing(os.fdopen(head_file_fd, 'wb')) as head_file:
                head_file.write(header)
            temporary_files.append(head_file_path)
            files_command_args.extend(['--header-html', head_file_path])

        if footer:
            foot_file_fd, foot_file_path = tempfile.mkstemp(suffix='.html', prefix='report.footer.tmp.')
            with closing(os.fdopen(foot_file_fd, 'wb')) as foot_file:
                foot_file.write(footer)
            temporary_files.append(foot_file_path)
            files_command_args.extend(['--footer-html', foot_file_path])

        cover_paths = []
        if covers:
            for i, cover in enumerate(covers):
                prefix = '%s%d.' % ('report.cover.tmp.', i)
                cover_file_fd, cover_file_path = tempfile.mkstemp(suffix='.html', prefix=prefix)
                with closing(os.fdopen(cover_file_fd, 'wb')) as cover_file:
                    cover_file.write(cover)
                cover_paths.append(cover_file_path)
                temporary_files.append(cover_file_path)
            if version[1] >= 6.0:
                cover_args.extend(['cover'])

        intro_paths = []
        if intros:
            for i, intro in enumerate(intros):
                prefix = '%s%d.' % ('report.intro.tmp.', i)
                intro_file_fd, intro_file_path = tempfile.mkstemp(suffix='.html', prefix=prefix)
                with closing(os.fdopen(intro_file_fd, 'wb')) as intro_file:
                    intro_file.write(intro)
                intro_paths.append(intro_file_path)
                temporary_files.append(intro_file_path)
            if version[1] >= 6.0:
                intro_args.extend(['page'])

        if paperformat_id.toc:
            toc_xsl_path = "/home/odoo/src/user/hawk_report/static/src/xsl/safety/custom-toc.xsl"
            if not os.path.exists(toc_xsl_path):
                toc_xsl_path = os.path.abspath("hawk_report/static/src/xsl/safety/custom-toc.xsl")
            # FOR DEBUG PURPOSES
            # dump_toc_xsl_path = os.path.abspath("hawk_report/static/src/xsl/default-toc.xsl")
            # toc_xml_path = os.path.abspath("hawk_report/templates/safety/outline-toc.xml")
            # test_pdf_path = os.path.abspath("hawk_report/static/src/pdf/test.pdf")
            if version[1] >= 6.0:
                toc_args.extend(['toc', '--xsl-style-sheet'])
                toc_paths.append(toc_xsl_path)

        body_paths = []
        for i, body in enumerate(bodies):
            prefix = '%s%d.' % ('report.body.tmp.', i)
            body_file_fd, body_file_path = tempfile.mkstemp(suffix='.html', prefix=prefix)
            with closing(os.fdopen(body_file_fd, 'wb')) as body_file:
                body_file.write(body)
            body_paths.append(body_file_path)
            temporary_files.append(body_file_path)

        backcover_paths = []
        if backcovers:
            for i, backcover in enumerate(backcovers):
                prefix = '%s%d.' % ('report.backcover.tmp.', i)
                backcover_file_fd, backcover_file_path = tempfile.mkstemp(suffix='.html', prefix=prefix)
                with closing(os.fdopen(backcover_file_fd, 'wb')) as backcover_file:
                    backcover_file.write(backcover)
                backcover_paths.append(backcover_file_path)
                temporary_files.append(backcover_file_path)
        if version[1] >= 6.0:
            backcover_args.extend(['cover'])

        merger = PdfFileMerger()

        sections = ['content']

        if intros:
            sections.insert(0, 'intro')

        if paperformat_id.cover:
            sections.insert(0, 'cover')
            if version[1] >= 6.0:
                additional_args.extend(['--page-offset', '3'])

        if paperformat_id.backcover:
            sections.insert(len(sections), 'backcover')

        pdf_report_fd, pdf_report_path = tempfile.mkstemp(suffix='.pdf', prefix='report.tmp.')
        os.close(pdf_report_fd)
        temporary_files.append(pdf_report_path)

        for section in sections:

            pdf_content_fd, pdf_content_path = tempfile.mkstemp(suffix='.pdf', prefix=section + '.tmp.')
            os.close(pdf_content_fd)
            temporary_files.append(pdf_content_path)

            main_args = command_args + additional_args + files_command_args + toc_args + toc_paths + body_paths + [
                pdf_content_path]

            if section == 'cover':
                main_args = cover_command_args + cover_args + cover_paths + [pdf_content_path]

            if section == 'intro':
                main_args = command_args + files_command_args + intro_args + intro_paths + [pdf_content_path]

            if section == 'backcover':
                main_args = cover_command_args + backcover_args + backcover_paths + [pdf_content_path]

            try:
                wkhtmltopdf = [_get_wkhtmltopdf_bin()] + main_args
                _logger.info(str(wkhtmltopdf))
                process = subprocess.Popen(wkhtmltopdf, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                out, err = process.communicate()

                if process.returncode not in [0, 1]:
                    if process.returncode == -11:
                        message = _(
                            'Wkhtmltopdf failed (error code: %s). Memory limit too low or maximum file number of subprocess reached. Message : %s')
                    else:
                        message = _('Wkhtmltopdf failed (error code: %s). Message: %s')
                    _logger.warning(message, process.returncode, err[-1000:])
                    raise UserError(message % (str(process.returncode), err[-1000:]))
                else:
                    if err:
                        _logger.warning('wkhtmltopdf: %s' % err)

                process.terminate()
            except:
                raise

            try:
                # import_bookmarks=False is a temporary solution.
                merger.append(str(pdf_content_path), import_bookmarks=False)
            except Exception as err:
                _logger.warning('pypdf2: %s' % err)

        merger.write(str(pdf_report_path))
        merger.close()

        with open(pdf_report_path, 'rb') as pdf_document:
            pdf_file = pdf_document.read()

        # Manual cleanup of the temporary files
        for temporary_file in temporary_files:
            try:
                os.unlink(temporary_file)
            except (OSError, IOError):
                _logger.error('Error when trying to remove file %s' % temporary_file)

        return pdf_file

    def _render_qweb_pdf(self, res_ids=None, data=None, type=None, components=None):
        if not data:
            data = {}
        data.setdefault('report_type', 'pdf')

        # access the report details with sudo() but evaluation context as current user
        self_sudo = self.sudo()

        # In case of test environment without enough workers to perform calls to wkhtmltopdf,
        # fallback to render_html.
        if (tools.config['test_enable'] or tools.config['test_file']) and not self.env.context.get(
                'force_report_rendering'):
            return self._render_qweb_html(res_ids, data=data)

        # As the assets are generated during the same transaction as the rendering of the
        # templates calling them, there is a scenario where the assets are unreachable: when
        # you make a request to read the assets while the transaction creating them is not done.
        # Indeed, when you make an asset request, the controller has to read the `ir.attachment`
        # table.
        # This scenario happens when you want to print a PDF report for the first time, as the
        # assets are not in cache and must be generated. To workaround this issue, we manually
        # commit the writes in the `ir.attachment` table. It is done thanks to a key in the context.
        context = dict(self.env.context)
        if not config['test_enable']:
            context['commit_assetsbundle'] = True

        # Disable the debug mode in the PDF rendering in order to not split the assets bundle
        # into separated files to load. This is done because of an issue in wkhtmltopdf
        # failing to load the CSS/Javascript resources in time.
        # Without this, the header/footer of the reports randomly disappear
        # because the resources files are not loaded in time.
        # https://github.com/wkhtmltopdf/wkhtmltopdf/issues/2083
        context['debug'] = False

        # The test cursor prevents the use of another environment while the current
        # transaction is not finished, leading to a deadlock when the report requests
        # an asset bundle during the execution of test scenarios. In this case, return
        # the html version.
        if isinstance(self.env.cr, TestCursor):
            return self_sudo.with_context(context)._render_qweb_html(res_ids, data=data)[0]

        save_in_attachment = OrderedDict()
        # Maps the streams in `save_in_attachment` back to the records they came from
        stream_record = dict()
        if res_ids:
            # Dispatch the records by ones having an attachment and ones requesting a call to
            # wkhtmltopdf.
            Model = self.env[self_sudo.model]
            record_ids = Model.browse(res_ids)
            wk_record_ids = Model
            if self_sudo.attachment:
                for record_id in record_ids:
                    attachment = self_sudo.retrieve_attachment(record_id)
                    if attachment:
                        stream = self_sudo._retrieve_stream_from_attachment(attachment)
                        save_in_attachment[record_id.id] = stream
                        stream_record[stream] = record_id
                    if not self_sudo.attachment_use or not attachment:
                        wk_record_ids += record_id
            else:
                wk_record_ids = record_ids
            res_ids = wk_record_ids.ids

        # A call to wkhtmltopdf is mandatory in 2 cases:
        # - The report is not linked to a record.
        # - The report is not fully present in attachments.
        if save_in_attachment and not res_ids:
            _logger.info('The PDF report has been generated from attachments.')
            self._raise_on_unreadable_pdfs(save_in_attachment.values(), stream_record)
            return self_sudo._post_pdf(save_in_attachment), 'pdf'

        if self.get_wkhtmltopdf_state() == 'install':
            # wkhtmltopdf is not installed
            # the call should be catched before (cf /report/check_wkhtmltopdf) but
            # if get_pdf is called manually (email template), the check could be
            # bypassed
            raise UserError(_("Unable to find Wkhtmltopdf on this system. The PDF can not be created."))

        html = self_sudo.with_context(context)._render_qweb_html(res_ids, data=data)[0]

        # Ensure the current document is utf-8 encoded.
        html = html.decode('utf-8')

        if type == 'safety_report':
            covers, intros, bodies, backcovers, html_ids, header, footer, specific_paperformat_args = self_sudo.with_context(context)._prepare_html(html, type=type)
            pdf_content = self._run_wkhtmltopdf(
                covers,
                intros,
                bodies,
                backcovers,
                header=header,
                footer=footer,
                landscape=context.get('landscape'),
                specific_paperformat_args=specific_paperformat_args,
                set_viewport_size=context.get('set_viewport_size'),
                type=type
            )

        elif type == 'snapshot_report':
            covers, intros, bodies, header, footer, specific_paperformat_args = self_sudo.with_context(context)._prepare_html(html, type=type)
            print('---header---', header)
            print('---covers---', covers)
            print('---bodies---', bodies)
            print('---intros---', intros)
            print('---footer---', footer)
            pdf_content = self._run_wkhtmltopdf(
                covers=covers,
                intros=intros,
                bodies=bodies,
                backcovers=None,
                header=header,
                footer=footer,
                landscape=context.get('landscape'),
                specific_paperformat_args=specific_paperformat_args,
                set_viewport_size=context.get('set_viewport_size'),
                type=type
            )

        else:

            bodies, html_ids, header, footer, specific_paperformat_args = self_sudo.with_context(context)._prepare_html(html)

            if self_sudo.attachment and set(res_ids) != set(html_ids):
                raise UserError(_("The report's template '%s' is wrong, please contact your administrator. \n\n"
                    "Can not separate file to save as attachment because the report's template does not contains the attributes 'data-oe-model' and 'data-oe-id' on the div with 'article' classname.") %  self.name)

            pdf_content = self._run_wkhtmltopdf(
                covers=None,
                intros=None,
                bodies=bodies,
                backcovers=None,
                header=header,
                footer=footer,
                landscape=context.get('landscape'),
                specific_paperformat_args=specific_paperformat_args,
                set_viewport_size=context.get('set_viewport_size'),
            )

        if self_sudo.attachment and res_ids:
            self._raise_on_unreadable_pdfs(save_in_attachment.values(), stream_record)
            _logger.info(
                'The PDF report has been generated for model: %s, records %s.' % (self_sudo.model, str(res_ids)))
            return self_sudo._post_pdf(save_in_attachment, pdf_content=pdf_content, res_ids=html_ids), 'pdf'

        return pdf_content, 'pdf'

    def report_action(self, docids, data=None, config=False):
        """Return an action of type ir.actions.report.

        :param docids: id/ids/browse record of the records to print (if not used, pass an empty list)
        :param report_name: Name of the template to generate an action for
        """
        context = self.env.context
        if docids:
            if isinstance(docids, models.Model):
                active_ids = docids.ids
            elif isinstance(docids, int):
                active_ids = [docids]
            elif isinstance(docids, list):
                active_ids = docids
            context = dict(self.env.context, active_ids=active_ids)

        report_action = {
            'context': context,
            'data': data,
            'type': 'ir.actions.report',
            'report_name': self.report_name,
            'report_type': self.report_type,
            'report_file': self.report_file,
            'name': self.name,
        }

        # Opens preview dialog when user is admin
        discard_logo_check = self.env.context.get('discard_logo_check')
        if self.env.is_admin() and not self.env.company.external_report_layout_id and config and not discard_logo_check and self.report_name != 'Safety Module Report':
            action = self.env["ir.actions.actions"]._for_xml_id("web.action_base_document_layout_configurator")
            ctx = action.get('context')
            py_ctx = json.loads(ctx) if ctx else {}
            report_action['close_on_report_download'] = True
            py_ctx['report_action'] = report_action
            action['context'] = py_ctx
            return action

        return report_action
