# -*- coding: utf-8 -*-
from odoo import tools, _
from odoo import api, fields, models
from odoo.exceptions import ValidationError, UserError
import base64
from slugify import slugify
import logging

_logger = logging.getLogger(__name__)


class SafetyReport(models.AbstractModel):
    _name = 'report.hawk_report.safety_module_report_template'
    _description = 'report.hawk_report.safety_module_report_template abstract model'

    @api.model
    def _get_report_values(self, docids, data=None):
        if docids:
            docs = self.env[data['model']].browse(docids)
        else:
            docs = self.env[data['model']].browse(data['id'])
            docids = self.env[data['model']].browse(data['id'])
        merged_df, coeff_count, sum_raw_mark, count, mean_raw_mark, cumulative_raw_mark, correlated_mark, cumulative_weighted_mark = data['dataframes']
        mean_correlated_mark = round(correlated_mark / coeff_count, 3)
        mean_mean_raw_mark = round(mean_raw_mark / 7, 3)
        mean_sum_raw_mark = round(sum_raw_mark / int(count), 3)
        return {
            'doc_ids': docids,
            'doc_model': data['model'],
            'docs': docs,
            'data': data,
            'total_weights': coeff_count,
            'total_score': sum_raw_mark,
            'count': count,
            'total_mean_raw_mark': format(round(mean_raw_mark, 2), '.2f'),
            'total_cumulative_raw_mark': format(round(cumulative_raw_mark, 2), '.2f'),
            'total_weighted_mean': format(round(correlated_mark, 2), '.2f'),
            'total_cumulative_weighted_mark': format(round(cumulative_weighted_mark, 2), '.2f'),
            'ave_total_weighted_mean': format(round(mean_correlated_mark, 2), '.2f'),
            'ave_mean_raw_mark': format(round(mean_mean_raw_mark, 2), '.2f'),
            'ave_sum_raw_mark': format(round(mean_sum_raw_mark, 2), '.2f'),
            'dataframes': merged_df,
            'values': data['values'],
            'version': data['version'],
            'components': data['components'],
            'disclaimer': data['disclaimer'],
            'executive_content': data['executive_content'],
            'copyright': data['copyright'],
            'assessment_context': data['assessment_context'],
            'results_glance': data['results_glance'],
            'score_method': data['score_method'],
            'assessment_criteria': data['assessment_criteria'],
            'repeated_headers': data['repeated_headers'],
            # 'tnc': data['tnc'],
            'results_analysis_context_1': data['results_analysis_context_1'],
            'results_analysis_context_2_intro': data['results_analysis_context_2_intro'],
            'results_analysis_context_2_content': data['results_analysis_context_2_content'],
            'results_analysis_context_3_intro': data['results_analysis_context_3_intro'],
            'results_analysis_context_3_content': data['results_analysis_context_3_content'],
            'results_analysis_context_4_intro': data['results_analysis_context_4_intro'],
            'results_analysis_context_4_content': data['results_analysis_context_4_content'],
            'results_analysis_context_5_intro': data['results_analysis_context_5_intro'],
            'results_analysis_context_5_content': data['results_analysis_context_5_content'],
            'img_category_count_bar': data['img_category_count_bar'],
            'img_weight_count_bar': data['img_weight_count_bar'],
            'img_weight_count_bar_large': data['img_weight_count_bar_large'],
            'img_mean_score_bar': data['img_mean_score_bar'],
            'img_mean_score_bar_large': data['img_mean_score_bar_large'],
            'img_weighted_mean_score_bar': data['img_weighted_mean_score_bar'],
            'img_weighted_mean_score_bar_large': data['img_weighted_mean_score_bar_large'],
            'img_category_count_pie': data['img_category_count_pie'],
            'img_mean_raw_mark_pie': data['img_mean_raw_mark_pie'],
            'img_weighted_mean_raw_mark_pie': data['img_weighted_mean_raw_mark_pie'],
            'img_weight_count_radar': data['img_weight_count_radar'],
            'img_mean_score_radar': data['img_mean_score_radar'],
            'img_linegraph_context': data['img_linegraph_context'],
            'img_linegraph_leadership': data['img_linegraph_leadership'],
            'img_linegraph_planning': data['img_linegraph_planning'],
            'img_linegraph_support': data['img_linegraph_support'],
            'img_linegraph_operation': data['img_linegraph_operation'],
            'img_linegraph_performance': data['img_linegraph_performance'],
            'img_linegraph_improvement': data['img_linegraph_improvement'],
        }
