# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import os
import base64
import logging

_logger = logging.getLogger(__name__)


class BaseDocumentLayout(models.TransientModel):
    _inherit = 'base.document.layout'

    disable = fields.Boolean(default=True)

    @api.depends('report_layout_id', 'logo', 'font', 'primary_color', 'secondary_color', 'report_header',
                 'report_footer')
    def _compute_preview(self):
        """ compute a qweb based preview to display on the wizard """

        styles = self._get_asset_style()

        for wizard in self:
            if wizard.report_layout_id and not wizard.disable:
                preview_css = self._get_css_for_preview(styles, wizard.id)
                ir_ui_view = wizard.env['ir.ui.view']
                wizard.preview = ir_ui_view._render_template('web.report_invoice_wizard_preview',
                                                             {'company': wizard, 'preview_css': preview_css})
            else:
                wizard.preview = False


class ReportInput(models.TransientModel):
    _name = 'wizard.report'
    _description = 'wizard.report transient model'

    @api.model
    def default_get(self, fields):
        res = super(ReportInput, self).default_get(fields)
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('analysis_id'))
        latestReportLog = self.env['hawk.analysis.report.log'].browse(self.env.context.get('reportChangeLog_id'))

        print('default_get', analysis)
        if not ((self.env.user.id == analysis.team_leader_id.id) or (
                self.env.user.id == analysis.safety_analyst_id.id)):
            raise ValidationError('Sorry only the assigned team leader or analyst are allowed to generate report.')

        if latestReportLog:
            res['executive_summary'] = latestReportLog.executive_summary
            res['assessment_context'] = latestReportLog.assessment_context
            res['results_analysis_context_1'] = latestReportLog.results_analysis_context_1
            res['img_weight_count_bar_large'] = latestReportLog.img_weight_count_bar_large
            res['results_analysis_context_2_intro'] = latestReportLog.results_analysis_context_2_intro
            res['results_analysis_context_2_content'] = latestReportLog.results_analysis_context_2_content
            res['img_mean_score_bar_large'] = latestReportLog.img_mean_score_bar_large
            res['results_analysis_context_3_intro'] = latestReportLog.results_analysis_context_3_intro
            res['results_analysis_context_3_content'] = latestReportLog.results_analysis_context_3_content
            res['img_weighted_mean_score_bar_large'] = latestReportLog.img_weighted_mean_score_bar_large
            res['results_analysis_context_4_intro'] = latestReportLog.results_analysis_context_4_intro
            res['results_analysis_context_4_content'] = latestReportLog.results_analysis_context_4_content
            res['img_mean_raw_mark_pie'] = latestReportLog.img_mean_raw_mark_pie
            res['img_weighted_mean_raw_mark_pie'] = latestReportLog.img_weighted_mean_raw_mark_pie
            res['results_analysis_context_5_intro'] = latestReportLog.results_analysis_context_5_intro
            res['results_analysis_context_5_content'] = latestReportLog.results_analysis_context_5_content

        return res

    stage = fields.Selection([('executive', 'Executive Summary'),
                              ('assessment', 'Assessment Context'),
                              ('results', 'Results Analysis')], default="executive", required=True)

    allow_back = fields.Boolean(compute="_compute_allow_back")

    executive_summary = fields.Html(string='Executive Summary', readonly=True)
    assessment_context = fields.Html(string='Assessment Context', readonly=True)
    results_analysis_context_1 = fields.Html(string='Results Analysis')
    img_weight_count_bar_large = fields.Binary()
    results_analysis_context_2_intro = fields.Html(string='Considered Weighting Coefficient')
    results_analysis_context_2_content = fields.Html(string='Second Context')
    img_mean_score_bar_large = fields.Binary()
    results_analysis_context_3_intro = fields.Html(string='Average Raw Mark per Category')
    results_analysis_context_3_content = fields.Html(string='Third Context')
    img_weighted_mean_score_bar_large = fields.Binary()
    results_analysis_context_4_intro = fields.Html(string='Average Corrected Mark per Category')
    results_analysis_context_4_content = fields.Html(string='Fourth Context')
    img_mean_raw_mark_pie = fields.Binary()
    img_weighted_mean_raw_mark_pie = fields.Binary()
    results_analysis_context_5_intro = fields.Html(string='Total Score Share for Tenderer')
    results_analysis_context_5_content = fields.Html(string='Fifth Context')

    @api.depends("stage")
    def _compute_allow_back(self):
        for record in self:
            record.allow_back = getattr(record, "stage_previous_%s" % record.stage, False)

    def open_next(self):
        stage_method = getattr(self, "stage_exit_{}".format(self.stage), None)
        if stage_method is None:
            raise NotImplementedError("No method defined for stage {}".format(self.stage))
        stage_method()
        return self._reopen_self()

    def open_previous(self):
        stage_method = getattr(self, "stage_previous_{}".format(self.stage), None)
        if stage_method is None:
            raise NotImplementedError("No method defined for stage {}".format(self.stage))
        stage_method()
        return self._reopen_self()

    def _reopen_self(self):
        return {
            'name': _("Edit Report"),
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "res_id": self.id,
            "view_mode": "form",
            "target": "new",
        }

    def stage_exit_executive(self):
        self.stage = 'assessment'

    def stage_exit_assessment(self):
        self.stage = 'results'

    def stage_previous_assessment(self):
        self.stage = 'executive'

    def stage_previous_results(self):
        self.stage = 'assessment'

    def compute_remarks(self, editor):
        latestReportLog = self.env['hawk.analysis.report.log'].browse(self.env.context.get('reportChangeLog_id'))
        remarks = ""
        try:
            if self.executive_summary != latestReportLog.executive_summary:
                remarks += editor.name + " edited the executive summary. \n"
            if self.assessment_context != latestReportLog.assessment_context:
                remarks += editor.name + " edited the assessment context. \n"
            if self.results_analysis_context_1 != latestReportLog.results_analysis_context_1 or \
                self.results_analysis_context_2_intro != latestReportLog.results_analysis_context_2_intro or \
                self.results_analysis_context_2_content != latestReportLog.results_analysis_context_2_content or \
                self.results_analysis_context_3_intro != latestReportLog.results_analysis_context_3_intro or \
                self.results_analysis_context_3_content != latestReportLog.results_analysis_context_3_content or \
                self.results_analysis_context_4_intro != latestReportLog.results_analysis_context_4_intro or \
                self.results_analysis_context_4_content != latestReportLog.results_analysis_context_4_content or \
                self.results_analysis_context_5_intro != latestReportLog.results_analysis_context_5_intro or \
                self.results_analysis_context_5_content != latestReportLog.results_analysis_context_5_content:
                remarks += editor.name + " edited the results analysis. \n"
            if self.img_weight_count_bar_large != latestReportLog.img_weight_count_bar_large:
                remarks += editor.name + " replaced the first graph in results analysis. \n"
            if self.img_mean_score_bar_large != latestReportLog.img_mean_score_bar_large:
                remarks += editor.name + " replaced the second graph in results analysis. \n"
            if self.img_weighted_mean_score_bar_large != latestReportLog.img_weighted_mean_score_bar_large:
                remarks += editor.name + " replaced the third graph in results analysis. \n"
            if self.img_mean_raw_mark_pie != latestReportLog.img_mean_raw_mark_pie:
                remarks += editor.name + " replaced the fourth graph in results analysis. \n"
            if self.img_weighted_mean_raw_mark_pie != latestReportLog.img_weighted_mean_raw_mark_pie:
                remarks += editor.name + " replaced the fifth graph in results analysis. \n"

        except Exception as e:
            _logger.error(str(e))

        if remarks != "":
            return remarks
        else:
            return "No changes have been made."

    def update_analysis(self, analysis, reportChangeLog):

        newReportLog = self.env['hawk.analysis.report.log'].create({
            'analysis_id': analysis.id,
            'remarks': self.compute_remarks(self.env.user),
            'executive_summary': reportChangeLog.executive_summary,
            'assessment_context': reportChangeLog.assessment_context,
            'results_analysis_context_1': self.results_analysis_context_1,
            'img_weight_count_bar_large': self.img_weight_count_bar_large,
            'results_analysis_context_2_intro': self.results_analysis_context_2_intro,
            'results_analysis_context_2_content': self.results_analysis_context_2_content,
            'img_mean_score_bar_large': self.img_mean_score_bar_large,
            'results_analysis_context_3_intro': self.results_analysis_context_3_intro,
            'results_analysis_context_3_content': self.results_analysis_context_3_content,
            'img_weighted_mean_score_bar_large': self.img_weighted_mean_score_bar_large,
            'results_analysis_context_4_intro': self.results_analysis_context_4_intro,
            'results_analysis_context_4_content': self.results_analysis_context_4_content,
            'img_mean_raw_mark_pie': self.img_mean_raw_mark_pie,
            'img_weighted_mean_raw_mark_pie': self.img_weighted_mean_raw_mark_pie,
            'results_analysis_context_5_intro': self.results_analysis_context_5_intro,
            'results_analysis_context_5_content': self.results_analysis_context_5_content,
            'img_category_count_pie': reportChangeLog.img_category_count_pie,
            'img_weight_count_radar': reportChangeLog.img_weight_count_radar,
            'img_mean_score_radar': reportChangeLog.img_mean_score_radar,
            'img_linegraph_context': reportChangeLog.img_linegraph_context,
            'img_linegraph_leadership': reportChangeLog.img_linegraph_leadership,
            'img_linegraph_planning': reportChangeLog.img_linegraph_planning,
            'img_linegraph_support': reportChangeLog.img_linegraph_support,
            'img_linegraph_operation': reportChangeLog.img_linegraph_operation,
            'img_linegraph_performance': reportChangeLog.img_linegraph_performance,
            'img_linegraph_improvement': reportChangeLog.img_linegraph_improvement,
        })

        return newReportLog

    def action_generate_report(self):
        self.ensure_one()
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('analysis_id'))
        analysis = analysis.sudo()
        # get current ['hawk.analysis.report.log'] record
        reportChangeLog = self.env['hawk.analysis.report.log'].browse(self.env.context.get('reportChangeLog_id'))
        # update views in the dialog: contents
        currentReportLog = self.update_analysis(analysis, reportChangeLog)

        if self.env.context.get('new_report'):
            reportChangeLog.sudo().unlink()

        ctx = self.env.context.get('ctx')
        template = None
        if analysis.analysis_type_id:
            template = "hawk_report.action_%s_module_report" % analysis.analysis_type_id.name.lower()

        type = self.env['sign.template.type'].sudo().search(
            [('name', '=', '%s Module Report' % (analysis.analysis_type))])
        components = analysis.config_id.get_report_template_component(analysis)
        assessment_criteria_content, repeated_headers = analysis.config_id.get_assessment_criteria(analysis)

        # make values to 2 decimal places
        for x, y in ctx['dataframes'][0].items():
            y['raw_mean'] = format(y.get('raw_mean'), '.2f')
            y['cumulative_raw_mean'] = format(y.get('cumulative_raw_mean'), '.2f')
            y['weighted_mean'] = format(y.get('weighted_mean'), '.2f')
            y['cumulative_weighted_mean'] = format(y.get('cumulative_weighted_mean'), '.2f')

        data = {
            'id': analysis.id,
            'model': analysis._name,
            'form': analysis.read()[0],
            'dataframes': ctx['dataframes'],
            'values': ctx['values'],
            'version': len(analysis.sign_request_ids.sudo().search(
                [('analysis_id.id', '=', analysis.id), ('template_id.type.id', '=', type.id)])) + 1,
            'components': components,
            'disclaimer': analysis.config_id.get_disclaimer(analysis),
            'copyright': analysis.config_id.get_copyright(analysis),
            'executive_content': currentReportLog.executive_summary,
            'assessment_context': currentReportLog.assessment_context,
            'results_glance': analysis.config_id.get_results_glance(analysis),
            'score_method': analysis.config_id.get_score_methodology(analysis),
            'assessment_criteria': assessment_criteria_content,
            # 'tnc': analysis.config_id.get_terms_and_conditions(analysis),
            'repeated_headers': repeated_headers,
            'results_analysis_context_1': currentReportLog.results_analysis_context_1,
            'results_analysis_context_2_intro': currentReportLog.results_analysis_context_2_intro,
            'results_analysis_context_2_content': currentReportLog.results_analysis_context_2_content,
            'results_analysis_context_3_intro': currentReportLog.results_analysis_context_3_intro,
            'results_analysis_context_3_content': currentReportLog.results_analysis_context_3_content,
            'results_analysis_context_4_intro': currentReportLog.results_analysis_context_4_intro,
            'results_analysis_context_4_content': currentReportLog.results_analysis_context_4_content,
            'results_analysis_context_5_intro': currentReportLog.results_analysis_context_5_intro,
            'results_analysis_context_5_content': currentReportLog.results_analysis_context_5_content,
            'img_category_count_bar': currentReportLog.img_category_count_bar,
            'img_weight_count_bar': currentReportLog.img_weight_count_bar,
            'img_weight_count_bar_large': currentReportLog.img_weight_count_bar_large,
            'img_mean_score_bar': currentReportLog.img_mean_score_bar,
            'img_mean_score_bar_large': currentReportLog.img_mean_score_bar_large,
            'img_weighted_mean_score_bar': currentReportLog.img_weighted_mean_score_bar,
            'img_weighted_mean_score_bar_large': currentReportLog.img_weighted_mean_score_bar_large,
            'img_category_count_pie': currentReportLog.img_category_count_pie,
            'img_mean_raw_mark_pie': currentReportLog.img_mean_raw_mark_pie,
            'img_weighted_mean_raw_mark_pie': currentReportLog.img_weighted_mean_raw_mark_pie,
            'img_weight_count_radar': currentReportLog.img_weight_count_radar,
            'img_mean_score_radar': currentReportLog.img_mean_score_radar,
            'img_linegraph_context': currentReportLog.img_linegraph_context,
            'img_linegraph_leadership': currentReportLog.img_linegraph_leadership,
            'img_linegraph_planning': currentReportLog.img_linegraph_planning,
            'img_linegraph_support': currentReportLog.img_linegraph_support,
            'img_linegraph_operation': currentReportLog.img_linegraph_operation,
            'img_linegraph_performance': currentReportLog.img_linegraph_performance,
            'img_linegraph_improvement': currentReportLog.img_linegraph_improvement,
        }

        # generate the pdf of report
        pdf_content, __ = self.env.ref(template)._render_qweb_pdf(analysis.id, data=data, type='safety_report')

        # create sign.template for the pdf
        template = analysis.create_sign_template(pdf_content)

        # Update the Timeline Tab
        analysis.analysis_timeline_ids.create([{
            'analysis_id': analysis.id,
            'details': 'Generate Report',
            'date': fields.Datetime.now(),
            'res_person_id': self.env.user.id,
            'remarks': self.env.user.name + ' generated the report.',
        }])

        # Alerts
        odoobot = self.env.ref('base.partner_root')
        analysis.message_post(
            subject='Generate Report',
            body='A new report was generated.',
            message_type='comment',
            subtype_xmlid='mail.mt_comment',
            notify_by_email=False,
            author_id=odoobot.id,
            partner_ids=[analysis.team_leader_id.partner_id.id, analysis.safety_analyst_id.partner_id.id])

        # Check who's editing the report
        if self.env.user.id == analysis.team_leader_id.id:
            self.action_send_email_notification('generate_report_by_tl_template', analysis)
        else:
            self.action_send_email_notification('generate_report_by_analyst_template', analysis)

        # create ['sign.request'] record for the sign.template of report
        analysis.create_sign_request(template, currentReportLog)

        # assigns all sign.request records: if none, false.
        module_report_requests = analysis.sign_request_ids.sudo().search(
            [('analysis_id.id', '=', analysis.id), ('template_id.type.id', '=', type.id)])

        _logger.info(str([rec.reference for rec in module_report_requests]))

        # If there are multiple versions. sign.item must be duplicated to the new version
        if len(module_report_requests) > 1:
            analysis.duplicate_sign_request(module_report_requests)

        if analysis.team_leader_id.id == self.env.user.id:
            return analysis.write({'state': 'tl', 'is_generate_done': True})
        else:
            return analysis.write({'is_generate_done': True})

    def action_send_email_notification(self, template, new_id=None):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(new_id.id)
        self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(new_id.id, force_send=True)
