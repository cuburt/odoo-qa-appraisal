# -*- coding: utf-8 -*-

from odoo import tools, _
from odoo import api, fields, models
from odoo.exceptions import ValidationError, UserError


class QaReject(models.TransientModel):
    _name = 'qa.reject'
    _description = 'QA Reject'

    analysis_id = fields.Many2one('hawk.analysis')
    remarks = fields.Text(string='Remarks', required=True)
    notify_analyst = fields.Boolean(string='Include analyst on the email notification?', default=False)

    @api.model
    def default_get(self, fields):
        res = super(QaReject, self).default_get(fields)
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
        if self.env.user.id != analysis.qa_specialist_id.id:
            raise ValidationError('Sorry only the assigned QA/QC Specialist is allowed to return the report to Team Leader.')
        return res

    def action_qa_reject(self):
        print('action_qa_reject', self)
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
        request = analysis.sign_request_ids[len(analysis.sign_request_ids) - 1]

        # Update the Reports Tab
        request.sudo().remarks = self.remarks
        # res = [{
        #     'analysis_id': analysis.id,
        #     'revision_date': fields.Date.today(),
        #     # 'report': '-',
        #     'res_person_id': analysis.qa_specialist_id.id,
        #     'remarks': self.remarks,
        # }]
        # analysis.analysis_rev_ids.create(res)

        # Update the Timeline Tab
        vals = [{
            'analysis_id': analysis.id,
            'details': 'QA Fail',
            'date': fields.Datetime.now(),
            'res_person_id': analysis.qa_specialist_id.id,
            'remarks': self.remarks,
        }]
        analysis.analysis_timeline_ids.create(vals)

        # Alerts
        odoobot = self.env.ref('base.partner_root')
        analysis.message_post(
            subject='QA Fail',
            body=analysis.qa_specialist_id.name + ' return the report to the team leader for revision.',
            message_type='comment',
            subtype_xmlid='mail.mt_comment',
            notify_by_email=False,
            author_id=odoobot.id,
            partner_ids=[4, analysis.team_leader_id.partner_id.id])

        analysis.write({
            'state': 'tl',
            'is_qa_reject': True,
        })
        if self.notify_analyst:
            self.action_send_email_notification('qa_reject_template', analysis, self.remarks)
        else:
            self.action_send_email_notification('qa_reject_1_template', analysis, self.remarks)

    def action_send_email_notification(self, template, analysis_id, remarks):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(analysis_id.id)
        self.env['mail.template'].browse(template_id).with_context(url=url, remarks=remarks).send_mail(analysis_id.id, force_send=True)


class QaPass(models.TransientModel):
    _name = 'qa.pass'
    _description = 'QA Pass'

    analysis_id = fields.Many2one('hawk.analysis')
    remarks = fields.Text(string='Remarks', required=True)
    date_qa_pass = fields.Date(string='Date', readonly=True, default=fields.Date.today())

    @api.model
    def default_get(self, fields):
        res = super(QaPass, self).default_get(fields)
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
        if self.env.user.id != analysis.qa_specialist_id.id:
            raise ValidationError('Sorry only the assigned QA/QC Specialist is allowed to send the report to the manager.')
        return res

    def check_if_signed(self, analysis, request):
        request_item = request.request_item_ids.search([('sign_request_id.id', '=', request.id),
                                                        ('role_id', '=', self.env['sign.item.role'].sudo().search(
                                                            [('name', '=', 'Quality Control')]).id),
                                                        ('partner_id.id', '=', analysis.qa_specialist_id.partner_id.id)])
        print('request_item', request_item)
        return request_item.state == 'completed'

    def action_qa_pass(self):
        print('action_qa_pass', self)
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
        request = analysis.sign_request_ids[len(analysis.sign_request_ids) - 1]

        if not self.check_if_signed(analysis, request):
            raise UserError(_('Please affix your signature on the latest report before submitting. Thank you.'))

        request.sudo().remarks = self.remarks
        # Update the Reports Tab
        # res = [{
        #     'analysis_id': analysis.id,
        #     'revision_date': fields.Date.today(),
        #     # 'report': '-',
        #     'res_person_id': analysis.qa_specialist_id.id,
        #     'remarks': self.remarks,
        # }]
        # analysis.analysis_rev_ids.create(res)

        vals = [{
            'analysis_id': analysis.id,
            'details': 'QA Pass',
            'date': fields.Datetime.now(),
            'res_person_id': analysis.qa_specialist_id.id,
            'remarks': self.remarks,

        }]
        analysis.analysis_timeline_ids.create(vals)

        # Alerts
        odoobot = self.env.ref('base.partner_root')
        analysis.message_post(
            subject='QA Pass',
            body='The report pass the QA stage.',
            message_type='comment',
            subtype_xmlid='mail.mt_comment',
            notify_by_email=False,
            author_id=odoobot.id,
            partner_ids=[analysis.tender_manager_id.partner_id.id, analysis.team_leader_id.partner_id.id])

        analysis.write({
            'state': 'manager',
        })
        self.action_send_email_notification('qa_pass_template', analysis, self.remarks)

    def action_send_email_notification(self, template, analysis_id, remarks):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(analysis_id.id)
        self.env['mail.template'].browse(template_id).with_context(url=url, remarks=remarks).send_mail(analysis_id.id, force_send=True)
