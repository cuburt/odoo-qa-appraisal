# -*- coding: utf-8 -*-

from odoo import tools, _
from odoo import api, fields, models
from odoo.exceptions import ValidationError, UserError


class AssignQa(models.TransientModel):
    _name = 'assign.qa'
    _description = 'Assign QA'

    qa_specialist_id = fields.Many2one('res.users', string='QA/QC Specialist',
                                       domain=lambda self: [('groups_id', '=', self.env.ref('hawk_base.group_hawk_qa').id)], required=True)
    reason = fields.Text('Reason')
    is_qa_reject = fields.Boolean(default=False)

    @api.model
    def default_get(self, fields):
        res = super(AssignQa, self).default_get(fields)
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
        res['is_qa_reject'] = analysis.is_qa_reject

        if self.env.user.id != analysis.team_leader_id.id:
            raise ValidationError('Sorry only the assigned teamleader is allowed to submit the report to QA.')

        return res

    def action_assign_qa(self):
        print('action_assign_qa', self)
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
        request = analysis.sign_request_ids[len(analysis.sign_request_ids) - 1]

        if analysis.qa_specialist_id.id:
            if self.qa_specialist_id.id == analysis.qa_specialist_id.id:
                remarks = analysis.team_leader_id.name + ' submitted the revised report to the same QA Specialist.'
            else:
                remarks = analysis.team_leader_id.name + ' submitted the revised report to a new QA Specialist.'
            vals = [{
                'analysis_id': analysis.id,
                'details': 'Submit to QA',
                'date': fields.Datetime.now(),
                'res_person_id': analysis.team_leader_id.id,
                'remarks': remarks,
            }]
            analysis.analysis_timeline_ids.create(vals)
        else:
            vals = [{
                'analysis_id': analysis.id,
                'details': 'Submit to QA',
                'date': fields.Datetime.now(),
                'res_person_id': analysis.team_leader_id.id,
                'remarks': self.qa_specialist_id.name + ' is assigned to conduct QA for the report.',
            }]
            analysis.analysis_timeline_ids.create(vals)
        try:
            self.qa_specialist_id.partner_id.sudo().write({'function': 'Quality Control'})
        except:
            pass

        # Alerts
        odoobot = self.env.ref('base.partner_root')
        analysis.message_post(
            subject='Submit to QA',
            body=analysis.team_leader_id.name + ' submitted the report for QA.',
            message_type='comment',
            subtype_xmlid='mail.mt_comment',
            notify_by_email=False,
            author_id=odoobot.id,
            partner_ids=[4, self.qa_specialist_id.partner_id.id])

        analysis.qa_specialist_id = self.qa_specialist_id
        analysis.update_sign_request(request, self.qa_specialist_id)
        analysis.state = 'qa'

        self.action_send_email_notification('submit_to_qa_template', analysis, self.qa_specialist_id)

    def action_send_email_notification(self, template, new_id=None, qa_id=None):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(new_id.id)
        self.env['mail.template'].browse(template_id).with_context(url=url, qa_id=qa_id).send_mail(new_id.id, force_send=True)
