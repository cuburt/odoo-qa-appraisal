#-*- coding: utf-8 -*-
# from odoo import http
# from odoo.http import request
# import logging
#
# _logger = logging.getLogger()
#
# class HawkReport(http.Controller):
#     @http.route("/hawk_report/render_assets_pdf_iframe", type="json", auth="public")
#     def render_assets_pdf_iframe(self, **kw):
#         context = {'debug': kw.get('debug')} if 'debug' in kw else {}
#         return request.env['ir.ui.view'].sudo()._render_template('sign.compiled_assets_pdf_iframe', context)

