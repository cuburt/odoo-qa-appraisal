{
    'name': "hawk_report",
    'summary': "Hawk Report Module",
    'description': """
        Generate the pdf report for the Hawk module.
    """,
    'author': "Arman Castro | Cuburt Balanon",
    'website': "",
    'category': 'base',
    'version': '0.2',
    'depends': ['web', 'hawk_survey', 'hawk_sign'],

    'data': [
        'security/ir.model.access.csv',

        'data/sign_data.xml',
        'data/safety_report_template.xml',
        'data/default_report_config.xml',
        'data/report_config.xml',

        'wizards/qa_qa_views.xml',
        'wizards/assign_qa_views.xml',
        'wizards/report.xml',

        'views/assets.xml',
        'views/inherit_analysis_views.xml',
        'views/inherit_sign_request_views.xml',
        'views/views.xml',
        'views/web_report_templates.xml',
        'views/tender_views.xml',

        'templates/paperformat.xml',
        'templates/safety/template.xml',
        'templates/safety/safety_module_report_template.xml',
        'templates/safety/safety_summary_report_template.xml',
    ],
    'demo': [
    ],
}
