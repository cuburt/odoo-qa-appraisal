{
    'name': "hawk_base",
    'summary': "Hawk Base Module",
    'description': """
        Includes primary models and views for the Hawk module.
    """,
    'author': "Arman Castro | Cuburt Balanon",
    'website': "",
    'category': 'base',
    'version': '0.1',
    'depends': ['base',
                'mail',
                'contacts',
                'web',
                'documents',
                'mass_mailing'],
    'qweb': [],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'security/rules.xml',

        'data/analysis_type_data.xml',
        'data/config_data.xml',
        'data/industry_data.xml',
        'data/mail_template_data.xml',
        'data/notif_mail_template_data.xml',

        'wizards/assign_teamleader_views.xml',
        'wizards/reject_analysis_views.xml',
        'wizards/assign_new_analyst_views.xml',
        'wizards/cancel_tender_views.xml',
        'wizards/cancel_analysis_views.xml',

        'views/tender_views.xml',
        'views/tenderer_views.xml',
        'views/analysis_views.xml',
        'views/snapshots_views.xml',
        'views/client.xml',
        'views/sequence_views.xml',
        'views/settings.xml',
        'views/preferences.xml',
        'views/assets.xml',

        # email marketing
        'views/mailing_contacts_view.xml',
        'views/mailing_mailing_views.xml',

        'report/paperformat_snapshot_report.xml',
        'report/snapshot_templates.xml',
        'report/snapshot_safety_report.xml',
    ],
    'demo': [
        # 'demo/demo.xml',
        'demo/thinksavvy_demo.xml',
    ],
    'installable': True,
    'application': False,
}

