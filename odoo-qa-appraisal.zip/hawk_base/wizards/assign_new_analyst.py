# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class AssignNewAnalyst(models.TransientModel):
    _name = 'assign.new.analyst'
    _description = 'Assign New Analyst'

    safety_analyst_id = fields.Many2one('res.users', string='Safety Analyst',
                                        domain=lambda self: [('groups_id', '=', self.env.ref('hawk_base.group_hawk_analyst').id)], required=True)
    is_analyst_available = fields.Boolean()

    @api.model
    def default_get(self, fields):
        res = super(AssignNewAnalyst, self).default_get(fields)
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
        if self.env.user.id != analysis.team_leader_id.id:
            raise ValidationError('Sorry only the assigned team leader is allowed to assign new analyst.')
        return res

    @api.onchange('safety_analyst_id')
    def onchange_safety_analysis_id(self):
        ongoing_analysis = self.env['hawk.analysis'].search([
            ('state', '!=', 'tl'),
            ('state', '!=', 'qa'),
            ('state', '!=', 'manager'),
            ('state', '!=', 'concierge'),
            ('state', '!=', 'done'),
            ('state', '!=', 'cancelled')])

        if ongoing_analysis:
            for analysis in ongoing_analysis:
                if analysis.safety_analyst_id.id == self.safety_analyst_id.id:
                    self.is_analyst_available = False
                    break
                else:
                    self.is_analyst_available = True
        else:
            self.is_analyst_available = True

    def action_assign_new_analyst(self):
        print('action_assign_new_analyst', self)
        if self.is_analyst_available:
            analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
            old_analyst = analysis.previous_analyst_id
            new_analyst = self.safety_analyst_id
            vals = [{
                'analysis_id': analysis.id,
                'details': 'Re-assigned Analyst',
                'date': fields.Datetime.now(),
                'res_person_id': analysis.team_leader_id.id,
                'remarks': self.safety_analyst_id.name + ' is the new assigned analyst for this tenderer.',
            }]
            analysis.analysis_timeline_ids.create(vals)

            analysis.write({
                'safety_analyst_id': self.safety_analyst_id.id,
            })

            if analysis.state == 'reject':
                recipients = [new_analyst.partner_id.id]
                self.action_send_email_notification('assign_new_analyst_template', old_analyst, analysis)
            else:
                old_analyst = analysis.safety_analyst_id
                recipients = [old_analyst.partner_id.id, new_analyst.partner_id.id]
                self.action_send_email_notification('assign_new_analyst_template_1', old_analyst, analysis)

            # Alerts
            odoobot = self.env.ref('base.partner_root')
            analysis.message_post(
                subject='Assigned Analyst',
                body=analysis.team_leader_id.name + ' assigned ' + new_analyst.name + ' as the new analyst.',
                message_type='comment',
                subtype_xmlid='mail.mt_comment',
                notify_by_email=False,
                author_id=odoobot.id,
                partner_ids=recipients)

            analysis.write({
                'state': 'new',
                'safety_analyst_id': self.safety_analyst_id.id,
                'hide_new_btn': True,
                'hide_resume_btn': True,
                'hide_submit_btn': True,
                'is_survey_started': False,
                'is_survey_done': False,
                'is_generate_done': False,
                'is_qa_reject': False,
                'qa_specialist_id': False,
                'sign_request_ids': False
            })
        else:
            raise ValidationError('Sorry the selected analyst still has an ongoing project.'
                                  '\nPlease choose another analyst.')

    def action_send_email_notification(self, template, old_id, new_id):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(new_id.id)
        self.env['mail.template'].browse(template_id).with_context(url=url, old_id=old_id).send_mail(new_id.id, force_send=True)
