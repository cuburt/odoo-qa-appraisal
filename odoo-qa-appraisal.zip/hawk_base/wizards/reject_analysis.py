# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class RejectAnalysis(models.TransientModel):
    _name = 'reject.analysis'
    _description = 'Reject Analysis'

    remarks = fields.Text(string='Remarks', required=True)

    @api.model
    def default_get(self, fields):
        res = super(RejectAnalysis, self).default_get(fields)
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
        if self.env.user.id != analysis.safety_analyst_id.id:
            raise ValidationError('Sorry only the assigned analyst is allowed to reject this analysis.')
        return res

    def action_reject_analysis(self):
        print('action_reject_analysis', self)
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
        vals = [{
            'analysis_id': analysis.id,
            'details': 'Declined Task',
            'date': fields.Datetime.now(),
            'res_person_id': analysis.safety_analyst_id.id,
            'remarks': self.remarks,
        }]
        analysis.analysis_timeline_ids.create(vals)

        # Alerts
        odoobot = self.env.ref('base.partner_root')
        analysis.message_post(
            subject='Declined Task',
            body=analysis.safety_analyst_id.name + ' rejected the assigned task.',
            message_type='comment',
            subtype_xmlid='mail.mt_comment',
            notify_by_email=False,
            author_id=odoobot.id,
            partner_ids=[4, analysis.team_leader_id.partner_id.id])
        self.action_send_email_notification('cancel_by_analyst_template', analysis)
        analysis.write({
            'state': 'reject',
            'previous_analyst_id': analysis.safety_analyst_id,
            'safety_analyst_id': None,
        })
        return {
            'type': 'ir.actions.act_window',
            'name': 'Tenderer',
            'domain': [],
            'view_mode': 'tree,form',
            'res_model': 'hawk.tenderer',
        }

    def action_send_email_notification(self, template, analysis_id):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(analysis_id.id)
        self.env['mail.template'].browse(template_id).with_context(url=url, remarks=self.remarks).send_mail(analysis_id.id, force_send=True)
