# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class CancelTender(models.TransientModel):
    _name = 'cancel.tender'
    _description = 'Cancel Tender'

    tender_id = fields.Many2one('hawk.tender', readonly=True)
    cancel_tenderer_ids = fields.Many2many('hawk.tenderer', string='Tenderers',default=lambda self: self._get_tenderers())
    note = fields.Text(string='Reason for Cancellation', required=True)

    @api.model
    def _get_tenderers(self):
        tender = self.env['hawk.tender'].browse(self.env.context.get('active_ids'))
        return tender.tenderer_ids.ids

    @api.model
    def default_get(self, fields):
        res = super(CancelTender, self).default_get(fields)
        tender = self.env['hawk.tender'].browse(self.env.context.get('active_ids'))
        if self.env.user.id != tender.tender_manager_id.id:
            raise ValidationError('Sorry only the assigned team manager is allowed to cancel the tender.')
        return res

    def action_cancel_tender(self):
        print('action_cancel_tender', self)
        if not self.cancel_tenderer_ids:
            raise ValidationError("Please select at least one tenderer.")
        else:
            tender = self.env['hawk.tender'].browse(self.env.context.get('active_ids'))
            tender.write({
                'cancel_tenderer_ids': self.cancel_tenderer_ids,
                'is_approve_by_crm': False,
                'previous_state': tender.state,
                'state': 'cancel',
                'note': self.note
            })

            # Alerts
            odoobot = self.env.ref('base.partner_root')
            tender.message_post(
                subject='Cancel Tender',
                body=tender.tender_manager_id.name + ' would like you to review a tender cancellation request.',
                message_type='comment',
                subtype_xmlid='mail.mt_comment',
                notify_by_email=False,
                author_id=odoobot.id,
                partner_ids=[tender.crm_id.partner_id.id])
            self.action_send_email_notification()

    def action_send_email_notification(self):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        url = base_url + '/web#id={}&model=hawk.tender&view_type=form'.format(self.tender_id.id)
        template_id = self.env.ref('hawk_base.cancel_tender_crm_template').id
        self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(self.id, force_send=True)
