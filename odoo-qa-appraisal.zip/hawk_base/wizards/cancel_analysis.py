# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class CancelAnalysis(models.TransientModel):
    _name = 'cancel.analysis'
    _description = 'Cancel Analysis'

    analysis_id = fields.Many2one('hawk.analysis', readonly=True)

    def action_cancel(self):
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_id'))
        category = self.env['ir.module.category'].sudo().search([('name', '=', 'HAWK')])
        dev_group = self.env['res.groups'].sudo().search(
            [('category_id.id', '=', category.id), ('name', '=', 'Developer')])
        if dev_group.id in [rec.id for rec in self.env.user.groups_id]:
            return {
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': self._model,
                'name': _("Cancel Analysis"),
                'res_id': analysis.id,
                'context': {'active_id': self.env.context.get('active_id')},
                'target': 'new',
            }
        return False

    def action_confirm_cancellation(self):
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_id'))
        category = self.env['ir.module.category'].sudo().search([('name', '=', 'HAWK')])
        dev_group = self.env['res.groups'].sudo().search(
            [('category_id.id', '=', category.id), ('name', '=', 'Developer')])
        if dev_group.id in [rec.id for rec in self.env.user.groups_id]:
            analysis.state = 'cancelled'
            analysis.is_cancel = True
            analysis.tenderer_id.is_cancel = True
            analysis.tenderer_id._get_state()
            if len([rec.id for rec in analysis.tenderer_id.tender_id.tenderer_ids]) == len([rec.id for rec in analysis.tenderer_id.tender_id.tenderer_ids if rec.is_cancel]):
                analysis.tenderer_id.tender_id.state = 'cancel'
                analysis.tenderer_id.tender_id.note = 'Cancelled by The System Admin'

