# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class AssignTeamleader(models.TransientModel):
    _name = 'assign.teamleader'
    _description = 'assign.teamleader transient model'

    tender_id = fields.Many2one('hawk.tender', compute='_get_tender')
    crm_id = fields.Many2one('res.users',
                             string='Concierge / CRM',
                             domain=lambda self: [('groups_id', '=', self.env.ref('hawk_base.group_hawk_client_manager').id)], required=True)
    team_leader_id = fields.Many2one('res.users',
                                     string='Team Leader',
                                     domain=lambda self: [('groups_id', '=', self.env.ref('hawk_base.group_hawk_leader').id)], required=True)
    is_tl_outsource = fields.Boolean(default=False, string='Is TL Outsourced?')  # TODO: make this automatic after MVP

    @api.model
    def default_get(self, fields):
        tender = self.env['hawk.tender'].browse(self.env.context.get('active_ids'))
        res = super(AssignTeamleader, self).default_get(fields)
        if self.env.user.id != tender.tender_manager_id.id:
            raise ValidationError('Sorry only the assigned tender manager is allowed to assign roles.')

        return res

    def _get_tender(self):
        self.tender_id = self.env['hawk.tender'].browse(self.env.context.get('active_ids')).id

    def action_assign_teamleader(self):
        self.tender_id.write({
            'crm_id': self.crm_id.id,
            'team_lead_id': self.team_leader_id.id,
            'is_tl_outsource': self.is_tl_outsource,
            'date_assign_tl': fields.Datetime.now(),
            'state': 'nda' if self.is_tl_outsource else 'analysis',
        })
        self.tender_id.team_lead_id.partner_id.function = 'Team Leader'

        # Alerts
        odoobot = self.env.ref('base.partner_root')
        self.tender_id.message_post(
            subject='Assigned Team Leader',
            body=self.team_leader_id.name + ' was assigned as the team leader for this tender.',
            message_type='comment',
            notify_by_email=False,
            author_id=odoobot.id,
            partner_ids=[4, self.team_leader_id.partner_id.id])
        self.action_send_email_notification('assign_tl_template')

        self.tender_id.message_post(
            subject='Assigned Concierge',
            body=self.crm_id.name + ' was assigned as the concierge for this tender.',
            message_type='comment',
            notify_by_email=False,
            author_id=odoobot.id,
            partner_ids=[4, self.crm_id.partner_id.id])
        self.action_send_email_notification('assign_crm_template')

    def action_send_email_notification(self, template):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        url = base_url + '/web#id={}&model=hawk.tender&view_type=form'.format(self.tender_id.id)
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(self.id, force_send=True)
