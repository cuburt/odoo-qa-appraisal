# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import ValidationError

import matplotlib as mpl

mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from contextlib import closing

import tempfile
import base64
import os


class PaperFormat(models.Model):
    _inherit = "report.paperformat"

    toc = fields.Boolean(default=False, required=False)
    cover = fields.Boolean(default=False, required=False)
    backcover = fields.Boolean(default=False, required=False)


class HawkSnapshots(models.Model):
    _name = "hawk.snapshots"
    _description = "Hawk Snapshots"

    state = fields.Selection([
        ('pending', 'Pending Tenders'),
        ('done', 'Ready for Snapshots'),
        ('sent', 'Sent to Client')
    ], string='Status', readonly=True, default='pending', group_expand='_expand_states', tracking=True)

    tender_id = fields.Many2one('hawk.tender', 'Tender')
    tenderer_ids = fields.One2many('hawk.tenderer', string='Tenderer', inverse_name='tender_id', tracking=True)
    reference_safety_analysis_id = fields.Many2one('hawk.analysis', string='Reference Safety Analysis')
    done_safety_tenderer_ids = fields.One2many('hawk.tenderer', string='Done Safety Tenderer', inverse_name='tender_id')
    crm_id = fields.Many2one('res.users', string='Concierge / CRM', related='tender_id.crm_id')
    tender_manager_id = fields.Many2one('res.users', string='Tender Manager', related='tender_id.tender_manager_id')
    is_snapshot_done = fields.Boolean(default=False, compute='_is_snapshot_done')

    sample_tenderers = ['Tenderer 1',
                        'Tenderer 2',
                        'Tenderer 3',
                        'Tenderer 4',
                        'Tenderer 5',
                        'Tenderer 6',
                        'Tenderer 7',
                        'Tenderer 8',
                        'Tenderer 9']

    def _expand_states(self, states, domain, order):
        return [key for key, val in type(self).state.selection]

    @api.model
    def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
        res = super(HawkSnapshots, self).fields_view_get(view_id, view_type, toolbar=toolbar, submenu=False)

        tender_ids = []
        tenders = self.env['hawk.tender'].search([])

        for tender in tenders:
            if tender.id not in tender_ids:
                tender_ids.append(tender)

        self.create_snapshots(tender_ids)
        return res

    def create_snapshots(self, tenders):
        print('create_snapshots', self)
        all_tenders = []
        snapshots = self.env['hawk.snapshots'].search([])

        for snapshot in snapshots:
            if snapshot.tender_id.id not in all_tenders:
                all_tenders.append(snapshot.tender_id.id)

        for tender in tenders:
            if tender.id not in all_tenders:
                self.env['hawk.snapshots'].create({
                    'tender_id': tender.id,
                    'state': 'pending',
                })

    def _is_snapshot_done(self):
        # TODO: make this automatic
        count = 0
        if self.state != 'sent':
            for tenderer in self.tenderer_ids:
                if tenderer.state == 'done' or tenderer.state == 'cancelled':
                    count += 1

            if len(self.tenderer_ids) == count:
                self.state = 'done'
                self.is_snapshot_done = True
            else:
                self.state = 'pending'
                self.is_snapshot_done = False

    @staticmethod
    def get_img_raw_scores_3d_bar(
            tenderers,
            categories,
            raw_score_context,
            raw_score_leadership,
            raw_score_planning,
            raw_score_support,
            raw_score_operation,
            raw_score_performance,
            raw_score_improvement):

        tenderers_names = []
        abbreviated_names = []
        for tenderer in tenderers:
            tenderers_names.append(tenderer['name'])
            abbreviated_names.append(tenderer['abbreviated_name'])

        t_len = len(tenderers_names)
        context_clr = ['#9400D3']*t_len
        leadership_clr = ['#0000FF']*t_len
        planning_clr = ['#00FF00']*t_len
        support_clr = ['#FFFF00']*t_len
        operation_clr = ['#FF7F00']*t_len
        performance_clr = ['#FF0000']*t_len
        improvement_clr = ['#ff66ff']*t_len
        colors = [context_clr + leadership_clr + planning_clr + support_clr + operation_clr + performance_clr + improvement_clr]

        result = [raw_score_context,
                  raw_score_leadership,
                  raw_score_planning,
                  raw_score_support,
                  raw_score_operation,
                  raw_score_performance,
                  raw_score_improvement]

        result = np.array(result, dtype=np.int)
        fig = plt.figure(figsize=(12, 6))  # facecolor='#f2e6ff' figsize=(14, 4)
        ax = fig.add_subplot(111, projection='3d')  # facecolor='#cccccc'

        xlabels = np.array(abbreviated_names)
        xpos = np.arange(xlabels.shape[0])
        ylabels = np.array(categories)
        ypos = np.arange(ylabels.shape[0])

        xposM, yposM = np.meshgrid(xpos, ypos, copy=False)
        zpos = result
        zpos = zpos.ravel()

        dx = .50
        dy = .25
        dz = zpos

        ax.w_xaxis.set_ticks(xpos + .5 / 2.)
        ax.w_xaxis.set_ticklabels(xlabels)
        ax.w_yaxis.set_ticks(ypos + 1 / 2.)
        ax.w_yaxis.set_ticklabels(ylabels)

        ax.set_box_aspect((2, 6, 1.5))  # (1, 4, 2) (2, 3, 1) (7, 23, 3.5) (8, 23, 9.5) (1, 6, 1.5)
        ax.bar3d(xposM.ravel(), yposM.ravel(), dz*0, dx, dy, dz, color=colors[0])  # color=colors
        ax.view_init(30, -35)  # ax.view_init(35, -35)

        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='raw_scores_3d_bar_.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    @staticmethod
    def get_img_corrected_ave_score_h_bar(data):
        x_data = []
        y_data = []

        for datum in data:
            x_data.append(float(datum['corrected_ave_score']))
            y_data.append(datum['abbreviated_name'])

        # no_of_rec = 5
        # y_data = ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9'][:no_of_rec]
        # x_data = [4.3, 2.5, 3.5, 4.5, 6.3, 5.5, 6.2, 4, 10][:no_of_rec]

        fig, ax = plt.subplots(figsize=(12, 5.5))
        # reversed the data to display the graph from top-bottom
        ax.barh(y_data[::-1], x_data[::-1], label="Corrected Average Score", color='#5a3d98')
        plt.legend(loc=8, ncol=4)
        plt.grid(axis='x')
        plt.margins(0.25)

        for index, data in enumerate(x_data[::-1]):
            plt.text(x=data-0.15,
                     y=index,
                     s=f"{data}",
                     color='w',
                     ha='center',
                     fontsize=10,
                     fontweight='bold')

        graph_fd, graph_path = tempfile.mkstemp(suffix='.png', prefix='corrected_ave_score_h_bar.tmp.')
        with closing(os.fdopen(graph_fd, 'wb')) as tmpfile:
            plt.savefig(tmpfile, format="png")
            tmpfile.seek(0)
        plt.clf()
        return base64.b64encode(open(graph_path, 'rb').read()), graph_path

    def button_safety_snapshots(self):
        print('button_safety_snapshots', self)
        template = "hawk_base.action_snapshot_safety_report"
        dataframes = ()
        tenderers = []

        # 3d bar graph data
        # tenderers_name = []
        categories = []
        raw_score_context = []
        raw_score_leadership = []
        raw_score_planning = []
        raw_score_support = []
        raw_score_operation = []
        raw_score_performance = []
        raw_score_improvement = []

        # line graph data
        t_names = []  # abbreviated names
        context = []
        leadership = []
        planning = []
        support = []
        operation = []
        performance = []
        improvement = []

        total_count = 1

        if self.env.user.id == self.tender_id.tender_manager_id.id:
            for analysis in self.tenderer_ids.analysis_ids:
                if analysis.analysis_type == 'Safety' and analysis.state == 'done':
                    self.done_safety_tenderer_ids = [(4, analysis.tenderer_id.id)]

                if not self.reference_safety_analysis_id.id:
                    self.reference_safety_analysis_id = analysis.id

                reportChangeLog = analysis.report_logs.search([('analysis_id', '=', analysis.id)], order='id desc')[0]
                ctx = analysis.get_values(analysis.id, reportChangeLog.id)
                merged_df, coeff_count, sum_raw_mark, count, mean_raw_mark, cumulative_raw_mark, correlated_mark, cumulative_weighted_mark = ctx['dataframes']
                mean_mean_raw_mark = round(mean_raw_mark / 7, 3)
                mean_correlated_mark = round(correlated_mark / coeff_count, 3)

                # tenderers_name.append(analysis.tenderer_id.name)
                tenderers.append({
                    'name': analysis.tenderer_id.name,
                    'abbreviated_name': 'T%s' % total_count,
                    'raw_overall_score': format(round(mean_mean_raw_mark, 2), '.2f'),
                    'corrected_ave_score': format(round(mean_correlated_mark, 2), '.2f'),
                })

                t_names.append('T%s' % total_count)
                total_count += 1

                for k, v in merged_df.items():
                    if v['index'] not in categories:
                        categories.append(v['index'])

                    if v['index'] == 'Context':
                        context.append(v['weighted_mean'])
                        raw_score_context.append(v['sum'])
                    elif v['index'] == 'Leadership':
                        leadership.append(v['weighted_mean'])
                        raw_score_leadership.append(v['sum'])
                    elif v['index'] == 'Planning':
                        planning.append(v['weighted_mean'])
                        raw_score_planning.append(v['sum'])
                    elif v['index'] == 'Support':
                        support.append(v['weighted_mean'])
                        raw_score_support.append(v['sum'])
                    elif v['index'] == 'Operation':
                        operation.append(v['weighted_mean'])
                        raw_score_operation.append(v['sum'])
                    elif v['index'] == 'Performance':
                        performance.append(v['weighted_mean'])
                        raw_score_performance.append(v['sum'])
                    elif v['index'] == 'Improvement':
                        improvement.append(v['weighted_mean'])
                        raw_score_improvement.append(v['sum'])

            if not dataframes:
                dataframes = merged_df
                for k, v in dataframes.items():
                    v['max'] = int(v['max'])

            data = {
                'title': self.tender_id.name,
                'client_company': self.sudo().tender_id.company.name,
                'disclaimer': self.reference_safety_analysis_id.config_id.get_disclaimer(self.reference_safety_analysis_id),
                'copyright': self.reference_safety_analysis_id.config_id.get_copyright(self.reference_safety_analysis_id),
                'dataframes': dataframes,
                'total_weight': int(coeff_count),
                'total_count': int(count),
                'tenderers': tenderers,
                'img_raw_scores_3d_bar': self.get_img_raw_scores_3d_bar(
                    tenderers,
                    categories,
                    raw_score_context,
                    raw_score_leadership,
                    raw_score_planning,
                    raw_score_support,
                    raw_score_operation,
                    raw_score_performance,
                    raw_score_improvement),
                'img_corrected_ave_score_h_bar': self.get_img_corrected_ave_score_h_bar(tenderers),
            }

            pdf_content, __ = self.env.ref(template)._render_qweb_pdf(self.id, data=data, type='snapshot_report')

            attachment = self.env['ir.attachment'].sudo().create({
                'name': '%s - Safety | Complementary Overall Results Snapshot.pdf' % self.tender_id.name,
                'type': 'binary',
                'datas': base64.b64encode(pdf_content),
                'res_model': self._name,
                'res_id': self.id
            })

            print(attachment)


        else:
            raise ValidationError('Sorry only the assigned Tender Manager is allowed to create the report.')
