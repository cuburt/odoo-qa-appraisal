# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Industry(models.Model):
    _name = 'hawk.industry'
    _description = "Hawk Industry"

    name = fields.Char()
    full_name = fields.Char()
    subindustry_ids = fields.One2many('hawk.subindustry', 'industry_id')


class Subindustry(models.Model):
    _name = 'hawk.subindustry'
    _description = "Hawk Subindustry"

    name = fields.Char()
    full_name = fields.Char()
    industry_id = fields.Many2one('hawk.industry')


