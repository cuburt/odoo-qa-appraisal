# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class HawkTender(models.Model):
    _name = "hawk.tender"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Hawk Tender"

    name = fields.Char(string='Tender Name', readonly=True, required=True, index=True, tracking=True)
    state = fields.Selection([
        ('new', 'New'),
        ('nda', 'Sign NDA'),
        ('analysis', 'Set Tenderer'),
        ('pending', 'Pending'),
        ('done', 'Done'),
        ('cancel', 'Cancelled')
    ], string='Status', readonly=True, default='new', group_expand='_expand_states', tracking=True)
    priority = fields.Selection([
        ('0', 'None'),
        ('1', 'Low'),
        ('2', 'Medium'),
        ('3', 'High'),
    ], string='Priority', default='0', tracking=True)

    crm_id = fields.Many2one('res.users', string='Concierge / CRM', readonly=True, tracking=True)
    tender_manager_id = fields.Many2one('res.users', string='Tender Manager', tracking=True)
    team_lead_id = fields.Many2one('res.users', string='Team Leader', readonly=True, tracking=True)
    is_tl_outsource = fields.Boolean(default=True, readonly=True, string='Outsourced Team Leader')

    """ General Information From the Client """
    reference = fields.Char(string='Tender / Project ID', default='/', tracking=True)
    revision = fields.Integer(string='Revision', tracking=True, default=1)
    order_id = fields.Many2one('sale.order', 'Sales Order', required=False)
    company = fields.Many2one('res.company', string='Client Name', tracking=True)
    ab_number = fields.Char(related='company.ab_number', string='Client ACN/ABN', tracking=True)
    company_size = fields.Char(related='company.company_size', string='Company Size')
    industry = fields.Many2one('hawk.industry', string='Industry', tracking=True)
    sub_industry = fields.Many2one('hawk.subindustry', string='Industry Sub-Class', tracking=True)
    company_street = fields.Char(related='company.street', tracking=True)
    company_street2 = fields.Char(related='company.street2', tracking=True)
    company_city = fields.Char(related='company.city', tracking=True)
    company_zip = fields.Char(related='company.zip', tracking=True)
    company_country_id = fields.Many2one('res.country', related='company.country_id', tracking=True)
    company_country = fields.Char('Suggested country', related='company.country')
    company_state_id = fields.Many2one('res.country.state', tracking=True)
    company_region = fields.Char('Suggested region', related='company.state')
    country_id = fields.Many2one('res.country', tracking=True)
    country = fields.Char('Suggested Country')
    state_id = fields.Many2one('res.country.state', tracking=True)
    region = fields.Char('Suggested region')
    contact_id = fields.Many2one('res.partner', string='Client Point of Contact', tracking=True)
    job_title = fields.Char(string='Job Title', related='contact_id.function', readonly=True, tracking=True)
    email = fields.Char(related='contact_id.email', string='Work Email', tracking=True)
    phone = fields.Char(related='contact_id.phone', string='Phone', tracking=True)
    tenderer_ids = fields.One2many('hawk.tenderer', string='Tenderer', inverse_name='tender_id', tracking=True)
    cancel_tenderer_ids = fields.Many2many('hawk.tenderer', string='Tenderers')
    note = fields.Text(string='Reason for Cancellation')
    previous_state = fields.Char(string='Previous State', readonly=True)  # state before it is cancelled

    """ Timeline """
    date_created = fields.Datetime(string='Date Created', readonly=True, default=fields.Datetime.now(), tracking=True)
    date_assign_tl = fields.Datetime(string='Assigned Team Leader', readonly=True, tracking=True)
    date_pending = fields.Datetime(string='Assigned Analysts', readonly=True, tracking=True)
    date_done = fields.Datetime(string='Date Finished', readonly=True, tracking=True)

    """ Criteria or Booleans """
    is_safety = fields.Boolean(default=False)
    is_health = fields.Boolean(default=False)

    is_team_manager = fields.Boolean(default=False, compute='_is_team_manager')
    is_team_leader = fields.Boolean(default=False, compute='_is_team_leader')
    is_sign_nda = fields.Boolean(default=False)
    is_tender_done = fields.Boolean(default=False, compute='_is_tender_done')
    is_approve_by_crm = fields.Boolean(default=False)
    is_tenderer_change = fields.Boolean(default=False)
    is_abn_duplicate = fields.Boolean(default=False, compute='_is_abn_duplicate')
    duplicate_abn_companies = fields.Char()

    odoobot_id = fields.Many2one('res.users', compute='_get_odoo_bot')
    mail_server_res_partner_id = fields.Many2one('res.partner', compute='_get_mail_server_res_partner_id')

    @api.onchange('ab_number', 'company_size', 'street', 'street2', 'city',
                  'zip', 'country_id', 'state_id', 'job_title', 'email', 'phone')
    def update_fields(self):
        if self.ab_number:
            self.company.sudo().write({'ab_number': self.ab_number})
        if self.company_size:
            self.company.sudo().write({'company_size': self.company_size})
        if self.company_street:
            self.company.sudo().write({'street': self.company_street})
        if self.company_street2:
            self.company.sudo().write({'street2': self.company_street2})
        if self.company_city:
            self.company.sudo().write({'city': self.company_city})
        if self.company_zip:
            self.company.sudo().write({'zip': self.company_zip})
        if self.company_country_id:
            self.company.sudo().write({'country_id': self.company_country_id.id})
        if self.company_state_id:
            self.company.sudo().write({'state_id': self.company_state_id.id})
        if self.job_title:
            self.contact_id.sudo().write({'function': self.job_title})
        if self.email:
            self.contact_id.sudo().write({'email': self.email})
        if self.phone:
            self.contact_id.sudo().write({'phone': self.phone})

    def _expand_states(self, states, domain, order):
        return [key for key, val in type(self).state.selection]

    @api.onchange('tenderer_ids')
    def _onchange_tenderer_ids(self):
        self.is_tenderer_change = True

    def write(self, vals):
        obj = super(HawkTender, self).write(vals)
        self.hide_warning_for_save()
        return obj

    def hide_warning_for_save(self):
        if self.is_tenderer_change:
            self.is_tenderer_change = False

    # COMPUTE
    def _is_abn_duplicate(self):
        companies = self.env['res.company'].sudo().search([('ab_number', '=', self.ab_number)])
        duplicate_companies = []
        if len(companies) > 1:
            self.is_abn_duplicate = True
        else:
            self.is_abn_duplicate = False

        for c in companies:
            if c.name != self.company.name:
                duplicate_companies.append(c.name)

        self.duplicate_abn_companies = duplicate_companies

    def _is_team_manager(self):
        for rec in self:
            rec.is_team_manager = rec.tender_manager_id.id == self.env.user.id

    def _is_team_leader(self):
        for rec in self:
            rec.is_team_leader = rec.team_lead_id.id == self.env.user.id

    def _is_tender_done(self):
        done_count = 0

        if self.state == 'pending':
            for tenderer in self.tenderer_ids:
                if (tenderer.state == 'done') or (tenderer.state == 'cancelled'):
                    done_count += 1

                if len(self.tenderer_ids) == done_count:  # number of tenderers must be equal to 'done' plus 'cancelled'
                    self.write({
                        'is_tender_done': True,
                        'state': 'done',
                        'date_done': fields.Datetime.now(),
                    })

                    # Alerts
                    odoobot = self.env.ref('base.partner_root')
                    self.message_post(
                        subject='Done',
                        body='All tenderers are completed successfully.',
                        message_type='comment',
                        notify_by_email=False,
                        author_id=odoobot.id,
                        partner_ids=[self.tender_manager_id.partner_id.id, self.team_lead_id.partner_id.id])

                else:
                    self.write({
                        'is_tender_done': False,
                    })
        else:
            self.is_tender_done = False

    def _get_odoo_bot(self):
        self.odoobot_id = self.env.ref('base.partner_root').id

    def _get_mail_server_res_partner_id(self):
        email_add = 'HTA.portal@think-savvy.com'
        try:
            self.mail_server_res_partner_id = self.env['res.partner'].sudo().search([('email', '=', email_add)], limit=1)
        except ValueError as e:
            raise ValidationError(e)

    # ACTIONS
    def button_new(self):
        self.write({
            'state': 'new',
            'crm_id': None,
            'team_lead_id': None,
            'is_sign_nda': False,
            'is_approve_by_crm': False,
        })
        return {}

    def action_confirm_assign_analysts(self):
        print('action_confirm_assign_analysts', self)
        if self.env.user.id == self.team_lead_id.id:
            analysis_data = []
            for tenderer in self.tenderer_ids:
                if not tenderer.tenderer_abn:
                    raise ValidationError(tenderer.name + ' - "ACN/ABN" is required.')
                if not tenderer.tenderer_contact_id.id:
                    raise ValidationError(tenderer.name + ' - "Contact Person" is required.')
                if not tenderer.position:
                    raise ValidationError(tenderer.name + ' - "Position" is required.')
                if not tenderer.email:
                    raise ValidationError(tenderer.name + ' - "Email" is required.')
                if not tenderer.city:
                    raise ValidationError(tenderer.name + ' - "City" is required.')
                if not tenderer.country_id.id:
                    raise ValidationError(tenderer.name + ' - "Country" is required.')
                if tenderer.pages_count <= 0:
                    raise ValidationError(tenderer.name + ' - "Number of Pages Received" is required.')
                if tenderer.safety_analyst_id.id:
                    if tenderer.analysis_ids.analysis_type_id.name == 'Safety':
                        vals = [{
                            'analysis_id': tenderer.analysis_ids.id,
                            'details': 'Assigned Analyst',
                            'date': fields.Datetime.now(),
                            'res_person_id': tenderer.team_leader_id.id,
                            'remarks': tenderer.safety_analyst_id.name + ' is the assigned analyst for this tenderer.',
                        }]
                        analysis_data.append(vals)
                else:
                    raise ValidationError(tenderer.name + ' - "Safety Analyst" is required.')

            # Alerts
            odoobot = self.env.ref('base.partner_root')
            recipients = [self.tender_manager_id.partner_id.id]
            for analyst in self.tenderer_ids.safety_analyst_id:
                recipients.append(analyst.partner_id.id)

            for analysis in self.tenderer_ids.analysis_ids:
                self.action_send_email_notification('assign_analyst_template', 'analysis', analysis)

            self.message_post(
                subject='Assigned Analysts',
                body=self.team_lead_id.name + ' assigned the analysts.',
                message_type='comment',
                notify_by_email=False,
                author_id=odoobot.id,
                partner_ids=recipients)

            self.action_send_email_notification('set_tenderer_template')

            # Update the Tender View Form
            self.write({
                'date_pending': fields.Datetime.now(),
                'state': 'pending',
            })

            # Update the Analysis Timeline Page
            for data in analysis_data:
                analysis = self.env['hawk.analysis'].browse(data[0].get('analysis_id'))
                analysis.analysis_timeline_ids.create(data)

            # TODO: also put this function when the TL change the analyst - new analyst should sign the NDA as well.
            # for tenderer in self.tenderer_ids:
            #     tenderer.safety_analyst_id.partner_id.function = 'Safety Analyst' # TODO: to omit, sign issue. change to group_ids
            # return True

        else:
            raise ValidationError('Sorry only the assigned team leader is allowed to confirm the assigned analysts.')

    def action_reject_cancellation(self):
        print('action_reject_cancellation', self)
        self.write({
            'state': self.previous_state
        })

        # Alerts
        odoobot = self.env.ref('base.partner_root')
        self.message_post(
            subject='Reject Tender Cancellation',
            body=self.crm_id.name + ' reject your tender cancellation.',
            message_type='comment',
            notify_by_email=False,
            author_id=odoobot.id,
            partner_ids=[self.tender_manager_id.partner_id.id])
        self.action_send_email_notification('cancel_tender_reject_template')

    def action_approved_cancellation(self):
        print('action_approved_cancellation', self)
        self.ensure_one()
        for tenderer in self.cancel_tenderer_ids:
            tenderer.write({
                'is_cancel': True
            })

        if len(self.tenderer_ids) == len(self.cancel_tenderer_ids):  # When all tenderers are cancelled the tender will be cancelled too
            self.write({
                'state': 'cancel'
            })
        else:
            self.write({
                'state': self.previous_state
            })
        self.is_approve_by_crm = True

        # Alerts
        recipients = [self.tender_manager_id.partner_id.id, self.team_lead_id.partner_id.id]
        for analyst in self.cancel_tenderer_ids.safety_analyst_id:
            recipients.append(analyst.partner_id.id)

        odoobot = self.env.ref('base.partner_root')
        self.message_post(
            subject='Tender Cancellation',
            body=self.crm_id.name + ' approved the tender cancellation.',
            message_type='comment',
            notify_by_email=False,
            author_id=odoobot.id,
            partner_ids=recipients)
        self.action_send_email_notification('cancel_tender_approved_template')

        return {
            'type': 'ir.actions.act_window',
            'name': 'Hawk Tenderer',
            'view_mode': 'form',
            'res_model': 'hawk.tenderer',
            'res_id': self.cancel_tenderer_ids[0].id,
        }

    def action_send_email_notification(self, template, criteria=None, new_id=None):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        if criteria == 'analysis':
            url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(new_id.id)
            self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(new_id.id, force_send=True)
        else:
            url = base_url + '/web#id={}&model=hawk.tender&view_type=form'.format(self.id)
            self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(self.id, force_send=True)
