# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)


class HawkTenderer(models.Model):
    _name = "hawk.tenderer"
    _description = "Hawk Tenderer"

    name = fields.Char(string='Tenderer', readonly=True, required=True)
    priority = fields.Selection([
        ('0', 'None'),
        ('1', 'Urgent'),
    ], string='Priority', default='0')
    state = fields.Selection([
        ('new', 'New'),
        ('reject', 'Reject'),
        ('analysis', 'Analysis'),
        ('report', 'Report'),
        ('tl', 'TL'),
        ('qa', 'QA'),
        ('manager', 'Manager'),
        ('concierge', 'Concierge'),
        ('done', 'Done'),
        ('cancelled', 'Cancelled'),
        ('none', 'None')
    ], string='Status', readonly=True, default='new', group_expand='_expand_states', compute='get_current_state')

    company = fields.Many2one('res.company', string='Tenderer Company', readonly=True)
    tender_id = fields.Many2one('hawk.tender', string='Tender')
    tenderer_abn = fields.Char(related='company.ab_number', string='ACN/ABN')
    tenderer_contact_id = fields.Many2one('res.partner', string='Contact Person')
    position = fields.Char(related='tenderer_contact_id.function', string='Position')
    email = fields.Char(related='tenderer_contact_id.email', string='Email')
    street = fields.Char(related='company.street')
    street2 = fields.Char(related='company.street2')
    city = fields.Char(related='company.city')
    zip = fields.Char(related='company.zip')
    country_id = fields.Many2one('res.country', related='company.country_id')
    country = fields.Char('Suggested country', related='company.country')
    state_id = fields.Many2one('res.country.state')
    region = fields.Char('Suggested region', related='company.state')
    pages_count = fields.Integer(string='Number of Pages Received')
    is_file_not_decrypted = fields.Boolean(default=False)
    crm_id = fields.Many2one('res.users', string='Concierge / CRM', readonly=True, related='tender_id.crm_id')
    tender_manager_id = fields.Many2one('res.users', string='Tender Manager', readonly=True, related='tender_id.tender_manager_id')
    team_leader_id = fields.Many2one('res.users', string='Team Leader', readonly=True, related='tender_id.team_lead_id')
    is_cancel = fields.Boolean('Select', default=False)
    document = fields.Binary(string='Document')
    document_filename = fields.Char(string='File Name')
    attachment_ids = fields.Many2many('ir.attachment', string='Attachment')

    analysis_ids = fields.One2many('hawk.analysis', string='Analysis', inverse_name='tenderer_id')
    safety_analyst_id = fields.Many2one('res.users', string='Safety Analyst',
                                        domain=lambda self: [('groups_id', '=', self.env.ref('hawk_base.group_hawk_analyst').id)])
    quality_analyst_id = fields.Many2one('res.users', string='Quality')
    health_analyst_id = fields.Many2one('res.users', string='Health')
    environment_analyst_id = fields.Many2one('res.users', string='Environment')

    safety_state = fields.Char(compute='_get_state')
    quality_state = fields.Char(compute='_get_state')
    health_state = fields.Char(compute='_get_state')
    environment_state = fields.Char(compute='_get_state')

    is_team_leader = fields.Boolean(default=False, compute='_is_team_leader')
    is_analyst_available = fields.Boolean()

    @api.onchange('tenderer_abn', 'street', 'street2', 'city', 'zip', 'country_id', 'state_id', 'position', 'email')
    def update_fields(self):
        if self.tenderer_abn:
            self.company.sudo().write({'ab_number': self.tenderer_abn})
        if self.street:
            self.company.sudo().write({'street': self.street})
        if self.street2:
            self.company.sudo().write({'street2': self.street2})
        if self.city:
            self.company.sudo().write({'city': self.city})
        if self.zip:
            self.company.sudo().write({'zip': self.zip})
        if self.country_id:
            self.company.sudo().write({'country_id': self.country_id.id})
        if self.state_id:
            self.company.sudo().write({'state_id': self.state_id.id})
        if self.position:
            self.tenderer_contact_id.sudo().write({'function': self.position})
        if self.email:
            self.tenderer_contact_id.sudo().write({'email': self.email})

    def _expand_states(self, states, domain, order):
        return [key for key, val in type(self).state.selection]

    def get_current_state(self):
        # TODO: MVP limitation - this is only for safety analysis state
        for rec in self:
            rec.state = rec.safety_state.lower()

    def _is_team_leader(self):
        for rec in self:
            rec.is_team_leader = rec.team_leader_id.id == self.env.user.id

    def open_analysis_view(self):
        analysis_type = self.env.context.get('type').capitalize()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Analysis',
            'domain': [('tenderer_id', '=', self.id), ('analysis_type', '=', analysis_type)],
            'view_mode': 'kanban,form',
            'res_model': 'hawk.analysis',
        }

    @api.depends('analysis_ids')
    def _get_state(self):
        self.safety_state = 'None'
        self.quality_state = 'None'
        self.health_state = 'None'
        self.environment_state = 'None'

        for rec in self:
            for analysis in rec.analysis_ids:
                try:
                    if rec.is_cancel:
                        analysis.write({
                            'state': 'cancelled'
                        })
                        rec.write({
                            'attachment_ids': [(6, 0, [])]
                        })
                    field = analysis.analysis_type_id.name.lower() + '_state'
                    rec[str(field)] = dict(analysis._fields['state'].selection).get(analysis.state)
                except Exception as e:
                    print(str(e))
                    _logger.error(str(e))

    @api.onchange('safety_analyst_id')
    def onchange_safety_analysis_id(self):
        ongoing_analysis = self.env['hawk.analysis'].search([
            ('state', '!=', 'tl'),
            ('state', '!=', 'qa'),
            ('state', '!=', 'manager'),
            ('state', '!=', 'concierge'),
            ('state', '!=', 'done'),
            ('state', '!=', 'cancelled')])

        for analysis in ongoing_analysis:
            if analysis.safety_analyst_id.id == self.safety_analyst_id.id:
                self.is_analyst_available = False
                break
            else:
                self.is_analyst_available = True

    def write(self, vals):
        result = super(HawkTenderer, self).write(vals)
        if self.safety_analyst_id.id:
            if not self.is_analyst_available:
                raise ValidationError('Sorry the selected analyst still has an ongoing project.'
                                      '\nPlease choose another analyst.')
        return result
