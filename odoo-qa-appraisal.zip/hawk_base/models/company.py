# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Company(models.Model):
    _inherit = 'res.company'

    company_size = fields.Char(string='Company Size', tracking=True)
    tender_ids = fields.One2many('hawk.tender', 'company')
    ab_number = fields.Char('Business Number')
    tenderer_ids = fields.One2many('hawk.tenderer', 'company')
    state = fields.Char()
    country = fields.Char()