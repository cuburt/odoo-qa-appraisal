# -*- coding: utf-8 -*-

from odoo import api, fields, models, _, tools
from odoo.exceptions import ValidationError
from datetime import date

import base64
import logging
_logger = logging.getLogger(__name__)


class HawkAnalysis(models.Model):
    _name = "hawk.analysis"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Hawk Tender Appraisal"

    name = fields.Char(string='Analysis', readonly=True, required=True)
    reference = fields.Char(string='Think Savvy Appraisal ID', default='/', readonly=True)
    tenderer_id = fields.Many2one('hawk.tenderer', string='Parent Tenderer')
    crm_id = fields.Many2one('res.users', string='Concierge / CRM', related='tenderer_id.crm_id', readonly=True)
    tender_manager_id = fields.Many2one('res.users', string='Tender Manager', related='tenderer_id.tender_manager_id', readonly=True)
    qa_specialist_id = fields.Many2one('res.users', string='QA/QC Specialist', readonly=True, tracking=True)
    team_leader_id = fields.Many2one('res.users', string='Team Leader', related='tenderer_id.team_leader_id', readonly=True)
    weight_ids = fields.One2many('hawk.analysis.coeff', 'analysis_id')
    safety_analyst_id = fields.Many2one('res.users', string='Safety Analyst', related='tenderer_id.safety_analyst_id', readonly=False, tracking=True)
    previous_analyst_id = fields.Many2one('res.users', string='Previous Safety Analyst', readonly=True, tracking=True)
    quality_analyst_id = fields.Many2one('res.users', string='Quality Analyst', related='tenderer_id.quality_analyst_id', tracking=True)
    health_analyst_id = fields.Many2one('res.users', string='Health Analyst', related='tenderer_id.health_analyst_id', tracking=True)
    environment_analyst_id = fields.Many2one('res.users', string='Environment Analyst', related='tenderer_id.environment_analyst_id', tracking=True)
    analysis_type_id = fields.Many2one('hawk.analysis.type')
    analysis_type = fields.Char(related='analysis_type_id.name', string='Type of Analysis')
    analysis_timeline_ids = fields.One2many('hawk.analysis.timeline', string='Timeline', inverse_name='analysis_id', readonly=True, tracking=True)
    priority = fields.Selection([
        ('0', 'None'),
        ('1', 'Urgent'),
    ], string='Priority')
    state = fields.Selection([
        ('new', 'New'),
        ('reject', 'Reject'),
        ('analysis', 'Analysis'),
        ('report', 'Report'),
        ('tl', 'TL'),
        ('qa', 'QA'),
        ('manager', 'Manager'),
        ('concierge', 'Concierge'),
        ('done', 'Done'),
        ('cancelled', 'Cancelled'),
        ('none', 'None')
    ], string='Status', readonly=True, default='new', group_expand='_expand_states', tracking=True)
    attachment_ids = fields.Many2many('ir.attachment', string='Attachment', related='tenderer_id.attachment_ids')
    access_token = fields.Char(string='Access Token')

    hide_new_btn = fields.Boolean(default=True)
    hide_resume_btn = fields.Boolean(default=True)
    hide_submit_btn = fields.Boolean(default=True)

    is_nda_required = fields.Boolean(compute='_compute_is_nda_required')

    # used for the alerts
    is_survey_done = fields.Boolean(default=False)
    is_generate_done = fields.Boolean(default=False)
    is_qa_reject = fields.Boolean(default=False)
    is_cancel = fields.Boolean(default=False)

    # used for the email template to avoid access rules
    company_string = fields.Char(string='Company String', compute='get_company_string')
    analysis_count = fields.Integer(string='Analysis Count', compute='get_analysis_count')
    analysis_index = fields.Integer(string='Analysis Index', compute='get_analysis_index')

    odoobot_id = fields.Many2one('res.users', compute='_get_odoo_bot')
    mail_server_res_partner_id = fields.Many2one('res.partner', compute='_get_mail_server_res_partner_id')

    @api.model
    def create(self, vals):
        obj = super(HawkAnalysis, self).create(vals)
        if obj.reference == '/':
            number = self.env['ir.sequence'].get('safety.analysis.sequence') or '/'
            sequence = 'TSHTA{}'.format(date.today().year)
            obj.write({'reference': sequence + number[2:]})
        return obj

    def _get_odoo_bot(self):
        self.odoobot_id = self.env.ref('base.partner_root').id

    def _get_mail_server_res_partner_id(self):
        email_add = 'HTA.portal@think-savvy.com'
        try:
            self.mail_server_res_partner_id = self.env['res.partner'].sudo().search([('email', '=', email_add)], limit=1)
        except ValueError as e:
            raise ValidationError(e)

    def _expand_states(self, states, domain, order):
        return [key for key, val in type(self).state.selection]

    @api.depends('team_leader_id', 'safety_analyst_id')
    def _compute_is_nda_required(self):
        self.is_nda_required = self.team_leader_id != self.safety_analyst_id
        _logger.info('is_nda_required'+str(self.is_nda_required))

    # ACTION
    def button_new(self):
        self.write({
            'state': 'new',
            'hide_new_btn': True,
            'hide_resume_btn': True,
            'hide_submit_btn': True,
            'is_survey_started': False,
            'is_survey_done': False,
            'is_generate_done': False,
            'is_qa_reject': False,
            'qa_specialist_id': False,
            'analysis_timeline_ids': False,
            'sign_request_ids': False
        })
        return True

    def action_review_answer_by_tl(self):
        if self.env.user.id == self.team_leader_id.id:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Survey',
                'view_mode': 'form',
                'res_model': 'survey.user_input',
                'res_id': self.env['survey.user_input'].search([('survey_token', '=', self.access_token)]).id,
                'context': {'edit': False},
            }
        else:
            raise ValidationError('Sorry only the assigned team leader can view the answers.')

    def action_review_answer_by_qa(self):
        if self.env.user.id == self.qa_specialist_id.id:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Survey',
                'view_mode': 'form',
                'res_model': 'survey.user_input',
                'res_id': self.env['survey.user_input'].search([('survey_token', '=', self.access_token)]).id,
                'context': {'edit': False},
            }
        else:
            raise ValidationError('Sorry only the assigned QA/QC can view the answers.')

    def action_accept(self):
        vals = [{
            'analysis_id': self.id,
            'details': 'Accept Task',
            'date': fields.Datetime.now(),
            'res_person_id': self.safety_analyst_id.id,
            'remarks': self.safety_analyst_id.name + ' accepted the task.',
        }]
        self.analysis_timeline_ids.create(vals)

        # Alerts
        odoobot = self.env.ref('base.partner_root')
        self.message_post(
            subject='Accept Task',
            body=self.safety_analyst_id.name + ' accepted the task.',
            message_type='comment',
            notify_by_email=False,
            author_id=odoobot.id,
            partner_ids=[4, self.tender_manager_id.partner_id.id])

        self.write({
            'state': 'analysis',
            'hide_new_btn': False,
            'hide_resume_btn': True,
            'hide_submit_btn': True,
        })

    def get_company_string(self):
        self.company_string = self.sudo().tenderer_id.tender_id.company.name

    def get_analysis_count(self):
        self.analysis_count = len(self.tenderer_id.tender_id.tenderer_ids)

    def get_analysis_index(self):
        count = 0
        for i in range(len(self.tenderer_id.tender_id.tenderer_ids)):
            if self.tenderer_id.id == self.tenderer_id.tender_id.tenderer_ids[i].id:
                count = i + 1
                print(count)
        self.analysis_index = count

    def action_proceed_to_crm(self):
        print('action_proceed_to_crm', self)
        if self.env.user.id == self.tender_manager_id.id:
            odoobot = self.env.ref('base.partner_root')
            self.message_post(
                subject='Proceed to Concierge',
                body=self.tender_manager_id.name + ' proceeds the report to ' + self.crm_id.name + '.',
                message_type='comment',
                notify_by_email=False,
                author_id=odoobot.id,
                partner_ids=[self.crm_id.partner_id.id])
            self.write({
                'state': 'concierge',
            })
            self.action_send_email_notification('proceed_to_crm_template', self)
        else:
            raise ValidationError('Sorry only the assigned tender manager is allowed to proceed to concierge.')

    def action_send_by_email(self):
        self.ensure_one()

        if self.env.user.id == self.crm_id.id:
            template = self.env.ref('hawk_base.email_template_send_to_manager', False)
            compose_form = self.env.ref('mail.email_compose_message_wizard_form', False)
            request = self.sign_request_ids[len(self.sign_request_ids) - 1]

            try:
                if not request.completed_document:
                    request.generate_completed_document()

                attachment = self.env['ir.attachment'].sudo().create({
                    'name': self.name + '.pdf',
                    'type': 'binary',
                    'datas': request.completed_document,
                    'res_model': self._name,
                    'res_id': self.id
                })

                template.write({'attachment_ids': [(6, 0, [attachment.id])]})
            except Exception as e:
                _logger.error(str(e))

            ctx = dict(
                default_model='hawk.analysis',
                default_res_id=self.id,
                default_use_template=bool(template),
                default_template_id=template.id,
                default_composition_mode='comment',
                custom_layout='mail.mail_notification_light',
                mark_coupon_as_sent=True,
                force_email=True,
            )
            return {
                'name': _('Compose Email'),
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_model': 'mail.compose.message',
                'views': [(compose_form.id, 'form')],
                'view_id': compose_form.id,
                'target': 'new',
                'context': ctx,
            }
        else:
            raise ValidationError('Sorry only the assigned crm is allowed to send the email.')

    def action_send_email_notification(self, template, analysis_id):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(analysis_id.id)
        self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(analysis_id.id, force_send=True)


class Weight(models.Model):
    _name = 'hawk.analysis.coeff'
    _description = "Hawk Analysis Coefficient"

    name = fields.Char()
    analysis_id = fields.Many2one('hawk.analysis')
    analysis_type_id = fields.Many2one('hawk.analysis.type', related='analysis_id.analysis_type_id')


class AnalysisType(models.Model):
    _name = 'hawk.analysis.type'
    _description = 'hawk.analysis.type model'

    name = fields.Char()
    sequence = fields.Integer()
    is_active = fields.Boolean(default=True)
    analysis_ids = fields.One2many('hawk.analysis', 'analysis_type_id')


class AnalysisTimeline(models.Model):
    _name = 'hawk.analysis.timeline'
    _description = "Hawk Analysis Timeline"

    analysis_id = fields.Many2one('hawk.analysis')
    date = fields.Datetime(string='Date')
    details = fields.Char(string='Details')
    res_person_id = fields.Many2one('res.users', string='Responsible Person')
    remarks = fields.Char(string='Remarks')


class MailComposeMessage(models.TransientModel):
    _inherit = 'mail.compose.message'
    is_hawk = fields.Boolean(string='Is Hawk App', default=False)

    @api.model
    def default_get(self, fields):
        result = super(MailComposeMessage, self).default_get(fields)
        try:
            if result.get('model') == 'hawk.analysis':
                result['is_hawk'] = True
                # result['subject'] = self.env['mail.template'].browse(result.get('template_id')).subject
        except Exception as e:
            print('Error in MailComposeMessage - hawk_base/analysis.py')
        return result

    def get_mail_values(self, res_ids):
        """Generate the values that will be used by send_mail to create mail_messages
        or mail_mails. """
        self.ensure_one()
        results = dict.fromkeys(res_ids, False)
        rendered_values = {}
        mass_mail_mode = self.composition_mode == 'mass_mail'

        if self.is_hawk:
            email_add = 'HTA.portal@think-savvy.com'
            self.email_from = self.env['res.partner'].sudo().search([('email', '=', email_add)], limit=1).email_formatted
            analysis = self.env['hawk.analysis'].browse(res_ids[0])
            analysis_name = analysis.name
            tender_title = analysis.tenderer_id.tender_id.name
            self.subject = '{} | Hawk Appraisal for {}'.format(analysis_name, tender_title)

            # for attachment in self.attachment_ids:
            #     if '.pdf' not in attachment.name and attachment.mimetype == 'application/pdf':
            #         attachment.name = attachment.name + '.pdf'

        # render all template-based value at once
        if mass_mail_mode and self.model:
            rendered_values = self.render_message(res_ids)
        # compute alias-based reply-to in batch
        reply_to_value = dict.fromkeys(res_ids, None)
        if mass_mail_mode and not self.no_auto_thread:
            records = self.env[self.model].browse(res_ids)
            reply_to_value = records._notify_get_reply_to(default=self.email_from)

        blacklisted_rec_ids = set()
        if mass_mail_mode and issubclass(type(self.env[self.model]), self.pool['mail.thread.blacklist']):
            self.env['mail.blacklist'].flush(['email'])
            self._cr.execute("SELECT email FROM mail_blacklist")
            blacklist = {x[0] for x in self._cr.fetchall()}
            if blacklist:
                targets = self.env[self.model].browse(res_ids).read(['email_normalized'])
                # First extract email from recipient before comparing with blacklist
                blacklisted_rec_ids.update(target['id'] for target in targets
                                           if target['email_normalized'] in blacklist)

        for res_id in res_ids:
            # static wizard (mail.message) values
            mail_values = {
                'subject': self.subject,
                'body': self.body or '',
                'parent_id': self.parent_id and self.parent_id.id,
                'partner_ids': [partner.id for partner in self.partner_ids],
                'attachment_ids': [attach.id for attach in self.attachment_ids],
                'author_id': self.author_id.id,
                'email_from': self.email_from,
                'record_name': self.record_name,
                'no_auto_thread': self.no_auto_thread,
                'mail_server_id': self.mail_server_id.id,
                'mail_activity_type_id': self.mail_activity_type_id.id,
            }

            # mass mailing: rendering override wizard static values
            if mass_mail_mode and self.model:
                record = self.env[self.model].browse(res_id)
                mail_values['headers'] = record._notify_email_headers()
                # keep a copy unless specifically requested, reset record name (avoid browsing records)
                mail_values.update(notification=not self.auto_delete_message, model=self.model, res_id=res_id, record_name=False)
                # auto deletion of mail_mail
                if self.auto_delete or self.template_id.auto_delete:
                    mail_values['auto_delete'] = True
                # rendered values using template
                email_dict = rendered_values[res_id]
                mail_values['partner_ids'] += email_dict.pop('partner_ids', [])
                mail_values.update(email_dict)
                if not self.no_auto_thread:
                    mail_values.pop('reply_to')
                    if reply_to_value.get(res_id):
                        mail_values['reply_to'] = reply_to_value[res_id]
                if self.no_auto_thread and not mail_values.get('reply_to'):
                    mail_values['reply_to'] = mail_values['email_from']
                # mail_mail values: body -> body_html, partner_ids -> recipient_ids
                mail_values['body_html'] = mail_values.get('body', '')
                mail_values['recipient_ids'] = [(4, id) for id in mail_values.pop('partner_ids', [])]

                # process attachments: should not be encoded before being processed by message_post / mail_mail create
                mail_values['attachments'] = [(name, base64.b64decode(enc_cont)) for name, enc_cont in email_dict.pop('attachments', list())]
                attachment_ids = []
                for attach_id in mail_values.pop('attachment_ids'):
                    new_attach_id = self.env['ir.attachment'].browse(attach_id).copy({'res_model': self._name, 'res_id': self.id})
                    attachment_ids.append(new_attach_id.id)
                attachment_ids.reverse()
                mail_values['attachment_ids'] = self.env['mail.thread']._message_post_process_attachments(
                    mail_values.pop('attachments', []),
                    attachment_ids,
                    {'model': 'mail.message', 'res_id': 0}
                )['attachment_ids']
                # Filter out the blacklisted records by setting the mail state to cancel -> Used for Mass Mailing stats
                if res_id in blacklisted_rec_ids:
                    mail_values['state'] = 'cancel'
                    # Do not post the mail into the recipient's chatter
                    mail_values['notification'] = False

            results[res_id] = mail_values
        return results

    # State Manager
    def send_mail(self, auto_commit=False):
        analysis = self.env['hawk.analysis'].browse(self.env.context.get('active_ids'))
        try:
            if self.is_hawk:
                if analysis.state == 'concierge':
                    vals = [{
                        'analysis_id': analysis.id,
                        'details': 'Send Report',
                        'date': fields.Datetime.now(),
                        'res_person_id': analysis.crm_id.id,
                        'remarks': analysis.crm_id.name + ' sent the email to the client successfully.',
                    }]
                    analysis.analysis_timeline_ids.create(vals)

                    # Alerts
                    odoobot = self.env.ref('base.partner_root')
                    analysis.message_post(
                        subject='Send Report',
                        body=analysis.crm_id.name + ' sent the email to the client successfully.',
                        message_type='comment',
                        subtype_xmlid='mail.mt_comment',
                        notify_by_email=False,
                        author_id=odoobot.id,
                        partner_ids=[analysis.tender_manager_id.partner_id.id, analysis.team_leader_id.partner_id.id, analysis.safety_analyst_id.partner_id.id])

                    self.action_send_email_notification('send_to_client_template', analysis)
                    analysis.write({'state': 'done'})
        except Exception as e:
            print(str(e))
        return super(MailComposeMessage, self).send_mail(auto_commit=auto_commit)

    def action_send_email_notification(self, template, analysis_id):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(analysis_id.id)
        self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(analysis_id.id, force_send=True)
