# -*- coding: utf-8 -*-

from odoo import models, fields, api


class User(models.Model):
    _inherit = 'res.users'

    phone = fields.Char(related='partner_id.phone', store=True)
    function = fields.Char(related='partner_id.function', readonly=True)

    company_abn = fields.Char(related='company_id.ab_number', string='ABN')
    company_email = fields.Char(related='company_id.email', string='Company Email')
    company_website = fields.Char(related='company_id.website', string='Company Website')

    company_street = fields.Char(related='company_id.street', string='Company Street')
    company_street2 = fields.Char(related='company_id.street2', string='Company Street2')
    company_city = fields.Char(related='company_id.city', string='Company City')
    company_zip = fields.Char(related='company_id.zip', string='Company Zip')
    company_state_id = fields.Many2one(related='company_id.state_id')
    company_country_id = fields.Many2one(related='company_id.country_id', string='Company Country')

    office_street = fields.Char()
    office_street2 = fields.Char()
    office_city = fields.Char()
    office_zip = fields.Char()
    office_state_id = fields.Many2one('res.country.state')
    office_country_id = fields.Many2one('res.country')

    def preference_save(self):
        if self.phone:
            self.partner_id.phone = self.phone
        if self.office_street:
            self.partner_id.street = self.office_street
        if self.office_street2:
            self.partner_id.street2 = self.office_street2
        if self.office_city:
            self.partner_id.city = self.office_city
        if self.office_zip:
            self.partner_id.zip = self.office_zip
        if self.office_state_id:
            self.partner_id.state_id = self.office_state_id
        if self.office_country_id:
            self.partner_id.country_id = self.office_country_id
        return {
            'type': 'ir.actions.client',
            'tag': 'reload_context',
        }
