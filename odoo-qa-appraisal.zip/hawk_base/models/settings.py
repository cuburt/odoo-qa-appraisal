# -*- coding: utf-8 -*-

from odoo import api, fields, models


class HawkConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    safety_access_token = fields.Char(string='Safety Questionnaire')

    def set_values(self):
        res = super(HawkConfigSettings, self).set_values()
        self.env['ir.config_parameter'].set_param('hawk_base.safety_access_token', self.safety_access_token)

    @api.model
    def get_values(self):
        res = super(HawkConfigSettings, self).get_values()
        params = self.env['ir.config_parameter'].sudo()
        safety_access_token = params.get_param('hawk_base.safety_access_token')
        res.update(
            safety_access_token=safety_access_token,
        )
        return res
