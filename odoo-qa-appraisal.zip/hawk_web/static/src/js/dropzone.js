function createDropzone(i, token, dropzone_placeholder){
    try {
        console.log('Initializing dropzone...');
        Dropzone.autoDiscover = false;
        let myDropzone = new Dropzone("div#myDropzone_"+i, {
            url: "/attachment-form/upload/" + token + "/" + i,
            paramName: 'file_'+i,
            chunking: true,
            retryChunks: true,
            parallelChunkUploads: false,
            addRemoveLinks: true,
            parallelUploads: 1,
            retryChunksLimit: 10,
            maxFilesize: 1024,
            timeout: 1800000,
            chunkSize: 128000000,
            params: function (files, xhr, chunk){
                        dropzone_placeholder.classList.add('hide_me');
                        if (chunk) {
                            return {
                                'dzUuid': chunk.file.upload.uuid,
                                'dzChunkIndex': chunk.index,
                                'dzTotalChunkCount': chunk.file.upload.totalChunkCount,
                            };
                        }
                    },
            removedfile: function(file) {
                        var name = file.name;
                        removePlaceholder(myDropzone, dropzone_placeholder);
                        $.ajax({
                            type: "POST",
                            url: "/attachment-form/delete/" + token + "/" + i + "/id=" + name,
                            dataType: "html"
                        });
                        removeFile();
                        var _ref;
                        return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
                    }
        });

        document.getElementById("myDropzone_"+i).classList.add("dropzone");

        myDropzone.on("sending", function(file) {
            document.getElementById("formSubmit").style.visibility = "hidden";
        });

        myDropzone.on("complete", function(file) {
            if (file.status == 'success') {
                removeFile();
            }
//            else {
//                alert('Unable to read the uploaded file due to access restrictions. \nPlease removed the file and reupload a new one. \nIf the problem persists, please contact concierge@think-savvy.com to assist you.')
//            }
        });

        function removeFile(){

            var complete_dropbox = 0;
            var tenderer_count = document.getElementsByClassName("dropzone").length;

            for (var index=0;index <= tenderer_count;index++) {
                cur_dropzone = document.getElementById("myDropzone_"+index);
                if (cur_dropzone && cur_dropzone.dropzone
                && cur_dropzone.dropzone.getUploadingFiles().length === 0
                && cur_dropzone.dropzone.getQueuedFiles().length === 0
                && cur_dropzone.dropzone.files.length !== 0) {
                    complete_dropbox += 1;
                }
            }

            if (complete_dropbox === tenderer_count) {
                document.getElementById("formSubmit").style.visibility = "visible";
            } else {
                document.getElementById("formSubmit").style.visibility = "hidden";
            }
        }

        function removePlaceholder(myDropzone, dropzone_placeholder) {
            if (myDropzone.files.length === 0) {
                dropzone_placeholder.classList.remove('hide_me');
            }
        }

    }
    catch(err){
        console.log(err.message);
    }
}


