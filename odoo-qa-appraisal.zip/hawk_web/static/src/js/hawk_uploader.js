/* Attachment */
function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

var data_list = [];

function showFile(input_id) {
    var input_field = document.getElementById(input_id);
    var files = input_field.files;
    var parent = input_field.parentElement.parentElement.parentNode;

//      FOR CLEARING PROGRESSBARS APPROACH
//    var progressBars = parent.getElementsByClassName("progress-bar");
//
//    if (progressBars.length != 0) {
//        console.log(progressBars.length);
//        console.log(progressBars);
//        for (var p = 0;p<progressBars.length; p++) {
//            progressBars[p].remove();
//        }
//    }

//    if (files != null && files.length >= 1) {
    var data = {};
    var data_dt = new DataTransfer();

    console.log('local file_list');
    console.log(input_field.files);

//      update input field files with the original files
    var temp_dt = new DataTransfer();

    for (let y = 0;y<files.length; y++) {
        data_dt.items.add(files[y]);
    }

//      store parent input and datatransfer containing files to a dictionary
    data['input_field'] = input_field;
    data['data_dt'] = data_dt;
//      store dictionary to global data list
    data_list.push(data);

    for (var dl=0;dl<data_list.length;dl++) {
        if (data_list[dl].input_field.id == input_field.id) {
            for (var dt=0;dt<data_list[dl].data_dt.files.length;dt++) {
                if (data_list[dl].data_dt.files[dt].idx == null) {
                    data_list[dl].data_dt.files[dt].idx = uuidv4();
                }
                temp_dt.items.add(data_list[dl].data_dt.files[dt]);
            }
        }
    }

    console.log('temp_dt file_list');
    console.log(temp_dt.files);

    for (let y = 0;y<files.length; y++) {


        var reader = new FileReader();
        addListeners(reader);

        for (let x=0;x<temp_dt.files.length;x++) {
            if (files[y] == temp_dt.files[x]) {

                var progressBar = document.createElement('div');
                progressBar.classList.add("progress-bar");
                progressBar.style.margin = "3mm 0mm 3mm";
                progressBar.style.border = "1px solid #5a3d98";
                progressBar.style.borderRadius = "5px";
                progressBar.style.boxShadow = "0 0 15px 1px rgba(0, 0, 0, 0.4)";
                progressBar.style.overflow = "hidden";
                progressBar.style.padding = "0";

                var progressBarFill = document.createElement('div');
                progressBarFill.classList.add("progress-bar-fill");
                progressBarFill.classList.add("row");
                progressBarFill.style.backgroundColor = "#ADA0CE";
                progressBarFill.style.margin = "0";
                progressBarFill.style.padding = "0";

                var progressBarTextDiv = document.createElement('div');
                progressBarTextDiv.style.padding = "0";
                progressBarTextDiv.style.margin = "0";
                progressBarTextDiv.style.backgroundColor = "transparent";

                var progressBarText = document.createElement('span');
                progressBarText.classList.add("progress-bar-text");
                progressBarText.style.margin = "2mm 2mm 2mm";
                progressBarText.style.color = "#5a3d98";
                progressBarText.style.fontSize = "9pt";
                progressBarText.style.textAlign = "left";
                progressBarText.textContent = '0%';

                progressBarTextDiv.appendChild(progressBarText);

                var deleteButtonDiv = document.createElement('div');
                deleteButtonDiv.style.padding = "0";
                deleteButtonDiv.style.margin = "0";
                deleteButtonDiv.style.backgroundColor = "transparent";
                deleteButtonDiv.style.position = "absolute";
                deleteButtonDiv.style.right = "8mm";

                var deleteButton = document.createElement('input');
                deleteButton.setAttribute('type', 'button');
                deleteButton.value = "X"
                deleteButton.style.margin = "1.5mm";
                deleteButton.style.padding = "0";
                deleteButton.style.border = "1px solid #5a3d98";
                deleteButton.style.borderRadius = "15px";
                deleteButton.style.width = "4mm";
                deleteButton.style.height = "4mm";
                deleteButton.style.backgroundColor = "#cb2b46";
                deleteButton.style.color = "#ffffff";
                deleteButton.style.fontWeight = "900";
                deleteButton.style.fontSize = "6pt";
                deleteButton.style.verticalAlign = "middle";
                deleteButton.style.textAlign = "center";

                deleteButtonDiv.appendChild(deleteButton);

                progressBarFill.appendChild(progressBarTextDiv);
                progressBar.appendChild(progressBarFill);
                progressBar.appendChild(deleteButtonDiv);
                parent.appendChild(progressBar);

                deleteButton.fileIndex = temp_dt.files[x].idx;
                deleteButton.addEventListener('click', deleteFile);

                function deleteFile(evt) {
                    evt.preventDefault();
                    console.log('delete');
                    console.log(input_field.files);
                    console.log(evt.target.fileIndex);
                    console.log(evt);
                    var dt = new DataTransfer();

                    for (let i = 0;i<input_field.files.length;i++) {
                        if (evt.target.fileIndex != input_field.files[i].idx) {
                            dt.items.add(input_field.files[i]);
                        }
                    }

                    input_field.files = dt.files;
                    console.log('new input files');
                    console.log(input_field.files);
                    temp_dt = dt;
                    console.log('dt.files');
                    console.log(dt.files);
                    console.log('new temp dt');
                    console.log(temp_dt.files);
                    evt.target.parentElement.parentNode.remove();

                    for (let dl=0;dl<data_list.length;dl++) {
                        if (data_list[dl].input_field.id == input_field.id) {
                            var cur_dt = new DataTransfer();
                            for (let dt=0;dt<data_list[dl].data_dt.files.length;dt++) {
                                for (let tdt=0;tdt<temp_dt.files.length;tdt++) {
                                    if (temp_dt.files[tdt].idx == data_list[dl].data_dt.files[dt].idx) {
                                        cur_dt.items.add(data_list[dl].data_dt.files[dt]);
                                    }
                                }
                            }
                            data_list[dl].data_dt = cur_dt;
                            data_list[dl].data_dt.files = cur_dt.files;
                            console.log(data_list[dl].input_field.id);
                            console.log(cur_dt.files);
                            console.log(data_list[dl].data_dt.files);
                        }
                    }

                    console.log('updated data list');
                    console.log(data_list);

                }

                reader.progressBarFill = progressBarFill;
                reader.progressBarText = progressBarText;
                reader.file = temp_dt.files[x];
                reader.readAsDataURL(temp_dt.files[x]);
            }
        }
    }

    if (temp_dt.files.length != 0) {
        console.log('input files changed')
        input_field.files = temp_dt.files;
        console.log(input_field.files);
    }

    console.log('global file_list');
    console.log(input_field.files);

//    if (input_field.files.length > 5) {
//        alert('Maximum of five pdf files per tenderer is allowed.');
//        return false;
//    }

    console.log(data);
    console.log(data_list);

    function handleEvent(event) {
        var progressBarText = event.target.progressBarText;
        var progressBarFill = event.target.progressBarFill;
        var percent = event.lengthComputable ? (event.loaded/event.total) * 100 : 0;

        console.log(`${event.type}: ${event.loaded} of ${event.total} bytes transferred\n`);
        console.log(percent);

        progressBarFill.style.width = percent + "%";
        progressBarText.textContent = percent + "%";

        if (event.loaded == event.total) {
            progressBarText.textContent = event.target.file.name;
            progressBarText.style.color = "#ffffff";
        }
    }

    function addListeners(reader) {
//                reader.addEventListener('loadstart', handleEvent);
//                reader.addEventListener('load', handleEvent);
//                reader.addEventListener('loadend', handleEvent);
        reader.addEventListener('progress', handleEvent);
//                reader.addEventListener('error', handleEvent);
//                reader.addEventListener('abort', handleEvent);
    }
//    }
};