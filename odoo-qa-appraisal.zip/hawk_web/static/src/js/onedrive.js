function launchSaveToOneDrive(input_id){
    var odOptions = {
      clientId: "37832f77-fe0d-417f-aa1d-ffc9a4ff37d5",
      action: "save",
      sourceInputElementId: input_id.id,
      sourceUri: "",
      fileName: "file.txt",
      openInNewWindow: false,
      advanced: {},
      success: function(files) { /* success handler */ },
      progress: function(percent) { /* progress handler */ },
      cancel: function() { /* cancel handler */ },
      error: function(error) { /* error handler */ }
    }
    OneDrive.save(odOptions);
}