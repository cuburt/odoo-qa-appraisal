odoo.define('my.HawkWeb', function (require) {

    var current_fs, next_fs, previous_fs;

    var left, opacity, scale;
    var Dialog = require('web.Dialog');

    var animating;

    // Need to improve this, when refreshing the page the header and footer display in split second
    // hide header and footer only for this client page
    $(document).ready(function() {
        if ($('.hawk-divider').length > 0) {
            $('.o_header_standard').addClass('client-page-header')
            $('.o_footer').addClass('client-page-footer')
        }
        $('#msform>#your-details-fieldset>.action-button-disabled').each(function() {
            $(this).prop('disabled', false);
            $(this).removeClass("action-button-disabled");
        });
        $('#msform>#file-upload-fieldset>.action-button-disabled').each(function() {
            $(this).prop('disabled', false);
            $(this).removeClass("action-button-disabled");
        });
        $('.your-details-input').each(function() {
            $(this).prop('disabled', false);
        });
        $('#street2').prop('disabled', false);
    });

    $(".edit").click(function(){
        var input = $('.list-group-flush input')
        input.each(function() {
            $(this)[0].disabled = false;
        })
    });

    $("#first_next").click(function(){
        var input = $('.your-details-input');
        let is_missing_field = new Boolean(false);
        var validations = [];

        input.each(function() {
            $(this).removeClass("is-invalid is-valid");
            userText = $(this).val().replace(/^\s+/, '').replace(/\s+$/, '');
            inputType = $(this).attr('type');


            if (userText == '') {
                if (inputType == 'tel') {
                    $('div#invalid-phone-feedback').text( "Phone number required.");
                    $('div#invalid-phone-feedback').css("display","block");
                }
                if (inputType == 'email') {
                    $('div#invalid-email-feedback').text("Please enter your email address.");
                }
                $(this).addClass('is-invalid');
                is_missing_field = true;
            }
            else {
//                $(this).addClass('is-valid'); //removed "Looks Good"
                is_missing_field = false;

                if (inputType == 'tel') {
                    var telText = $(this).val();
                    if (telText.indexOf('-') != -1) {
                        telText.replace('-','');
                    }
                    if (telText.length != 10) {
                        $('div#invalid-phone-feedback').text("10 digits required.");
                        $(this).addClass('is-invalid');
                        $('div#valid-phone-feedback').css("display","none");
                        $('div#invalid-phone-feedback').css("display","block");
                        is_missing_field = true;
                    } else {
                       $('div#invalid-phone-feedback').css("display","none");
//                       $('div#valid-phone-feedback').css("display","block"); //removed "Looks Good"
                    }
                }

                if (inputType == 'email') {
                    var emailText = $(this).val();
                    if (emailText.indexOf('@') == -1) {
                        $('div#invalid-email-feedback').text("Email address should have '@'.");
                        $(this).addClass('is-invalid');
                        is_missing_field = true;
                    }
                }
            }
            validations.push(is_missing_field);
        });

        if (jQuery.inArray(true, validations) === -1) {
            if(animating) return false;
            animating = true;

            current_fs = $(this).parent();
            next_fs = $(this).parent().next();

            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

            next_fs.show();

            current_fs.animate({opacity: 0}, {step: function(now, mx) {
                scale = 1 - (1 - now) * 0.2;
                left = (now * 50)+"%";
                opacity = 1 - now;
                current_fs.css({
                    'transform': 'scale('+scale+')'
                });
                next_fs.css({
                    'left': left,
                    'opacity': opacity
                });
            },
            duration: 800,
            complete: function(){
                current_fs.hide();
                animating = false;
            },
            easing: 'easeInOutBack'
            });
        }
        $('#success-alert').css('display', 'none');
    });

    $("#second_next").click(function(){
        var input = $('.tender-details-input')
        let is_missing_field = new Boolean(false)
        var validations = [];

        input.each(function() {
            $(this).removeClass("is-invalid is-valid");
            userText = $(this).val().replace(/^\s+/, '').replace(/\s+$/, '');

            if (userText == '') {
                $(this).addClass('is-invalid');
                is_missing_field = true;
            } else {
//                $(this).addClass('is-valid'); //removed "Looks Good"
                is_missing_field = false;
            }
            validations.push(is_missing_field);
        });

        var tenderer_count = $('#tenderer_count').val();

        if (!$.isNumeric(tenderer_count) && !is_missing_field) {
            Dialog.alert(this, "Invalid value for the number of tenderers");
            return false;
        }

        validations.push(!checkDuplicates());

        if (jQuery.inArray(true, validations) === -1) {

            if(animating) return false;
            animating = true;

            current_fs = $(this).parent();
            next_fs = $(this).parent().next();

            $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

            next_fs.show();

            current_fs.animate({opacity: 0}, {step: function(now, mx) {
                scale = 1 - (1 - now) * 0.2;
                left = (now * 50)+"%";
                opacity = 1 - now;
                current_fs.css({
                    'transform': 'scale('+scale+')'
                });
                next_fs.css({
                    'left': left,
                    'opacity': opacity
                });
            },
            duration: 800,
            complete: function(){
                current_fs.hide();
                animating = false;
            },
            easing: 'easeInOutBack'
            });
        }
    });


    $("#third_next").click(function(){
        var productCheckbox = $('.productCheckbox:checked')

        if (productCheckbox.length == 0) {
            Dialog.alert(this, "Please select service(s).");
            breakOut = true;
            return false;
        }

        if(animating) return false;
        animating = true;

        current_fs = $(this).parent();
        next_fs = $(this).parent().next();

        $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

        next_fs.show();

        current_fs.animate({opacity: 0}, {step: function(now, mx) {
            scale = 1 - (1 - now) * 0.2;
            left = (now * 50)+"%";
            opacity = 1 - now;
            current_fs.css({
                'transform': 'scale('+scale+')'
            });
            next_fs.css({
                'left': left,
                'opacity': opacity
            });
        },
        duration: 800,
        complete: function(){
            current_fs.hide();
            animating = false;
        },
        easing: 'easeInOutBack'
        });
    });

    $("#fourth_next").click(function(){
        if(animating) return false;
        animating = true;

        current_fs = $(this).parent();
        next_fs = $(this).parent().next();

        $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

        next_fs.show();

        current_fs.animate({opacity: 0}, {step: function(now, mx) {
            scale = 1 - (1 - now) * 0.2;
            left = (now * 50)+"%";
            opacity = 1 - now;
            current_fs.css({
                'transform': 'scale('+scale+')'
            });
            next_fs.css({
                'left': left,
                'opacity': opacity
            });
        },
        duration: 800,
        complete: function(){
            current_fs.hide();
            animating = false;
        },
        easing: 'easeInOutBack'
        });
    });


    $(".previous").click(function(){
        if(animating) return false;
        animating = true;

        current_fs = $(this).parent();
        previous_fs = $(this).parent().prev();

        $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

        previous_fs.show();

        current_fs.animate({opacity: 0}, {step: function(now, mx) {
            scale = 0.8 + (1-now) * 0.2;
            left = ((1-now) * 50)+"%";
            opacity = 1-now;
            current_fs.css({
                'left':left
            });
            previous_fs.css({
                'transform': 'scale('+scale+')',
                'opacity': opacity
            });
        },
        duration: 800,
        complete: function(){
            current_fs.hide();
            animating = false;
        },
        easing: 'easeInOutBack'
        });
    });
}); //end of the odoo.define('my.HawkWeb', function (require)

function checkIfArrayIsUnique(myArray) {
    return myArray.length === new Set(myArray).size;
}

function checkDuplicates() {
    let divs = document.getElementsByClassName('tenderer-row');
    var duplicates = [];
    for (var i = 0; i < divs.length; i++) {
        let div = divs.item(i);
        let inputs = div.getElementsByTagName('input');
        for (var x = 0; x < inputs.length; x++) {
            let input = inputs.item(x);
            if (input.value != "" && duplicates.includes(input.value.toLowerCase().replace(/\s/g, ""))) {
                let invalid_feedbacks = div.getElementsByClassName('invalid-feedback');
                for (var y = 0; y < invalid_feedbacks.length; y++) {
                    let invalid_feedback = invalid_feedbacks.item(y);
                    invalid_feedback.textContent = "You can't have a duplicate name for this tenderer.";
                }
                input.classList.remove('is-valid');
                input.classList.add('is-invalid');
            }
            else if (input.value != "" && !duplicates.includes(input.value.toLowerCase().replace(/\s/g, ""))) {
                input.classList.remove('is-invalid');
//                input.classList.add('is-valid'); //removed "Looks Good"
            }
            else {
                let invalid_feedbacks = div.getElementsByClassName('invalid-feedback');
                for (var y = 0; y < invalid_feedbacks.length; y++) {
                    let invalid_feedback = invalid_feedbacks.item(y);
                    invalid_feedback.textContent = "Enter tenderer's name.";
                }
            }
            duplicates.push(input.value.toLowerCase().replace(/\s/g, ""));
        }
    }
    return checkIfArrayIsUnique(duplicates)
}

function SafetyFunction() {
    var productCheckbox = $('.productCheckbox')

    if (productCheckbox.prop('checked')) {
        productCheckbox.prop("checked", false);
    } else {
        productCheckbox.prop("checked", true);
    }
}

function productFunction() {
    var data = JSON.parse(decodeURIComponent(document.getElementById("hiddenFieldset").getAttribute("data-json")));
	var selected = new Array();

        //Reference the Table.
        var productTable = document.getElementById("productTable");

        //Reference all the CheckBoxes in Table.
        var chks = productTable.getElementsByTagName("INPUT");

        // Loop and push the checked CheckBox value in Array.
        for (var i = 0; i < chks.length; i++) {
            if (chks[i].checked) {
                selected.push(parseInt(chks[i].value));
            }
        }

    var tbl = document.getElementsByClassName("weightTable")[0];
    var tbdy = document.createElement("tbody");

    for (var index in data) {

        if (selected.includes(parseInt(data[index].id)) && !(document.getElementById(data[index].name + "_weight"))){
//            alert("category value: "+ selected.join(",") +' : '+ data[index].id);
            var tr = document.createElement("tr");
            var th = document.createElement("th");
            var title = document.createTextNode(data[index].name);
            var tooltipDiv = document.createElement("div");
            tooltipDiv.classList.add("tooltip-container");
            tooltipDiv.style.marginRight = "10px";
            var tooltipIcon = document.createElement("span");
            tooltipIcon.classList.add("tooltip-icon");
            tooltipIcon.classList.add("fa");
            tooltipIcon.classList.add("fa-info-circle");
            var tooltipText = document.createElement("span");
            tooltipText.classList.add("tooltip-text");
            tooltipText.innerText = data[index].tooltip;
            tooltipDiv.appendChild(tooltipIcon);
            tooltipDiv.appendChild(tooltipText);
            th.style.textAlign = 'left';
            th.appendChild(tooltipDiv);
            th.appendChild(title);
            tr.appendChild(th);
            for (var i = 1; i < 4; i++) {
                if (i==1){
                    var td = document.createElement("td");
                    var input = document.createElement("input");
                    input.type = "radio";
                    input.id = data[index].name + "_weight";
                    input.name = data[index].name + "_weight";
                    input.value = i;
                    input.checked = "checked";
                    td.appendChild(input);
                    tr.appendChild(td);
                } else {
                    var td = document.createElement('td');
                    var input = document.createElement('input');
                    input.type = "radio";
                    input.id = data[index].name + '_weight';
                    input.name = data[index].name + '_weight';
                    input.value = i;
                    td.appendChild(input);
                    tr.appendChild(td);
                }

            }
            tbdy.appendChild(tr);
        } else {
            tbdy.innerHTML = "";
            selected = new Array();
        }

    }
    tbl.appendChild(tbdy);

}

function tendererFunction(tendererCount=false) {
    var parentForm = document.getElementById('tendererGroup');
    if (!tendererCount) var tendererCount = document.getElementById('tenderer_count').value;
    var token = document.getElementsByName('token')[0].value;
    var formGroupElementCount = parentForm.getElementsByClassName("form-group");

    if (tendererCount && formGroupElementCount.length == 0) {
        for (var i=0;i<parseInt(tendererCount);i++) {

            var formGroup = document.createElement('div');
            formGroup.classList.add("form-group");
            var formInput = document.createElement('input');
            formInput.classList.add("form-control");
//            formInput.style.marginBottom = "5mm";
            formInput.type = "text";
            formInput.placeholder = String(i+1)+". Tenderer Name";
            formInput.name = "tenderer_name_"+String(i);
            formInput.required = true;
            formInput.value = document.getElementById(String(i + 1)).value;
            var dropZone = document.createElement('div');
            dropZone.id = "myDropzone_"+String(i);

            var dropzone_placeholder = document.createElement('span');
            dropzone_placeholder.classList.add("dropzone_ph");
            dropzone_placeholder.textContent = "Choose a file or drag it here";

            dropZone.appendChild(dropzone_placeholder);

            formGroup.appendChild(formInput);
            formGroup.appendChild(document.createElement('br'));
            formGroup.appendChild(dropZone);
            parentForm.appendChild(formGroup);
            parentForm.appendChild(document.createElement('br'));

            formInput.addEventListener("focus", createDropzone(String(i), token, dropzone_placeholder));
        }
    }
    if (tendererCount && (formGroupElementCount.length < parseInt(tendererCount))) {
        for (var i=formGroupElementCount.length;i<parseInt(tendererCount);i++) {

            var formGroup = document.createElement('div');
            formGroup.classList.add("form-group");
            var formInput = document.createElement('input');
            formInput.classList.add("form-control");
//            formInput.style.marginBottom = "5mm";
            formInput.type = "text";
            formInput.placeholder = String(i+1)+". Tenderer Name";
            formInput.name = "tenderer_name_"+String(i);
            formInput.required = true;
            formInput.value = document.getElementById(String(i + 1)).value;
            var dropZone = document.createElement('div');
            dropZone.id = "myDropzone_"+String(i);

            var dropzone_placeholder = document.createElement('span');
            dropzone_placeholder.classList.add("dropzone_ph");
            dropzone_placeholder.textContent = "Choose a file or drag it here";

            dropZone.appendChild(dropzone_placeholder);

            formGroup.appendChild(formInput);
            formGroup.appendChild(document.createElement('br'));
            formGroup.appendChild(dropZone);
            parentForm.appendChild(formGroup);
            parentForm.appendChild(document.createElement('br'));

            formInput.addEventListener("focus", createDropzone(String(i), token, dropzone_placeholder));
        }
    }
    if (parseInt(tendererCount) < formGroupElementCount.length) {
        var lastRow = formGroupElementCount[parseInt(formGroupElementCount.length)-1];
        lastRow.remove();
    }

    for (var i = 0; i < formGroupElementCount.length; i++) {
       let grp = formGroupElementCount.item(i);
       let inputs = grp.getElementsByTagName('input');
       for (var x = 0; x < inputs.length; x++) {
            let input = inputs.item(x);
            input.value = document.getElementById(String(i + 1)).value;
       }
    }
}

function onchangeCountry(tender=false) {
    var inputCountry = document.getElementById('country');
    if (!inputCountry) inputCountry = document.getElementById('quot_country');
    if (tender) inputCountry = document.getElementById('tender_country');
    var inputRegion = document.getElementById('region');
    if (!inputRegion) inputRegion = document.getElementById('quot_region');
    if (tender) inputRegion = document.getElementById('tender_region');
    var inputPhoneCode = document.getElementById('inputGroupPrependPhoneCode');
    if (!inputPhoneCode) inputPhoneCode = document.getElementById('quotInputGroupPrependPhoneCode');
    var dataList = document.getElementById('regionList');
    if (inputCountry.value) {
        $.ajax({
            type: "POST",
            url: "/filter-region/country=" + inputCountry.value,
            dataType: "html",
            success: function(data) {
                var jsonData = JSON.parse(decodeURIComponent(data));
                dataList.innerHTML = '';
                inputRegion.value = '';
                for (var index in jsonData) {
                    var option = document.createElement('option');
                    option.value = jsonData[index].name;
                    option.innerText = jsonData[index].name;
                    dataList.appendChild(option);
                }
            }
        });
        if (!tender) {
            $.ajax({
                type: "POST",
                url: "/assign-phone-code/country=" + inputCountry.value,
                dataType: "html",
                success: function(phoneCode) {
                    inputPhoneCode.innerText = phoneCode;
                }
            });
        }
    }
}

function onchangeIndustry() {
    var inputIndustry = document.getElementById('industry');
    var inputSubindustry = document.getElementById('sub_industry');
    var dataList = document.getElementById('subindustryList');
    if (inputIndustry.value) {
        $.ajax({
            type: "POST",
            url: "/filter-subindustry/industry=" + inputIndustry.value,
            dataType: "html",
            success: function(data) {
                var jsonData = JSON.parse(decodeURIComponent(data));
                dataList.innerHTML = '';
                inputSubindustry.value = '';
                for (var index in jsonData) {
                    var option = document.createElement('option');
                    option.value = jsonData[index].name;
                    option.innerText = jsonData[index].name;
                    dataList.appendChild(option);
                }
            }
        });
    }
}

function onchangeTendererCount() {
    var tendererCount = document.getElementById('tenderer_count');
    var parentDiv = document.getElementById('tenderer-details');
    var tendererRows = document.getElementsByClassName('tenderer-row');
    for (var i=1; i <= parseInt(tendererCount.value) - 2; i++) {
        if (!(document.getElementById(String(i + 2)))) {
            formRow = document.createElement('div');
            formRow.classList.add('form-row');
            formRow.classList.add('tenderer-row');
            formGroup = document.createElement('div');
            formGroup.classList.add('form-group');
            formGroup.classList.add('col-md-12');
            input = document.createElement('input');
            input.classList.add('form-control');
            input.classList.add('tender-details-input');
            input.type = 'text';
            input.placeholder = String(i + 2) + ". Enter tenderer's name";
            input.id = String(i + 2);
            valid_fdbck = document.createElement('div');
            valid_fdbck.classList.add('valid-feedback');
            valid_fdbck.setAttribute('align','left');
            valid_fdbck.textContent = 'Looks good!';
            invalid_fdbck = document.createElement('div');
            invalid_fdbck.classList.add('invalid-feedback');
            invalid_fdbck.setAttribute('align','left');
            invalid_fdbck.textContent = "Enter tenderer's name.";

            formGroup.appendChild(input);
            formGroup.appendChild(valid_fdbck);
            formGroup.appendChild(invalid_fdbck);
            formRow.appendChild(formGroup);
            parentDiv.appendChild(formRow);
        }
    }
    if (parseInt(tendererCount.value) < parseInt(tendererRows.length)) {
        var lastRow = document.getElementsByClassName('tenderer-row')[parseInt(tendererRows.length)-1];
        lastRow.remove();
    }
}

function submitForm(token, reference) {
    var form = document.getElementById('msform');
    var submitBtn = document.getElementById('formSubmit');
    var submitLoading = document.getElementById('submitLoading');

    var tendererGroup = document.getElementById('tendererGroup');
    var fromGroups = tendererGroup.getElementsByClassName('form-group');
    for (var i = 0; i < fromGroups.length; i++) {
       let formGroup = fromGroups.item(i);
       let inputs = formGroup.getElementsByTagName('input');
       for (var x = 0; x < inputs.length; x++) {
            let input = inputs.item(x);
            input.setAttribute('readonly','true');
       }
    }

    dropzones = document.getElementsByClassName('dropzone');
    for (var i = 0; i < dropzones.length; i++) {
       let dropzone = dropzones.item(i);
       dropzone.classList.add('dropzone-disabled');
    }

    prevBtns = document.getElementsByClassName('action-button-previous');
    for (var i = 0; i < prevBtns.length; i++) {
       let btn = prevBtns.item(i);
       btn.setAttribute('disabled','true');
       btn.classList.add("action-button-previous-disabled");
    }

    submitBtn.setAttribute('disabled','true');
    submitBtn.classList.add("action-button-disabled");
    submitLoading.style.display = 'inline-block';

    if (token && reference) {
        form.setAttribute('action', '/attachment-form/submit?token='+token+'&reference='+reference);
    } else {
        form.setAttribute('action', '/attachment-form/submit');
    }
    form.submit();
}
