# -*- coding: utf-8 -*-
import base64
import json
import urllib.parse
from odoo import http
from odoo.http import request
from werkzeug import urls
import requests
from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.exceptions import AccessDenied, AccessError, UserError, ValidationError
from odoo.addons.base.models.ir_ui_view import keep_query
import logging

_logger = logging.getLogger(__name__)


class Registration(http.Controller):

    @ http.route('/attachment-form/<token>', type='http', auth='public', website=True, sitemap=False)
    def attachment_form(self, token, **kw):
        print(kw)
        try:
            web_tx = request.env['hawk.api.transaction'].sudo().search([('reference', '=', kw.get('reference')),('token', '=', token)])

            if web_tx.state == 'close':
                return request.redirect('/')

            data = eval(request.env['hawk.api.link'].base64_decoder(web_tx.data))

            if not data:
                return http.Response(status=400)

            form = "hawk_web.msform"

            context = {
                'reference': kw.get('reference'),
                'token': token,
                'company': data['company'],
                'contact': data['contact'],
                'tender': data['tender'],
                'products': request.env['hawk.analysis.type'].sudo().search([('is_active', '=', True)]),
                'categories': urllib.parse.quote(json.dumps([{"id": i.analysis_type_id.id, "name": i.name, "tooltip": i.tooltip} for i in request.env['survey.question.category'].sudo().search([('is_active', '=', True)])], separators=(',', ':'))),
                'industries': request.env['hawk.industry'].sudo().search([]),
                'subindustries': request.env['hawk.subindustry'].sudo().search([]),
                'countries': request.env['res.country'].sudo().search([]),
                'regions': request.env['res.country.state'].sudo().search([]),
                'order_id': data['order_id']}

            if 'country' in data['company'] and data['company']['country']:
                context['regions'] = request.env['res.country.state'].sudo().search([('country_id.name', '=', data['company']['country'])])
                context['phone_code'] = request.env['res.country'].sudo().search([('name', '=', data['company']['country'])]).phone_code

            return request.render(form, context)

        except Exception as e:
            _logger.error('Error in attachment_form ', str(e))
            return http.Response(response='Error in attachment_form: ' + str(e), status=403)

    @http.route('/attachment-form', type='http', auth='user', website=True, sitemap=False)
    def internal_attachment_form(self, **kw):
        # TODO: check user's role
        try:
            token = request.env['hawk.api.transaction'].sudo()._get_default_access_token()
            context = {
                'token': token,
                'user': {'name': request.env.user.name},
                'products': request.env['hawk.analysis.type'].sudo().search([('is_active', '=', True)]),
                'categories': urllib.parse.quote(json.dumps([{"id": i.analysis_type_id.id, "name": i.name, "tooltip": i.tooltip} for i in request.env['survey.question.category'].sudo().search([('is_active', '=', True)])],
                            separators = (',', ':'))),
                'industries': request.env['hawk.industry'].sudo().search([]),
                'subindustries': request.env['hawk.subindustry'].sudo().search([]),
                'countries': request.env['res.country'].sudo().search([]),
                'regions': request.env['res.country.state'].sudo().search([])
                            }

            return request.render("hawk_web.msform", context)

        except Exception as e:
            _logger.error('Error in internal_attachment_form ', str(e))
            return http.Response(response='Error in internal_attachment_form: ' + str(e), status=403)

    @http.route('/api/2.0/attachment-form', type='json', auth='public', website=True, methods=['POST'], csrf=False, sitemap=False)
    def attachment_form_api(self, **kw):
        print('attachment_form_api', kw)
        # TODO: send email function here with expirable link
        try:
            headers = dict(request.httprequest.headers)
            session = False
            try:
                session = request.httprequest.args.get('session_id')
            except Exception as e:
                _logger.error('attachment_form_api_session_args_error', str(e))
            try:
                session = request.httprequest.cookies.get('session_id')
            except Exception as e:
                _logger.error('attachment_form_api_session_cookies_error', str(e))
            print('session', session)

            data = json.loads(request.httprequest.data)
            tx = request.env['hawk.api.transaction'].initialize_tx(data, {'headers': headers}, 'api')

            if tx:
                message = tx.message
                id = request.env['hawk.api.link'].base64_encoder(str(tx.id))
                success_url = urls.url_join(request.env['ir.config_parameter'].sudo().get_param('web.base.url'), '/attachment-form/%s?%s' % (tx.token, keep_query(reference= 'api_' + tx.token + str(id))))

            else:
                raise ValidationError(_('Transaction has failed.'))

            return {'success': True, 'status': 'OK', 'code': 200, 'message': message, 'success_url': success_url}

        except Exception as e:
            message = str(e)
            # return {'success': False, 'status': 'INTERNAL SERVER ERROR', 'code': 500, 'message': message}
            return http.Response(response=message, status=500)

    @http.route('/attachment-form/submit', type='http', auth='public', website=True, sitemap=False)
    def attachment_form_submit(self, **kw):
        print('attachment_form_submit', kw)
        try:

            country = request.env['res.country'].sudo().search([('name', '=', kw.get('country'))], limit=1)
            region = request.env['res.country.state'].sudo().search([('name', '=', kw.get('region'))], limit=1)
            tender_country = request.env['res.country'].sudo().search([('name', '=', kw.get('tender_country'))], limit=1)
            tender_region = request.env['res.country.state'].sudo().search([('name', '=', kw.get('tender_region'))], limit=1)
            industry = request.env['hawk.industry'].sudo().search([('name', '=', kw.get('industry'))], limit=1)
            subindustry = request.env['hawk.subindustry'].sudo().search([('name', '=', kw.get('sub_industry'))], limit=1)

            if not subindustry:
                subindustry = request.env['hawk.subindustry'].sudo().create({
                    'industry_id': industry.id,
                    'name': kw.get('sub_industry')
                })

            company = False
            company_has_no_abn = request.env['res.company'].sudo().search([('name', '=', kw.get('company_name'))])
            company_has_correct_abn = request.env['res.company'].sudo().search(['&',('name', '=', kw.get('company_name')), ('ab_number', '=', kw.get('ab_number'))])
            # company_has_incorrect_abn = request.env['res.company'].sudo().search(['&',('name', '=', kw.get('company_name')), ('ab_number', '!=', kw.get('ab_number'))])
            # company_has_incorrect_name = request.env['res.company'].sudo().search(['&',('name', '!=', kw.get('company_name')), ('ab_number', '=', kw.get('ab_number'))])

            if company_has_correct_abn:
                _logger.info('company has correct name and abn')
                company = company_has_correct_abn
                sudo_company = company.sudo()

                if not sudo_company.street:
                    sudo_company.street = kw.get('street')

                if not sudo_company.street2:
                    sudo_company.street2 = kw.get('street2')

                if not sudo_company.city:
                    sudo_company.city = kw.get('city')

                if not sudo_company.state_id:
                    sudo_company.state_id = region.id

                if not sudo_company.state:
                    sudo_company.state = region.name if region else kw.get('region')

                if not sudo_company.country_id:
                    sudo_company.country_id = country.id

                if not sudo_company.country:
                    sudo_company.country = country.name if country else kw.get('country')

                if not sudo_company.company_size:
                    sudo_company.company_size = kw.get('company_size')

            # elif company_has_incorrect_abn:
            #     _logger.info('company has incorrect abn')
            #     message = 'You may have provided us an incorrect business number. Please '
            #     return_url = urls.url_join(request.env['ir.config_parameter'].sudo().get_param('web.base.url'),
            #                                '/attachment-form')
            #     if not request.env.user.id:
            #         id = request.env['hawk.api.link'].base64_encoder(str(kw.get('id')))
            #         return_url = urls.url_join(request.env['ir.config_parameter'].sudo().get_param('web.base.url'),
            #                                    '/attachment-form/%s' % (kw.get('token')))
            #     return request.render("hawk_web.tx_fail_form",
            #                           {'message': message, 'allow_try_again': True, 'return_url': return_url})
            #
            # elif company_has_incorrect_name:
            #     _logger.info('company has incorrect name')
            #     message = 'You may have provided us an incorrect company name. Please '
            #     return_url = urls.url_join(request.env['ir.config_parameter'].sudo().get_param('web.base.url'),
            #                                '/attachment-form')
            #     if not request.env.user.id:
            #         id = request.env['hawk.api.link'].base64_encoder(str(kw.get('id')))
            #         return_url = urls.url_join(request.env['ir.config_parameter'].sudo().get_param('web.base.url'),
            #                                    '/attachment-form/%s' % (kw.get('token')))
            #     return request.render("hawk_web.tx_fail_form",
            #                           {'message': message, 'allow_try_again': True, 'return_url': return_url})

            elif company_has_no_abn:
                _logger.info('company has no abn registered in the system')
                company = company_has_no_abn
                sudo_company = company.sudo()

                if not sudo_company.street:
                    sudo_company.street = kw.get('street')

                if not sudo_company.street2:
                    sudo_company.street2 = kw.get('street2')

                if not sudo_company.city:
                    sudo_company.city = kw.get('city')

                if not sudo_company.state_id:
                    sudo_company.state_id = region.id

                if not sudo_company.state:
                    sudo_company.state = region.name if region else kw.get('region')

                if not sudo_company.country_id:
                    sudo_company.country_id = country.id

                if not sudo_company.country:
                    sudo_company.country = country.name if country else kw.get('country')

                if not sudo_company.company_size:
                    sudo_company.company_size = kw.get('company_size')

            elif not company:
                company = request.env['res.company'].sudo().create({
                    'name': kw.get('company_name'),
                    'street': kw.get('street'),
                    'street2': kw.get('street2'),
                    'city': kw.get('city'),
                    'country_id': country.id,
                    'country': country.name if country else kw.get('country'),
                    'state_id': region.id,
                    'state': region.name if region else kw.get('region'),
                    'company_size': kw.get('company_size'),
                    'ab_number': kw.get('ab_number'),
                })
                _logger.info('...new company created.')

            contact = request.env['res.partner'].sudo().search([
                ('email', '=', kw.get('email')),
                ('parent_id.id', '=', company.partner_id.id)
            ])

            contact.write({
                'function': kw.get('jobtitle')
            })

            if not contact:
                contact = request.env['res.partner'].sudo().create({
                    'name': '%s %s' % (kw.get('firstname'), kw.get('lastname')),
                    'phone': kw.get('phone'),
                    'email': kw.get('email'),
                    'function': kw.get('jobtitle'),
                    'parent_id': company.partner_id.id,
                })
                _logger.info('...new contact created.')

            category = request.env['ir.module.category'].sudo().search([('name','=','HAWK')])
            manager_group = request.env['res.groups'].sudo().search([('category_id.id','=',category.id),('name','=','Tender Manager')])
            crm_group = request.env['res.groups'].sudo().search([('category_id.id','=',category.id),('name','=','Client Relations Manager')])
            admin_group = request.env['res.groups'].sudo().search([('category_id.id','=',category.id),('name','=','Administrator')])
            responsible_person = False

            tender_manager = request.env['res.users'].sudo().search([('login', '=', 'l.bryce@think-savvy.com')], limit=1)
            # tender_manager = request.env['res.users'].sudo().search(
            #         ['&',('groups_id','in',manager_group.id),
            #          '&',('groups_id','not in',crm_group.id),
            #          '|',('groups_id','not in',admin_group.id),
            #          ('login', '=', 'l.bryce@think-savvy.com')], limit=1)

            admin = request.env['res.users'].sudo().search(
                    [('groups_id', 'in', admin_group.id)], limit=1)

            if tender_manager:
                responsible_person = tender_manager[0]

            elif admin:
                responsible_person = admin[0]

            if responsible_person:
                tender = request.env['hawk.tender'].sudo().create({
                    'tender_manager_id': tender_manager.id,
                    'name': kw.get('tender_title'),
                    'reference': kw.get('tender_number'),
                    'country_id': tender_country.id,
                    'country': tender_country.name if tender_country else kw.get('tender_country'),
                    'state_id': tender_region.id,
                    'region': tender_region.name if tender_region else kw.get('tender_region'),
                    'industry': industry.id,
                    'sub_industry': subindustry.id,
                    'tenderer_count': kw.get('tenderer_count'),
                    # 'document_count': kw.get('report_count'),
                    'company': company.id,
                    'contact_id': contact.id,
                    'state': 'new',
                    'token': kw.get('token'),
                    'tenderer_ids': [(4, tenderer.id) for tenderer in
                                     request.env['hawk.tender'].sudo().tenderer_generator(kw)],
                    'order_id': int(kw.get('order_id')) if 'order_id' in kw else False
                })

                # Alerts
                odoobot = request.env.ref('base.partner_root')
                tender.message_post(
                    subject='New Tender Created!',
                    body=tender.tender_manager_id.name + ' is assigned as the tender manager for this newly created tender.',
                    message_type='comment',
                    notify_by_email=False,
                    author_id=odoobot.id,
                    partner_ids=[tender.tender_manager_id.partner_id.id])
                tender.action_send_email_notification('new_tender_template')
                tender.action_send_email_notification('new_tender_for_client_template')
            else:
                tender = request.env['hawk.tender'].sudo().create({
                    'name': kw.get('tender_title') + ' (No Assigned Tender Manager)',
                    'reference': kw.get('tender_number'),
                    'country_id': tender_country.id,
                    'country': tender_country.name if tender_country else kw.get('tender_country'),
                    'state_id': tender_region.id,
                    'region': tender_region.name if tender_region else kw.get('tender_region'),
                    'industry': industry.id,
                    'sub_industry': subindustry.id,
                    'tenderer_count': kw.get('tenderer_count'),
                    # 'document_count': kw.get('report_count'),
                    'company': company.id,
                    'contact_id': contact.id,
                    'state': 'new',
                    'token': kw.get('token'),
                    'tenderer_ids': [(4, tenderer.id) for tenderer in
                                     request.env['hawk.tender'].sudo().tenderer_generator(kw)],
                    'order_id': int(kw.get('order_id')) if 'order_id' in kw else False
                })

                # Alerts
                odoobot = request.env.ref('base.partner_root')
                tender.message_post(
                    subject='New Tender Created!',
                    body='No assigned tender manager for this newly created tender.',
                    message_type='comment',
                    notify_by_email=False,
                    author_id=odoobot.id,
                    partner_ids=[admin[0].partner_id.id]
                )

            if ('token' in kw and 'reference' in kw) and (kw.get('token') and kw.get('reference')):
                web_tx = request.env['hawk.api.transaction'].sudo().search(
                    [('reference', '=', kw.get('reference')), ('token', '=', kw.get('token'))])
                web_tx.state = 'close'

            _logger.info('_______________________________')
            _logger.info('____________SUCCESS____________')
            _logger.info('__tender created successfully__')
            _logger.info('_______________________________')

            message = "Setup Successful"
            return request.render("hawk_web.tx_success_form", {'message': message})

        except Exception as e:
            message = str(e)
            return request.render("hawk_web.tx_fail_form", {'message': message})


    @http.route('/attachment-form/upload/<token>/<sequence>', type='http', methods=['POST'], auth='public', website=True, sitemap=False, csrf=False)
    def attachment_form_upload(self, token, sequence, **kw):
        if sequence and token:

            files = request.httprequest.files.getlist('file_' + str(sequence))
            for file in files:
                try:
                    merged_file = False
                    uuid = False
                    if kw.get('dzUuid'):
                        _logger.info(f"{file.filename} is more than 128GB")

                        uuid = kw.get('dzUuid')
                        chunk_index = int(kw.get('dzChunkIndex'))
                        total_chunks = int(kw.get('dzTotalChunkCount'))

                        merged_file = request.env['ir.attachment'].sudo().create_temp_rec_db(file, token, sequence, uuid,
                                                                                             chunk_index, total_chunks)
                    if not kw.get('dzUuid') or merged_file:
                        fname = file.filename
                        if not merged_file:
                            fread = file.read()
                        else:
                            fread = merged_file

                        if not kw.get('dzUuid'):
                            _logger.info(f"{fname} is below 128GB")
                        else:
                            _logger.info(f"{fname} is more than 128GB but chunked.")
                            _logger.info(f"Saving {fname} as an attachment...")

                        try:
                            attachment = request.env['ir.attachment'].sudo().create({
                                'name': fname,
                                'type': 'binary',
                                'datas': base64.b64encode(fread),
                                'token': token,  # for tender reference
                                'tenderer_sequence': sequence,  # for tenderer reference
                                'pages_count': request.env['ir.attachment'].sudo().page_counter(fread),
                            })
                        except Exception as e:
                            if str(e) == 'File has not been decrypted':
                                attachment = request.env['ir.attachment'].sudo().create({
                                    'name': fname,
                                    'type': 'binary',
                                    'datas': base64.b64encode(fread),
                                    'token': token,  # for tender reference
                                    'tenderer_sequence': sequence,  # for tenderer reference
                                    # 'pages_count': 0,
                                    'is_file_not_decrypted': True,
                                })

                        _logger.info(f"{fname} has been saved as an attachment...")

                        # delete chunks when merged file is generated
                        if attachment and merged_file:
                            _logger.info(f'Deleting chunks for {attachment.name} ...')
                            request.env['ir.attachment'].sudo().search(['&', ('uuid', '!=', False),
                                                                        '&', ('uuid', '=', uuid),
                                                                        '&', ('token', '=', token),
                                                                        ('tenderer_sequence', '=',
                                                                         sequence)]).sudo().unlink()

                            _logger.info(f'{attachment.name} chunks are deleted.')

                    return http.Response(response="chunk/file uploaded", status=200)

                except Exception as e:
                    _logger.error(str(e))
                    return http.Response(response=str(e), status=500)

        else:
            return http.Response(response='No sequence and token', status=500)

    @http.route('/attachment-form/delete/<token>/<sequence>/id=<name>', type='http', methods=['POST'], auth='public', website=True, sitemap=False, csrf=False)
    def attachment_form_delete(self, token, sequence, name):
        try:
            request.env['ir.attachment'].sudo().search([('token', '=', token), ('tenderer_sequence', '=', sequence),
                                                        ('name', '=', name)]).unlink()
            _logger.info(f"{name} successfully deleted.")
            return http.Response(response=f"{name} successfully deleted.", status=200)
        except Exception as e:
            return http.Response(response=str(e), status=500)


    @http.route('/filter-region/country=<country>', type='http', methods=['POST'], auth='public', csrf=False)
    def filter_region(self, country):
        if country:
            regions = [{"name": i.name} for i in
                       request.env['res.country.state'].sudo().search([('country_id.name', '=', country)])]
            _logger.info(str(regions))
            return urllib.parse.quote(json.dumps(regions, separators=(',', ':')))


    @http.route('/assign-phone-code/country=<country>', type='http', methods=['POST'], auth='public', csrf=False)
    def assign_phone_code(self, country):
        if country:
            phoneCode = request.env['res.country'].sudo().search([('name', '=', country)]).phone_code
            if not phoneCode:
                phoneCode = +800
            return '+' + str(phoneCode)


    @http.route('/filter-subindustry/industry=<industry>', type='http', methods=['POST'], auth='public', csrf=False)
    def filter_subindustry(self, industry):
        if industry:
            subindustries = [{"name": i.name} for i in
                             request.env['hawk.subindustry'].sudo().search([('industry_id.name', '=', industry)])]
            _logger.info(str(subindustries))
            return urllib.parse.quote(json.dumps(subindustries, separators=(',', ':')))


class APIDocs(http.Controller):
    @http.route('/api', type='http', auth='public', website='True', sitemap=False)
    def api_docs(self, **kw):
        context = {}
        return request.render("hawk_web.api_docs", context)
