{
    'name': "hawk_web",
    'summary': "Hawk Web Module",
    'description': """
        Login Page and Portal for the Form Page connected to DMA.
    """,
    'author': "Arman Castro | Cuburt Balanon",
    'website': "",
    'category': 'base',
    'version': '0.1',
    'depends': ['website',
                'portal',
                'hawk_report'],
    'data': [
        'security/ir.model.access.csv',

        'views/assets.xml',
        'views/views.xml',
        'views/client_form.xml',
        'views/templates.xml',
        'views/api_documentation.xml',
        'views/portal.xml',

    ],
    'demo': [
        # 'demo/demo.xml',
        'demo/users.xml',
    ],
    'installable': True,
    'application': False,
}
