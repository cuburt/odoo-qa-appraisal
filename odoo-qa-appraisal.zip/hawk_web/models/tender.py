# -*- coding: utf-8 -*-
import io
import base64
import logging
from PyPDF2 import PdfFileReader

from odoo import api, fields, models
_logger = logging.getLogger(__name__)


class HawkTender(models.Model):
    _inherit = 'hawk.tender'

    tenderer_count = fields.Integer('Number of Tenderers')
    document_count = fields.Integer('Number of Reports')
    token = fields.Char()

    def tenderer_generator(self, kw):
        print('tenderer_generator', kw)
        try:
            y = self.env['hawk.analysis.type'].sudo().search([('is_active', '=', True)])
            z = self.env['survey.question.category'].sudo().search([
                ('is_active', '=', True),
                ('analysis_type_id.id', '!=', False)])

            for i in range(int(kw.get('tenderer_count'))):
                token = kw.get('token')
                name = kw.get('tenderer_name_' + str(i))  # name = tenderer's company name
                company = self.env['res.company'].sudo().search([('name', '=', name)])
                if not company:
                    company = self.env['res.company'].sudo().create({'name': name})

                ir_attachment = self.env['ir.attachment'].sudo()
                attachments = []
                is_file_not_decrypted = False
                for attachment in ir_attachment.search([('token', '=', token), ('tenderer_sequence', '=', i)]):
                    attachments.append(attachment)
                    if attachment.is_file_not_decrypted:
                        is_file_not_decrypted = True

                tenderer = self.env['hawk.tenderer'].sudo().create({
                    'name': name,
                    'company': company.id,
                    'sequence': i,
                    'analysis_ids': [(0, 0, {
                        'name': ' {} - {} Appraisal'.format(name, type.name),
                        'analysis_type_id': int(kw.get('analysis_'+str(type.sequence))),
                        'weight_ids': [(0, 0, {
                            'category_id': cat.id,
                            'weight': float(kw.get(cat.name+'_weight'))
                        }) for cat in z if cat.analysis_type_id.id == type.id and cat.name+'_weight' in kw and kw.get(cat.name+'_weight')]
                    }) for type in y if 'analysis_'+str(type.sequence) in kw and kw.get('analysis_'+str(type.sequence))],
                    'is_file_not_decrypted': is_file_not_decrypted,
                    'attachment_ids': [(4, attachment.id) for attachment in attachments],
                    'pages_count': sum([attachment.pages_count for attachment in attachments]),
                })

                _logger.info('__tenderer created successfully__')

                yield tenderer
        except Exception as e:
            _logger.error(str(e))
