# -*- coding: utf-8 -*-
import io
import base64
import logging
from PyPDF2 import PdfFileReader
from werkzeug.utils import secure_filename
from odoo import api, fields, models
import shutil


_logger = logging.getLogger(__name__)


class Attachment(models.Model):
    _inherit = 'ir.attachment'

    uuid = fields.Char()
    token = fields.Char()
    index = fields.Char()
    tenderer_sequence = fields.Integer()
    pages_count = fields.Integer()
    is_file_not_decrypted = fields.Boolean(default=False)

    def page_counter(self, fread):
        _logger.info("Counting pages...")
        pdf = PdfFileReader(io.BytesIO(fread), strict=False, overwriteWarnings=False)
        return pdf.getNumPages()

    def merge_temp_rec(self, chunks):
        file = b''
        _logger.info('Merging chunks...')
        for index in range(len(chunks)):
            for chunk in chunks:
                print(chunk.index,' ',index)
                if int(chunk.index) == int(index):
                    file += base64.b64decode(chunk.datas)
        if file:
            return file
        return False

    def create_temp_rec_db(self, file, token, sequence, uuid, chunk_index, total_chunks):
        fname = file.filename
        fread = file.read()
        _logger.info(f'Creating temporary db record for {fname} chunk {chunk_index} for tenderer {sequence} ...')
        self.sudo().create({
            'name': fname,
            'type': 'binary',
            'datas': base64.b64encode(fread),
            'uuid': uuid,
            'token': token,
            'index': chunk_index,
            'tenderer_sequence': sequence,
        })
        chunks = self.sudo().search(['&',('uuid', '!=', False),
                                     '&',('uuid', '=', uuid),
                                     '&',('token', '=', token),
                                     ('tenderer_sequence','=',sequence)])
        if len(chunks) == total_chunks:
            return self.merge_temp_rec(chunks)
        return False