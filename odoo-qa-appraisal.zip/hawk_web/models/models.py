# -*- coding: utf-8 -*-
import uuid
import base64
import binascii
import contextlib
import datetime
import hmac
import ipaddress
import itertools
import json
import logging
import os
import time
from collections import defaultdict
from hashlib import sha256
from itertools import chain, repeat

import decorator
import passlib.context
import pytz
from lxml import etree
from lxml.builder import E

from odoo import api, fields, models, tools, SUPERUSER_ID, _
from odoo.addons.base.models.ir_model import MODULE_UNINSTALL_FLAG
from odoo.exceptions import AccessDenied, AccessError, UserError, ValidationError
from odoo.http import request
from odoo.modules.module import get_module_resource
from odoo.osv import expression
from odoo.service.db import check_super
from odoo.tools import partition, collections, frozendict, lazy_property, image_process

_logger = logging.getLogger(__name__)

def _jsonable(o):
    try:
        json.dumps(o)
    except TypeError:
        return False
    else:
        return True

@decorator.decorator
def check_identity(fn, self):
    """ Wrapped method should be an *action method* (called from a button
    type=object), and requires extra security to be executed. This decorator
    checks if the identity (password) has been checked in the last 10mn, and
    pops up an identity check wizard if not.

    Prevents access outside of interactive contexts (aka with a request)
    """
    if not request:
        raise UserError(_("This method can only be accessed over HTTP"))

    if request.session.get('identity-check-last', 0) > time.time() - 10 * 60:
        # update identity-check-last like github?
        return fn(self)

    w = self.sudo().env['res.users.identitycheck'].create({
        'request': json.dumps([
            {  # strip non-jsonable keys (e.g. mapped to recordsets like binary_field_real_user)
                k: v for k, v in self.env.context.items()
                if _jsonable(v)
            },
            self._name,
            self.ids,
            fn.__name__
        ])
    })
    return {
        'type': 'ir.actions.act_window',
        'res_model': 'res.users.identitycheck',
        'res_id': w.id,
        'name': _("Security Control"),
        'target': 'new',
        'views': [(False, 'form')],
    }


# API keys support
API_KEY_SIZE = 20  # in bytes
INDEX_SIZE = 8  # in hex digits, so 4 bytes, or 20% of the key
KEY_CRYPT_CONTEXT = passlib.context.CryptContext(
    # default is 29000 rounds which is 25~50ms, which is probably unnecessary
    # given in this case all the keys are completely random data: dictionary
    # attacks on API keys isn't much of a concern
    ['pbkdf2_sha512'], pbkdf2_sha512__rounds=6000,
)
hash_api_key = getattr(KEY_CRYPT_CONTEXT, 'hash', None) or KEY_CRYPT_CONTEXT.encrypt


class User(models.Model):
    _inherit = 'res.users'

    api_link_ids = fields.One2many('hawk.api.link', 'user_id')


class APIKey(models.Model):
    _inherit = 'res.users.apikeys'
    _auto = False

    def init(self):
        try:
            self.env.cr.execute(
                "ALTER TABLE {table} ADD COLUMN IF NOT EXISTS key varchar not null;".format(table=self._table))
        except:
            self.env.cr.execute("""
             DELETE FROM {table};
             ALTER TABLE {table} ADD COLUMN IF NOT EXISTS key varchar not null;
             """.format(table=self._table))

# API link. for own api service. has method for hashing, for secured storage in db
class APIConfig(models.Model):
    _name = 'hawk.api.link'
    _description = 'hawk.api.link model'

    key = fields.Char()
    scope = fields.Char()
    user_id = fields.Many2one('res.users')
    is_production = fields.Boolean(default=False)
    sandbox_url = fields.Char()
    production_url = fields.Char()
    is_active = fields.Boolean(default=True)

    def _check_credentials(self, *, scope, key):
        assert scope, "scope is required"
        query = self.sudo().search([
            ('user_id.id', 'in', [rec.id for rec in self.env['res.users'].sudo().search([]) if rec.active]),
            '|', ('scope', '=', None), ('scope', '=', scope)])
        # self.env.cr.execute('''
        #         SELECT user_id, key
        #         FROM hawk_api_link INNER JOIN res_users u ON (u.id = user_id)
        #         WHERE u.active AND (scope IS NULL OR scope = %s)
        #     ''', [scope])
        # query = self.env.cr.fetchall()
        for rec in query:
            if KEY_CRYPT_CONTEXT.verify(key, rec.key):
                return {'user_id': rec.user_id.id, 'link_id': rec.id}

    def base64_encoder(self, string, type='standard'):
        if type == 'standard':
            return str(base64.b64encode(string.encode('UTF-8')), 'UTF-8')
        elif type == 'fibonacci':
            return True

    def base64_decoder(self, token):
        return base64.b64decode(token).decode('UTF-8')

    def base_url(self):
        self.ensure_one()
        return self.env['ir.config_parameter'].get_param('web.base.url')

    def remove(self):
        self.unlink()


# stores data from all customised portal web forms.
class APITransaction(models.Model):
    _name = 'hawk.api.transaction'
    _description = 'hawk web transactions'

    def _get_default_access_token(self):
        return self.env['hawk.api.link'].base64_encoder(str(uuid.uuid4()))

    name = fields.Char(default='POST')
    link_id = fields.Many2one('hawk.api.link', 'API Link')
    reference = fields.Char('Reference')
    type = fields.Selection([('api', 'API request'),('form_save', 'Form with tokenization')], 'Type', default='api', required=True, readonly=True)
    date = fields.Datetime(default=fields.Datetime.now())
    token = fields.Char('Access Token', default=lambda self: self._get_default_access_token(), copy=False)
    session = fields.Char()
    content_type = fields.Char()
    data = fields.Char()
    message = fields.Text()
    state = fields.Selection([('open', 'Open'), ('close', 'Closed')], default='open')

    def verify_headers(self, headers):
        try:
            link_id = False
            message = False
            if 'Authorization' in headers and headers.get('Authorization'):
                secret_key = headers.get('Authorization')
                apikey_user_id = self.env['res.users.apikeys'].sudo()._check_credentials(scope='rpc', key=secret_key)
                link = self.env['hawk.api.link'].sudo()._check_credentials(scope='rpc', key=secret_key)
                if link and apikey_user_id == link.get('user_id'):
                    link_id = link.get('link_id')
                    message = 'Your key and link are verified.'
                elif apikey_user_id and not link:
                    link_id = self.env['hawk.api.link'].sudo().create({
                        'user_id': apikey_user_id,
                        'key': hash_api_key(secret_key),
                        'scope': 'rpc'
                    })
                    link_id = link_id.id
                    message = 'Your key is verified. We have created a new link.'
                elif not apikey_user_id:
                    message = 'Your key does not exist.'
            else:
                message = 'You have not provided your key.'
            return {'link_id': link_id, 'message': message}
        except Exception as e:
            _logger.error('verify_headers', str(e))

    def initialize_tx(self, data, params, type='form'):
    # data : dict object that contains data from other form or api reqs.
    # params : dict object, parameters for creating web tx
    # type : selection, type of web tx.
    # form_save : save form data to this model for later use.
    # api : retrieve data from api request, save to this model for later use.
    # TODO: Implement this to all customised web forms.

        try:
            tx = False

            if type == 'api':
                headers = params['headers']
                link = self.verify_headers(headers)
                data = self.env['hawk.api.link'].base64_encoder(str(data))
                if link and link.get('link_id'):
                    tx = self.sudo().create({
                        'type': type,
                        'link_id': link.get('link_id'),
                        'data': data,
                        'content_type': headers['Content-Type'],
                        'message': link.get('message'),
                    })
                    tx.reference = 'api_' + tx.token + str(self.env['hawk.api.link'].base64_encoder(str(tx.id))),
            elif type == 'form_save':
                data = self.env['hawk.api.link'].base64_encoder(str(data))
                tx = self.sudo().create({
                    'type': type,
                    'reference': params['payment_intent'],
                    'data': data
                })
            return tx
        except Exception as e:
            _logger.error('initialize_tx', str(e))



