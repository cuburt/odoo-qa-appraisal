# -*- coding: utf-8 -*-

from odoo import api, fields, models
from odoo.exceptions import ValidationError


class Survey(models.Model):
    _inherit = 'survey.survey'
    _description = 'Inherit Survey Survey'

    editable_question_ids = fields.One2many('survey.question', 'survey_id', string='Editable Questions')
    survey_token = fields.Char(string='Survey Token')
    analysis_type_id = fields.Many2one('hawk.analysis.type')
    category_ids = fields.One2many(related='analysis_type_id.category_ids')
    # category_ids = fields.Many2many(related='analysis_type_id.category_ids')
    is_hawk_survey = fields.Boolean(default=False)
    is_fill_user_input = fields.Boolean(default=False)
    question_counts = fields.Integer(string='Total Questions', compute='_compute_question_counts')

    # ACTION
    def action_copy_questions(self):
        for questions in self.editable_question_ids:
            if not questions.formatted_title:
                questions.formatted_title = questions.title

    # COMPUTE
    def _compute_question_counts(self):
        self.question_counts = len(self.question_ids)


class SurveyQuestion(models.Model):
    _inherit = 'survey.question'
    _description = 'Inherit Survey Question'

    title = fields.Char('Title', required=False, translate=True)
    formatted_title = fields.Html('Question (Formatted)')
    help = fields.Char(string='Help')
    show_help = fields.Boolean(string='Show Help', default=False, compute='is_show_help')
    category_id = fields.Many2one('survey.question.category')
    parent_id = fields.Many2one('survey.question')
    child_ids = fields.One2many('survey.question', 'parent_id')
    score = fields.Integer

    # COMPUTE
    def is_show_help(self):
        for rec in self:
            rec.show_help = True if rec.help else False

    @api.model
    def create(self, vals):
        result = super(SurveyQuestion, self).create(vals)
        if not vals.get('is_page'):
            result.title = result.formatted_title
        return result

    def write(self, vals):
        result = super(SurveyQuestion, self).write(vals)
        if vals.get('formatted_title'):
            for rec in self:
                rec.title = vals.get('formatted_title')
        return result

    @api.onchange('formatted_title')
    def _onchange_formatted_title(self):
        question_id = self.env['survey.question'].browse(self._origin.id)
        # Create new section
        if self.is_page:
            if question_id.title:  # edit section (section is already existing)
                self.title = self.formatted_title
            else:
                self.formatted_title = self.title
        else:
            # Create new question
            self.title = self.formatted_title


# class SurveyQuestionAnswer(models.Model):
#     _inherit = 'survey.question.answer'
#
#     formatted_value = fields.Html('Suggested value', translate=True, required=True)
#
#     @api.onchange('formatted_value')
#     def _onchange_formatted_value(self):
#         q = self.env['survey.question'].browse(self._origin.id)
#         if self.value:
#             self.value = self.formatted_value
#         else:
#             pass


class SurveyUserInput(models.Model):
    _inherit = 'survey.user_input'
    _description = 'Inherit Survey User Input'

    survey_id = fields.Many2one('survey.survey', string='Survey', required=True, readonly=True, ondelete='cascade')
    survey_token = fields.Char(string='Survey Token', related='survey_id.survey_token')
    question_counts = fields.Integer(string='Total Questions', compute='_compute_question_counts')
    answered_counts = fields.Integer(string='Total Answered', compute='_compute_answered_counts')

    def _compute_question_counts(self):
        self.question_counts = len(self.user_input_line_ids)

    def _compute_answered_counts(self):
        count = 0
        for line in self.user_input_line_ids:
            if line.suggested_answer_id.id:
                count += 1
        self.answered_counts = count

    @api.model
    def _save_line_choice(self, question, old_answers, answers, comment):
        # Override to prevent creating another list if a comment is put on the questionnaire.
        if not (isinstance(answers, list)):
            answers = [answers]
        vals_list = []

        if question.question_type == 'simple_choice':
            if not question.comment_count_as_answer or not question.comments_allowed or not comment:
                vals_list = [self._get_line_answer_values(question, answer, 'suggestion') for answer in answers]
            if not answers:
                vals_list = [self._get_line_answer_values(question, '', 'suggestion')]
        elif question.question_type == 'multiple_choice':
            vals_list = [self._get_line_answer_values(question, answer, 'suggestion') for answer in answers]

        print('vals_list', vals_list)
        if comment:
            if vals_list:
                vals_list[0].update({
                    'findings': comment,
                    'value_char_box': comment,
                })
            else:
                pass

        old_answers.sudo().unlink()
        return self.env['survey.user_input.line'].create(vals_list)


class SurveyUserInputLine(models.Model):
    _inherit = 'survey.user_input.line'
    _description = 'Inherit Survey User Input Line'

    question_id = fields.Many2one('survey.question', string='Question', ondelete='cascade', required=True, readonly=True)
    suggested_answer_id = fields.Many2one('survey.question.answer', string="Answer", domain="[('question_id', '=', question_id)]")
    answer_score = fields.Float('Score', related='suggested_answer_id.answer_score')
    findings = fields.Char('Findings/Evidences')
    is_initialize = fields.Boolean()

    def create(self, vals):
        res = super(SurveyUserInputLine, self).create(vals)
        if res.survey_id.is_hawk_survey:
            if res.survey_id.is_fill_user_input:
                for user_input_line in res.survey_id.user_input_ids.user_input_line_ids:
                    if (vals[0].get('question_id') == user_input_line.question_id.id) and user_input_line.is_initialize:
                        user_input_line.sudo().unlink()
                        break
        return res

    # Override 'Save' button to fix the error when user tries to change the answer and save it
    def write(self, vals):
        vals.update({
            'answer_type': self.answer_type,
            'user_input_id': self.user_input_id,
            'question_id': self.question_id,
        })
        result = super(SurveyUserInputLine, self).write(vals)
        return result


class SurveyCategory(models.Model):
    _name = 'survey.question.category'
    _description = 'survey.question.category model'

    name = fields.Char()
    sequence = fields.Integer()
    tooltip = fields.Char()
    is_active = fields.Boolean(default=True)
    analysis_type_id = fields.Many2one('hawk.analysis.type')
    question_ids = fields.One2many('survey.question', 'category_id')


class Partner(models.Model):
    _inherit = 'res.partner'

    survey_user_input_ids = fields.One2many('survey.user_input', 'partner_id')
