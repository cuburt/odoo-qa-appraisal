# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo import tools, _
from odoo.exceptions import ValidationError, UserError


class HawkAnalysis(models.Model):
    _inherit = 'hawk.analysis'

    survey_id = fields.Many2one('survey.survey')
    is_demo = fields.Boolean(default=False)
    is_survey_started = fields.Boolean(default=False)

    def action_new_survey(self):
        try:
            hawk_config_params = self.env['ir.config_parameter'].sudo()
            safety_access_token = hawk_config_params.get_param('hawk_base.safety_access_token')

            if self.is_survey_started:
                print('survey is started')
            else:
                if self.is_demo:
                    safety_access_token = '6e5376fa-07c0-4627-ab29-f700f7dbd119'

                if safety_access_token:
                    if self.env.user.id == self.safety_analyst_id.id:
                        self.is_survey_started = True
                        safety_questionnaires = self.env['survey.survey'].search([('access_token', '=', safety_access_token)], limit=1, order='id desc')
                        copy_safety_questionnaires = safety_questionnaires.copy({
                            'state': 'open',
                        })
                        copy_safety_questionnaires.write({
                            'title': "Questionnaire for: %s" % self.name,
                            'survey_token': copy_safety_questionnaires.access_token,
                            'is_hawk_survey': True,
                        })

                        self.write({
                            'hide_new_btn': True,
                            'hide_resume_btn': False,
                            'access_token': copy_safety_questionnaires.access_token,
                            'survey_id': copy_safety_questionnaires,
                        })

                        # Update the Timeline
                        vals = [{
                            'analysis_id': self.id,
                            'details': 'Start Questionnaire',
                            'date': fields.Datetime.now(),
                            'res_person_id': self.safety_analyst_id.id,
                            'remarks': self.safety_analyst_id.name + ' started answering the safety questionnaire.',
                        }]
                        self.analysis_timeline_ids.create(vals)

                        # Alerts
                        odoobot = self.env.ref('base.partner_root')
                        self.message_post(
                            subject='Start Questionnaire',
                            body=self.safety_analyst_id.name + ' started answering the safety questionnaire.',
                            message_type='comment',
                            subtype_xmlid='mail.mt_comment',
                            notify_by_email=False,
                            author_id=odoobot.id,
                            partner_ids=[4, self.team_leader_id.partner_id.id])
                        self.action_send_email_notification('start_safety_questionnare_template', self)
                        return {
                            'type': 'ir.actions.act_url',
                            'target': 'self',
                            'url': '/survey/start/%s' % self.access_token
                        }
                    else:
                        raise ValidationError('Sorry only the assigned analyst is allowed to answer the questionnaire.')
                else:
                    raise ValidationError('Questionnaire not found. Please contact administrator.')
        except Exception as e:
            raise ValidationError(_(str(e)))

    def action_resume_survey(self):
        if self.safety_analyst_id.id == self.env.user.id:
            survey_user_input = self.env['survey.user_input'].search([('survey_token', '=', self.access_token)])
            answer_token = survey_user_input.access_token

            return {
                'type': 'ir.actions.act_url',
                'target': 'self',
                'url': '/survey/%s/%s' % (self.access_token, answer_token)
            }
        else:
            raise ValidationError('Sorry only the assigned analyst is allowed to resume the questionnaire.')

    def close_survey(self, access_token, answer_token):
        analysis = self.env['hawk.analysis'].search([('access_token', '=', access_token)])
        analysis.hide_resume_btn = True
        analysis.hide_submit_btn = False
        analysis.is_survey_done = True
        self.action_send_email_notification('done_safety_questionnare_template', analysis)

    def action_review_survey(self):
        if self.safety_analyst_id.id == self.env.user.id:
            return {
                'type': 'ir.actions.act_window',
                'name': 'Survey',
                'view_mode': 'form',
                'res_model': 'survey.user_input',
                'res_id': self.env['survey.user_input'].search([('survey_token', '=', self.access_token)]).id,
            }
        else:
            raise ValidationError('Sorry only the assigned analyst is allowed to review the questionnaire.')

    def action_submit_survey(self):
        print('action_submit_survey', self)
        vals_list = []
        if self.safety_analyst_id.id == self.env.user.id:
            questionnaire = self.env['survey.user_input'].search([('survey_token', '=', self.access_token)])
            records = questionnaire.user_input_line_ids
            for rec in records:
                if not rec.suggested_answer_id.value:
                    raise ValidationError('No answer provided on Section: {}.\n\nPress the Review button to edit your answers.'.format(rec.page_id.title))
                vals = {
                    'question': rec.question_id.title,
                    'section': rec.page_id.title,
                    'answer': rec.suggested_answer_id.value,
                    'findings': rec.findings if rec.findings else '',
                    'score': rec.answer_score,
                }
                vals_list.append(vals)
            self.survey_id.state = 'closed'
            self.write({
                'state': 'report',
            })

            # Update the Timeline
            res = [{
                'analysis_id': self.id,
                'details': 'Finished Questionnaire',
                'date': fields.Datetime.now(),
                'res_person_id': self.safety_analyst_id.id,
                'remarks': self.safety_analyst_id.name + ' finished answering the safety questionnaire.',
            }]
            self.analysis_timeline_ids.create(res)

            # Alerts
            odoobot = self.sudo().env.ref('base.partner_root')
            self.message_post(
                subject='Finished Questionnaire',
                body=self.safety_analyst_id.name + ' finished answering the safety questionnaire.',
                message_type='comment',
                subtype_xmlid='mail.mt_comment',
                notify_by_email=False,
                author_id=odoobot.id,
                partner_ids=[4, self.team_leader_id.partner_id.id])
            self.action_send_email_notification('submit_safety_questionnare_template', self)

            return vals_list
        else:
            raise ValidationError('Sorry only the assigned analyst is allowed to submit the questionnaire.')

    def action_send_email_notification(self, template, new_id=None):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        template_id = self.env.ref('hawk_base.{}'.format(template)).id
        url = base_url + '/web#id={}&model=hawk.analysis&view_type=form'.format(new_id.id)
        self.env['mail.template'].browse(template_id).with_context(url=url).send_mail(new_id.id, force_send=True)


class AnalysisType(models.Model):
    _inherit = 'hawk.analysis.type'

    category_ids = fields.One2many('survey.question.category', 'analysis_type_id')


class Weight(models.Model):
    _inherit = 'hawk.analysis.coeff'

    category_id = fields.Many2one('survey.question.category')
    weight = fields.Float(digits=(2, 3))
