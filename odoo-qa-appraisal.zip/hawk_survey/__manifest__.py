{
    'name': "hawk_survey",
    'summary': "Hawk Survey Module",
    'description': """
        Includes data for questionnaires and design for the Hawk Survey module.
    """,
    'author': "Arman Castro | Cuburt Balanon",
    'website': "",
    'category': 'base',
    'version': '0.1',
    'depends': ['hawk_base','survey'],
    'qweb': [],
    'data': [
        'security/ir.model.access.csv',
        'data/safety_questionnaire_settings.xml',
        'data/question_category.xml',
        'data/context_category_data.xml',
        'data/leadership_category_data.xml',
        'data/planning_category_data.xml',
        'data/support_category_data.xml',
        'data/operation_category_data.xml',
        'data/performance_category_data.xml',
        'data/improvement_category_data.xml',

        'views/assets.xml',
        'views/survey_templates.xml',
        'views/survey_survey_views.xml',
        'views/survey_question_views.xml',
        'views/survey_user_views.xml',
        'views/inherit_analysis_form.xml',
    ],
    'demo': [
        'demo/users.xml',
        'demo/demo.xml',
    ],
    'installable': True,
    'application': False,
}

